# AstroCS Alpha 0.11.0 模块化重构控制包

这是给前台 Agent 和固定 SubAgent 执行的工程控制包，不是源码补丁。它把现有 `main`（起点 `c1696156583c68c9a3a65287639c726937e9f6e7`，版本 `0.10.0-alpha.2`）收敛到目标 `0.11.0-alpha.1` 的工作拆成可审计任务。

前台 Agent 只能校验、派发、回收、在 `main` 串行集成、原子 commit/push、重算 Gate 和封签；算法/文档/测试长任务绑定给固定 SubAgent。三阶段分别运行；Windows x64 是正式平台，Linux 2c2g 是轻量控制节点；ACR 保留但不进入当前发布依赖。

## 从哪里开始

1. 读取 `START_PROMPT.txt` 与 `00_READ_FIRST.md`。
2. 先读 `01_OWNER_FROZEN_CONSTRAINTS.md`、`02_CURRENT_BASELINE_AUDIT.md`。
3. 用 `validators/run_control_checks.py` 验证本控制包。
4. 按 `TASK_LEDGER.csv`、`06_TASK_GRAPH_AND_WAVES.md` 和 `checklists/` 派发，不允许自行改排序或放宽门限。

## 负责人审查入口

最终审核只读 `templates/L0_OWNER_REVIEW.md` 对应的生成文件；科学定义、算法、接口、代码、测试和现场证据通过 ID/hash 链接追溯。没有 `READY_FOR_OWNER_REVIEW` 不得称发布。

