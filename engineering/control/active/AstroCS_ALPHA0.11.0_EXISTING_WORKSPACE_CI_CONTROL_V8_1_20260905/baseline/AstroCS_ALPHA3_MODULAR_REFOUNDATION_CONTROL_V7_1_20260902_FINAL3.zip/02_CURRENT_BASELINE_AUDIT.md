# AstroCS V6.1 架构审核与下一阶段设计方向

状态：设计审查稿（不是控制包，不授权 Agent 开始全面重构）  
日期：2026-09-02  
审查对象：`AstroCS_V6_1_PROGRESS_PACK_20260902T064333Z.zip`  
源码提交：`c1696156583c68c9a3a65287639c726937e9f6e7`  
源码版本：`0.10.0-alpha.2`  
进度包 SHA-256：`65b2c21431a31e6487c3260135d94ddba7e4894df790e2e07886d2149350379b`  
审查原则：以项目负责人本轮修正为最高约束；历史 V4/V5/V6/V19 文档不得覆盖本轮决定。

## 0. 结论先行

当前快照**不满足预发布架构冻结，也不能证明“科学定义、算法、接口、代码、测试完全一致”**。它已经有一些可复用基础，但模块化、调度、追溯和发布状态中存在结构性假阳性，不能在此基础上直接进入发布验证。

最严重的问题不是“还有几个旧版本号”，而是当前代码把完整 Session 包装成多个模块节点，静态 Pipeline 图和实际执行行为不一致：

- Phase2 的 7 个节点都创建同一个 `P2Api`，最终调用同一个 `p2_session_run()`；
- 该 Session 实际只做 `coverage → sample → upm_build → 可选 persist`，没有执行节点名声称的 `upm_apply/reject/integrate/write`；
- 因此 canonical Phase2 IR 可能把同一段计算重复运行多次，却仍没有完成真正的 Phase2 输出；
- 所有 `SessionModule` 固定 `workers_=2`，没有接收 Runtime 的真实线程租约；
- Scheduler 又创建自己的 `budget_` 线程池，Session 内部再创建私有线程，统一预算没有真正成立；
- trace 把 `workers` 直接填成全局预算、把 provider 固定写成 `baseline`，不是实测值。

这组问题可以直接解释此前观察到的 Phase2 极慢、CPU 利用率低，也证明现有“模块注册、静态图、运行 trace、资源预算均已闭环”的结论不可信。

下一阶段不应做大爆炸式重写，而应按以下顺序收敛：

1. 冻结负责人约束并清理虚假的当前状态；
2. 确立三个**彼此独立调用**的 Phase 产品合同；
3. 先建成真实的 DLL ABI、注册表、Runtime、I/O、Artifact、资源执行器骨架；
4. 将现有算法按模块逐一迁入真实执行节点，每迁一个就复用/补齐该模块单测；
5. 重建科学—算法—数据—API—源码符号—测试机器追溯；
6. Windows x64 作为正式构建与发布判据，Linux 仅做控制、静态、轻量编译和小合成验证；
7. Phase3 在独立科学合同下重新设计多投影、采样与流式内存模型。

## 1. 本次审查范围与证据边界

本次不是只看审核摘要。已检查进度包中的完整自有源码快照、根构建文件、CLI、Runtime、Module Registry、三个 Session、CPU provider、Phase3 实现、模块/架构/科学/API 文档、测试目录、机器检查脚本和审核包校验器。

快照规模：

| 项目 | 数量 |
|---|---:|
| 源码快照文件 | 1462 |
| 自有 C/C++ 头与实现（排除第三方/历史归档） | 613 |
| Markdown 文档 | 156 |
| `tests/` 文件 | 162 |
| `lib/` 一级目录 | 20 |
| 根 CMake 静态库 target | 21 |
| 根 CMake 共享库 target | 0 |
| 注册表声明 module ID | 22 |

本次结论属于架构、关键路径和文档/证据体系的深度静态审核，不冒充逐行证明所有 613 个自有 C/C++ 文件的科学正确性。后续必须由模块负责人按本文设计建立逐模块证明和机器证据。

## 2. 本轮必须覆盖旧文档的负责人决定

以下内容视为下一版工程约束的正式方向：

1. 只在 `main` 形成正式提交和 push，不建立常规功能分支。
2. Phase1、Phase2、Phase3 是三个独立产品命令、独立配置、独立运行、独立验收单元。
3. 三个 Phase **不得在同一进程中自动按 1→2→3 串接**；也不得以跨阶段内存 Artifact 图作为唯一生产语义。
4. Phase1 输出标准化单帧 HiPS；Phase2 接收一组符合合同的 HiPS 并输出马赛克 HiPS；Phase3 接收任一符合合同的 HiPS 并输出平面 FITS。Phase3 不要求输入一定来自 Phase2。
5. 阶段之间如需复用结果，只通过显式、持久化、带 manifest/hash/provenance 的产品交换，是否串联由用户在进程外决定。
6. Windows amd64 是正式开发、客户端和发布平台；Windows 10+ 必须有明确兼容矩阵和现场证据。
7. Linux amd64 是常在线控制、静态分析、辅助编译和小合成验证节点；不得为 Linux 便利反向扭曲 Windows 产品架构。
8. Linux CLI 可保留为同源的高级用户/技术预览产物，但不与 Windows 发布判据同权，首个正式发布以 Windows 为阻塞平台。
9. 正式产品只有一个用户可见的 `astrocs.exe`；科学模块、Runtime、I/O 和 CPU provider 以 DLL 交付，由 CLI 安全加载。
10. HiPS Browser 不进入 CLI 插件注册表；它是未来 Windows GUI 的独立可视化子模块。
11. ACR 保留但 dormant；首次正式发布不加载、不链接、不依赖 ACR。ACR 异构计算在正式发布后的独立性能版本接入。
12. 当前生产只使用纯 CPU；baseline/AVX2/AVX-512 等 provider 必须经硬件安全检测、数值自测和逐内核 benchmark 才能被选择。
13. 长时间 CPU-heavy 生产任务不得单线程或长期低利用率；短 I/O、元数据、初始化允许串行。
14. 前台 Agent 只负责拆解、分发、验收、串行集成和提交；每个模块绑定固定 SubAgent/owner。
15. 每个模块同时拥有模块化源码、模块化可复用单测、README、manifest、合同链接和独立验证入口。

## 3. 当前快照中值得保留的基础

不能因为整体未达标而推倒已有成果。以下基础可以保留并整改：

- 根 CMake 已使用显式源文件列表，没有用 GLOB 代替构建清单；
- `VERSION` 已存在，当前值为 `0.10.0-alpha.2`；
- ACR 默认 `OFF`，方向符合当前 CPU-only 决策；
- 已有 C ABI 风格的 host services、allocator、日志和取消接口雏形；
- 已有 `ModuleDescriptor`、`PipelineIR`、`ThreadBudget`、`ArtifactStore` 的类型定义和部分单元测试；
- Phase1/2/3、CPU backend、监控、接口、架构已有相当数量的测试素材；
- Phase2 的 sampling/UPM 等实现中已有显式 worker 参数，可迁移到统一执行器；
- Phase3 已有 TAN、HiPS properties、FITS 输出和合成测试原型，可作为重构输入，但不能直接认定为 production；
- 文档已经尝试采用 SCI/ALG/API/DATA/TEST ID，这一思路应保留，但要重建真实引用关系。

## 4. 当前状态详细审核

### 4.1 P0：伪模块化导致执行语义错误

`lib/core/src/module_adapters.cpp` 中所有 Phase2 描述符最终都通过：

```cpp
make_session_module<P2Api>(d)
```

而 `P2Api::run()` 固定调用：

```cpp
p2_session_run(h, c)
```

同样，所有 Phase3 节点均调用完整 `p3_session_run()`，Phase1 的多个描述符也都指向完整 `p1_session_run()`。

这不是模块注册，而是给同一整段函数贴了多个不同模块名。其后果是：

- 节点名称不等于执行代码；
- 单个节点不能独立输入、输出、测试、替换；
- 静态图无法用于定位真实性能和错误；
- 运行图会显示多个模块，实际却重复调用同一 Session；
- 固定 SubAgent 无法真正拥有一个模块，因为修改仍集中在 Session；
- 新功能仍会迫使全局修改。

必须废除“一个 Session adapter 冒充多个 node”的方式。每个注册节点必须绑定唯一的实际执行符号，并只实现该节点声明的输入、输出和副作用。

### 4.2 P0：Phase1/Phase2 canonical 路径并未执行文档所称完整算法

当前 `p1_session_run()` 只看到：

```text
io_read → calibrate → cosmetic → io_write
```

没有执行文档宣称的 star/PSF/WCS/photometry/noise/drizzle/HiPS writer 全链。

当前 `p2_session_run()` 只看到：

```text
coverage → sample → upm_build → optional persist
```

没有执行 registry/IR 声称的 upm_apply/reject/integrate/write。因此：

- “Phase1 8 节点 IMPLEMENTED”不成立；
- “Phase2 7 节点 IMPLEMENTED”不成立；
- 当前新 CLI 路径不能替代仍可能真正完成叠加的旧 Phase2 路径；
- 旧路径不能在新路径未等价接管前退出。

下一轮迁移必须采用 strangler/adapter 策略：旧实现先作为科学参考入口保留；新模块逐节点接管并通过模块 Oracle，最后才移除旧生产入口。禁止先宣布旧路径退出，再用不完整 facade 顶替。

### 4.3 P0：三个 Phase 的隔离要求与代码/文档冲突

`cli/runtime_client.cpp` 支持一个 `phases` 列表，将 P1/P2/P3 放入同一个 IR；Phase2 从字符串 `artifact:cal` 开始，Phase3 从 `artifact:hips_in` 开始。`docs/review/PIPELINE_OVERVIEW.md` 进一步宣称：

```text
phase1 → phase2 → phase3 唯一生产路径，逐 phase Artifact 哈希链传递
```

这与负责人要求直接冲突。下一版必须：

- 删除或禁用生产 `--phases` 多阶段组合；
- `astrocs phase1 run`、`astrocs phase2 run`、`astrocs phase3 run` 分别建立各自内部 IR；
- Runtime 实例的 DAG 生命周期不得跨 Phase；
- 跨 Phase 只认磁盘产品合同和 manifest，不认隐式 artifact 名；
- 集成测试可以由外部测试脚本依次启动三个进程，但不得把它重新定义成产品内连续 pipeline。

### 4.4 P0：线程预算只存在于类型和单测，没有进入真实执行

当前问题链：

1. `SessionModule::workers_ = 2` 硬编码；
2. `HostSession::init(workers_)` 永远只获得 2；
3. `RunContext::acquire_lease()` 只返回 `ThreadLease::make(n)`，没有调用已经实现的原子 `ThreadBudget::acquire()`；
4. Scheduler 启动 `budget_` 个线程，模块内部又创建 `std::thread` pool；
5. Runtime 未把一个共享 `ThreadBudget` 注入 `RunContext`；
6. `ModulePlan` 总是 `work_units=1`、`parallel_axes={"tile"}`，内存估计为 0；
7. trace 的 worker/provider 字段是填写值，不是观测值。

因此当前系统既可能低利用率，也可能在并行节点出现超额订阅。正确方向见第 9 节。

### 4.5 P0：ArtifactStore 与真实模块 I/O 未接通

`ArtifactStore` 有类和单测，但生产 Runtime 没有创建或绑定它；`IModule::execute()` 也没有类型化输入/输出参数。Runtime 只使用 artifact 字符串推导 DAG 边，没有把实际数据对象交给模块。

当前所谓 artifact 的主要来源是 Session inspect 返回的字符串路径。这无法证明：

- producer 唯一；
- schema、单位、坐标、shape、invalid policy 正确；
- consumer 实际读取的就是声明的文件；
- hash 是科学 payload hash 而非任意 JSON；
- 节点没有绕过 Store 直接猜路径。

ArtifactStore 需要在**单个 Phase 内**成为 Runtime 的真实服务；跨 Phase 则使用持久化 Product Manifest Reader/Writer，不应继续使用 `bind_p1_to_p2()`、`bind_p2_to_p3()` 这种强制顺序命名。

### 4.6 P1：当前构建不是 DLL 模块产品

根 `CMakeLists.txt` 有 21 个 `STATIC` target、0 个 `SHARED` target，最终 `astrocs` 静态链接几乎所有模块。另有 `cli/CMakeLists.txt` 把大量源文件直接编入单个可执行文件，`lib/phase2/CMakeLists.txt` 又保留 `astrocs-stage2`。

问题包括：

- 两套 CLI 构建事实源；
- 静态 registry，不存在 DLL discovery/load；
- AVX2/AVX-512 也是 STATIC，不是可独立安全路由的 provider；
- 旧 Phase2 executable 仍在构建；
- 依赖中保留机器专属 `ACS_ZLIB_ROOT` 和历史 MSYS2/MinGW 痕迹；
- Windows/MSVC 尚未成为唯一权威 release preset。

下一版只允许根 CMake 作为 build graph 权威，子目录 CMake 只声明本模块 target，不得再生成第二套产品入口。

### 4.7 P1：模块 ABI 不是可发布的 DLL ABI

当前 `ModuleDescriptor.abi` 多数写 `c++17`，registry 工厂使用 C++ lambda、`std::unique_ptr<IModule>`、`std::string`。这可以作为同一二进制内部接口，但不能作为稳定 DLL 边界。

Windows DLL 边界必须使用版本化 C ABI：

- 不跨 DLL 传 STL 容器、C++ exception、RTTI 对象；
- 不让一侧分配、另一侧用不同 allocator/CRT 释放；
- 每个结构体包含 `struct_size` 和 `abi_version`；
- buffer 所有权和生命周期逐字段定义；
- 导出符号采用固定名称和 calling convention；
- 失败返回稳定状态码，详细信息走 host logger/diagnostic buffer；
- module version、ABI version、data schema version、product version 分开。

### 4.8 P1：README 和模块单测尚未真正模块化

当前 `tools/check_module_readmes.py` 显示 PASS，但它只检查 5 个 README。实际 `lib/` 一级目录至少有以下 8 个缺根 README：

```text
backend_host
common
core
io
phase1
phase1_session
phase2_session
snr_estimator
```

测试主要集中在一个巨大的 `tests/unit/CMakeLists.txt` 和多个历史模块自带 test 目录，没有统一的模块边界、公共 fixture 规则和独立 Oracle 规则。后续应采用第 7 节目录规范。

### 4.9 P1：机器检查器和审核包不能独立证明 PASS

现场运行结果：

| 检查 | 结果 | 说明 |
|---|---|---|
| `check_module_readmes.py` | PASS | 只覆盖 5 个模块，结论范围过窄 |
| `check_serial_hardcode.py` | FAIL | 命中 Phase2、Phase3、Runtime 的 worker=1 路径 |
| `check_p3_status.py` | FAIL | 仍按旧 `cli/main.cpp` 结构查 Phase3 |
| `check_cli_run_preset.py` | FAIL | 仍要求已经被拆出的旧 monolithic CLI 代码形状 |
| `docs_machine_consistency.py` | FAIL | integration/rejection 状态文档集合为空，与源码不一致 |
| `check_traceability.py` | CRASH | 依赖不存在的 `artifacts/prerelease_v5/...` |
| `check_final_traceability.py` | FAIL | 当前追溯未闭合 |
| `check_version_consistency.py` | PASS | 检查范围绕过大量 `lib/`/历史语义，不能证明活跃文档无旧版本 |
| `check_l0_docs.py` | PASS | 只证明文件和表面字段存在，不证明结论正确 |
| 外层/内层审核包 validator | CRASH | 缺少互相 import 的脚本，包不能自包含校验 |

审核摘要还存在当前提交与 Windows 证据提交不一致：当前源码为 `c169615...`，Windows evidence 仍指向 `faad602...`；32R 为 NOT_RUN。因而 Windows/真实数据结论不能继承到当前提交。

### 4.10 P1：工程约束文件本身没有进入源码真相

`AstroCS_ENGINEERING_CONSTRAINTS.md` 出现在审核包的 `audit/source/`，却不在实际源码 tar 的仓库根目录。它是审核时注入还是未跟踪文件，来源不清。下一轮第一件事应把负责人确认后的新版本正式提交到 `main`，使其成为所有 Agent 和构建证据的可追踪输入。

### 4.11 P1：活跃文档存在大面积陈旧状态和直接矛盾

已人工确认的典型冲突：

| 文件 | 当前问题 |
|---|---|
| `README.md` | 仍称当前 V19R2，入口是 `toolchain.ps1` 和 `astrocs-stage2.exe`，未描述真实 alpha 架构 |
| `HANDOVER.md` | 仍是 V18R2、HEAD `77fc48e`、16 线程/64GB 老环境和旧生产入口 |
| `memory.md` | 仍称 Python 调 DLL、11 子仓、Windows F 盘、OpenMP 16 线程，不能作为当前记忆 |
| `AGENTS.md` | 仍把 Linux 写成开发环境，目录条款含糊；没有写清三个 Phase 独立 |
| `REVIEW.md` | 版本为 alpha.1，而 `VERSION` 为 alpha.2；又声称三个 Phase IMPLEMENTED |
| `docs/review/RELEASE_STATUS.md` | 声称 88 任务/81 PASS；审核 ledger 实际为 67 项：57 PASS、7 WAITING、3 NOT_STARTED |
| `docs/review/PIPELINE_OVERVIEW.md` | 把 Phase1→2→3 写成唯一连续路径，直接违反负责人要求 |
| `docs/review/SCIENCE_OVERVIEW.md` | Phase3 称 prototype；其他 L0 文档又称 implemented |
| `docs/algorithms/PHASE3_RESAMPLE.md` | 写“待实现”，代码与 ledger 又称已实现；插值描述与实现不一致 |
| `docs/architecture/PHASE3_MODULE_ARCH.md` | 声称共享 cache、异步预取、面积权重和受控内存，源码并未这样实现 |
| `docs/refactor/CLI_COMMAND_LAYER.md` | 声称 `main.cpp` 1521 行和 HEAD `d3f0b37`，当前 main 已拆到约 71 行 |
| `docs/refactor/P3_STATUS.md` | 同时把同一目录称 prototype 和 production，内部自相矛盾 |
| `CHANGELOG.md` | 顶部仍是 V19R8/V19R2 系列，没有当前 alpha 的权威变更节 |

不能做全仓机械替换：FITS 4.0、HiPS 1.0、ABI v1、schema version 等不是产品版本。必须先将版本分成四个命名空间：

1. 产品版本：只来自根 `VERSION`；
2. Module/API/ABI/Data schema 版本：各有独立生命周期；
3. 文档修订号：`doc_revision`；
4. 历史工程轮次：只允许出现在 `CHANGELOG` 和 `docs/history/`。

## 5. 目标产品和 Phase 边界

### 5.1 产品命令

```text
astrocs phase1 validate|plan|run|inspect <config>
astrocs phase2 validate|plan|run|inspect <config>
astrocs phase3 validate|plan|run|inspect <config>
astrocs benchmark cpu [--suite ...]
astrocs doctor
astrocs modules list|verify
astrocs version --json
```

必须移除：

```text
astrocs run --phases 1,2,3
```

允许测试脚本在三个独立进程间串接文件，但不得重新引入产品内串行 Phase 状态机。

```mermaid
flowchart TB
    P1["独立 Phase1 Runtime"] --> O1["单帧 HiPS + manifest"]
    P2["独立 Phase2 Runtime"] --> O2["马赛克 HiPS + manifest"]
    P3["独立 Phase3 Runtime"] --> O3["平面 FITS + manifest"]
    EXT["用户/外部工作流"] -.显式选择输入.-> P1
    EXT -.显式选择输入.-> P2
    EXT -.显式选择输入.-> P3
```

图中的三个 Runtime 不共享内存状态；虚线表示用户或外部脚本可以选择已有持久化产品，并不定义强制阶段顺序。

### 5.2 三个 Phase 的独立产品合同

| Phase | 输入 | 输出 | 内部可有 DAG | 不得假设 |
|---|---|---|---|---|
| Phase1 | 单帧 light、masters、星表/配置 | 每帧标准化 HiPS 产品及 manifest | 是 | 后面一定运行 Phase2 |
| Phase2 | N 个符合 DATA-HIPS 合同的单帧/兼容 HiPS | 马赛克 HiPS、UPM/rejection/integration provenance | 是 | 输入一定由同一进程 Phase1 生成 |
| Phase3 | 任一符合受支持 HiPS 子集的产品 | 平面 FITS、coverage/validity、WCS/provenance | 是 | 输入一定来自 Phase2 |

每个 Phase 的 `validate` 必须只做静态/轻量检查；`plan` 输出节点、work units、内存、I/O 和预计 provider；`run` 才执行；`inspect` 只读已生成 manifest，禁止重算。

## 6. Windows 发布布局与 DLL 划分

用户看到一个 CLI，但发布目录不可能物理上只有一个文件；DLL、schema、license 和 manifest 必须随包交付。建议布局：

```text
AstroCS/
  astrocs.exe
  astrocs.product.json
  modules/
    astrocs_runtime.dll
    astrocs_io.dll
    astrocs_calibration.dll
    astrocs_astrometry.dll
    astrocs_photometry.dll
    astrocs_noise.dll
    astrocs_drizzle.dll
    astrocs_p2_sampling.dll
    astrocs_p2_upm.dll
    astrocs_p2_rejection.dll
    astrocs_p2_integration.dll
    astrocs_p3_projection.dll
    astrocs_p3_resample.dll
  providers/
    astrocs_cpu_baseline.dll
    astrocs_cpu_avx2.dll
    astrocs_cpu_avx512.dll
  pipelines/
    phase1.default.json
    phase2.default.json
    phase3.default.json
  schemas/
  licenses/
```

具体原则：

- 不按每个小函数拆 DLL；按“可独立拥有、测试、替换、发布”的科学/工程责任域拆分；
- `common` 应尽量是 header/value contract，避免形成到处互相链接的万能 DLL；
- CFITSIO/zlib/zstd/lz4 等第三方依赖由 `astrocs_io.dll` 私有封装，不泄漏到模块 ABI；
- Gaia catalog client 属于独立数据访问 DLL，不并入 Runtime；
- HiPS Browser 不在此目录的 `modules/` registry 中；未来 GUI 单独安装并通过 CLI/文件协议工作；
- ACR DLL 不进入首次发布目录和 product manifest；
- 未在真实硬件通过数值自测和 benchmark 的 provider 不得随正式包启用。

```mermaid
flowchart TB
    CLI["astrocs.exe"] --> RT["本 Phase Runtime"]
    RT --> REG["安全 DLL Registry"]
    RT --> SVC["I/O · Artifact · Executor · Log"]
    REG --> MOD["科学模块 DLL"]
    MOD --> CPU["CPU Provider DLL"]
```

Windows 加载器必须从 product manifest 的显式允许列表加载绝对路径 DLL，校验文件 SHA-256、ABI、build ID 和 module ID；使用安全 DLL 搜索策略，禁止从当前工作目录或任意 PATH 自动捡 DLL。Microsoft 推荐使用 `LoadLibraryEx` 的 `LOAD_LIBRARY_SEARCH_*` 约束搜索目录：[LoadLibraryEx 文档](https://learn.microsoft.com/en-us/windows/win32/api/libloaderapi/nf-libloaderapi-loadlibraryexa)。

## 7. 模块源码、README 和可复用单测目录规范

保留现有 `lib/` 习惯，逐模块收敛为统一结构：

```text
lib/<module_id>/
  README.md
  CMakeLists.txt
  module.yaml
  include/astrocs/<module_id>/
    public_api.h
    types.h
  src/
    module_entry.cpp
    *.cpp
  tests/
    CMakeLists.txt
    unit/
    properties/
    oracle/
    fixtures/
    negative/
    performance/
```

每个模块 README 固定包含：

1. 模块 ID、DLL target、状态、owner；
2. 负责与明确不负责的内容；
3. 输入/输出端口、DATA ID、单位、坐标、dtype、shape、invalid 语义；
4. 对应 SCI、ALG、API、ARCH、TEST 文档链接；
5. 实际导出入口和主要内部符号索引；
6. 配置 schema 和默认值；
7. 串/并行模型、并行轴、线程租约、内存和 I/O 上界；
8. 取消、错误、日志、指标、checkpoint；
9. 独立 Oracle、性质测试、容差；
10. Windows/Linux 构建和模块单测命令；
11. 已知限制和未实现能力。

模块测试规则：

- 测试与模块共址，便于未来直接复用；
- 根 `tests/` 只保留跨模块 contract、CLI、integration、release acceptance；
- 建立 `tests/testkit`，只提供 harness、临时目录、确定性 RNG、报告格式，不提供生产算法；
- 独立 Oracle 不得调用被测生产符号或复用同一公式实现；
- 每个 DLL 生成唯一 CTest label，例如 `module:p2_upm`；
- `astrocs test module <id>` 可以调用测试 runner，但正式用户运行不依赖 Python；
- 合成 fixture 由 seed+参数生成，禁止把巨大二进制夹具提交仓库；
- 每个性能关键模块至少包含 1-worker/N-worker、baseline/ISA 等价和资源曲线测试。

## 8. DLL C ABI 与注册协议

建议每个模块只导出一个稳定查询符号：

```c
ACS_EXPORT acs_status ACS_CALL
astrocs_module_query_v1(uint32_t host_abi,
                        const acs_module_api_v1** out_api);
```

`acs_module_api_v1` 至少包含：

```text
struct_size / abi_version
module_id / module_version / build_id
describe_json
validate_config
plan
create
execute
inspect
request_cancel
destroy
self_test
```

`execute` 不接受任意文件路径拼接，而接受 Runtime 已验证的 input artifact handles 和 output sink；模块通过 host services 获取：

```text
allocator
logger
metrics
cancellation
thread_executor / ThreadLease
artifact_reader / artifact_writer
checkpoint
kernel_provider
```

关键限制：

- C ABI 结构只用固定宽度整数、POD、span/handle；
- `struct_size` 允许尾部扩展；
- host 和 module 双方先协商 ABI，再调用任何函数；
- 所有跨边界文本为 UTF-8；
- 路径在 Windows 内部转换为 UTF-16，公共 JSON 保持 UTF-8；
- host allocator 分配的内存必须由 host allocator 释放；
- module 私有对象只通过 opaque handle 传递；
- DLL 内捕获全部 C++ exception，边界只返回 `acs_status`；
- C++ 内部接口可以存在，但不能作为发布 ABI。

`module.yaml` 是构建期/文档期声明；DLL 内嵌 query 返回的是运行时事实。机器检查必须比较二者，任何不同即构建失败。

## 9. Runtime、调度和资源模型

### 9.1 只保留一个线程执行器

建议 alpha 首版采用最稳妥模型：

- 每个 Phase 启动一个 Runtime；
- DAG coordinator 在控制线程运行；
- 全 Phase 只有一个共享 CPU work executor，线程数来自可用配额/benchmark profile；
- CPU-heavy node 默认一次只运行一个，并通过 `parallel_for` 使用大部分或全部租约；
- I/O 可由独立、严格有界的 1–2 线程队列与计算重叠；
- 后续只有在证明确有收益时，才允许多个独立 heavy node 分享预算并行；
- 模块不得创建私有永久线程池，不得直接调用 `hardware_concurrency()` 决策，不得固定 2/16/32；
- 如保留 OpenMP，只能由 host 按 lease 注入 `num_threads(lease.size)`，禁 nested。

这比“Scheduler N 线程 + 每个 Session 再 N 线程”容易证明，也符合当前多数线性科学链。

### 9.2 真实 plan 和 trace

每个模块的 `plan()` 必须从输入元数据计算：

```text
work_units
parallel_axis
min/max useful workers
estimated_peak_memory
estimated_read/write bytes
kernel IDs
serial sections
```

实际 trace 必须从 executor、provider 和 monitor 采集，禁止把配置值写成观测值。至少记录：

```text
node/module/build_id
start/end/wall/cpu time
requested/granted/peak active workers
provider + kernel ID
work units completed
CPU normalized utilization time series
RSS/commit/private bytes
read/write bytes and throughput
queue/lock/io wait
cancel/error/checkpoint
input/output artifact hashes
```

### 9.3 低利用率硬门

对持续时间 ≥10 秒且声明为 `cpu_heavy` 的任务，建议冻结以下初始门限，后续可由真实数据校准，但 Agent 无权自行放宽：

- 可用 CPU ≥2 且 work units 足够时，峰值 active workers 必须 ≥2；
- 按获配逻辑核归一化的平均 CPU 利用率建议 ≥80%；
- 连续 10 秒低于 60% 必须触发诊断事件；
- 低利用率不得直接 PASS，必须归因为 I/O、内存带宽、锁、负载不均、错误的任务粒度或重复串行；
- RSS 持续单调增长、任务结束不回落到可解释高水位时失败；
- 监控器与业务进程同一 run ID，报告不可手工拼接。

若算法确属内存带宽受限，也应表现为线程活跃和可量化带宽饱和；不能用一句“可能是内存”豁免。

## 10. CPU provider、ISA 安全和 benchmark

### 10.1 不要给每段代码机械复制三份

架构应支持 baseline、AVX2/FMA、AVX-512、BMI2 等 provider，但只有经 profile 确认的热点 kernel 才实现高级 ISA。一个 provider 可以只实现部分 kernel，其他调用自动落回 baseline。这避免三份科学算法逐渐漂移。

建议首发 provider：

| Provider | 最低要求 | 用途 |
|---|---|---|
| baseline | AMD64/x86-64 基线（不要求 AVX） | 未 benchmark 或高级 ISA 不安全时必定可用 |
| avx2 | CPUID AVX2+FMA，OSXSAVE/XCR0 保存 YMM | 通用向量热点 |
| avx512 | 明确所需 AVX-512 子集，OSXSAVE/XCR0 保存 ZMM | 仅实测更快且硬件现场验证的 kernel |
| bmi2（可作为能力而非独立 DLL） | BMI2 | HEALPix/NESTED 位交错等特定 kernel |

MSVC `/arch:AVX2` 和 `/arch:AVX512` 必须只作用于相应 provider target；Microsoft 明确这些选项会改变编译器可发出的指令集：[MSVC /arch x64](https://learn.microsoft.com/en-us/cpp/build/reference/arch-x64?view=msvc-170)。baseline 不能因为全局编译选项意外含 AVX。

### 10.2 选择过程

顺序必须固定：

1. CPUID 检测 CPU feature；
2. XGETBV/OSXSAVE 检查操作系统是否保存相应寄存器状态；
3. DLL manifest 检查 ABI/build/hash；
4. provider 自测对 baseline/解析 Oracle 通过；
5. 对每个 kernel 和典型尺寸 benchmark；
6. 只在速度收益超过冻结噪声门限且数值通过时选择；
7. 写入硬件指纹绑定的 profile；
8. CPU、OS、软件 build、provider hash、profile schema 任一变化则失效重测；
9. 没有 profile 时只用 baseline，并输出明确提示。

AVX-512 可能因频率下降在部分 CPU/内核上慢于 AVX2，所以 profile 必须按 kernel 选择，不能写一个全局 `preferred_isa=avx512`。

### 10.3 profile 内容

建议 Windows 存放：`%LOCALAPPDATA%\AstroCS\cpu_profile.json`，仓库和发布包不内置某台机器的 profile。内容包括：

```text
profile schema/version
product build ID
CPU vendor/family/model/stepping
logical/physical cores, groups, NUMA, affinity/job limits
cache topology
CPUID/XCR0 features
memory bandwidth sample
kernel → provider/workers/block/median/MAD/tolerance
created time/tool version
integrity hash
```

## 11. 文档—代码一致性机制

### 11.1 权威层级

```text
SCI 科学定义
  ↓ 推导
ALG 离散算法、误差、复杂度
  ↓ 承载
DATA + API + ARCH 软件合同
  ↓ 实现
源码符号 + module manifest
  ↓ 证明
TEST + runtime evidence
  ↓ 汇总
Owner L0 文档
```

SCI 不得由代码反向生成；函数签名也不得由手写文档冒充事实。建议权威规则：

- SCI/ALG/DATA 语义由人工编写和审核；
- API 的解释由人工写，真实签名由 AST 从 public header 生成；
- 模块集合由 DLL query 和 release manifest 生成；
- Pipeline 图由每个 Phase 的 IR 生成；
- 真实运行图由 trace 生成；
- L0 只汇总以上事实，不复制一套底层公式和状态。

### 11.2 活跃文档 front matter

每份活跃文档必须有：

```yaml
doc_id:
title:
status: DRAFT|ACTIVE|DEPRECATED
doc_revision:
product_version_min:
authority:
owner:
upstream_ids: []
downstream_ids: []
last_verified_commit:
generated_sections: []
```

禁止在活跃文档正文写“当前 HEAD=某旧 SHA”“V19R8 已完成”“main.cpp 1521 行”等易腐事实。此类值放在机器生成状态块。

### 11.3 机器检查必须新增

1. AST 提取所有 public C ABI 符号、参数、可见性、calling convention；
2. 比较 header、DLL export table、API contract、module manifest；
3. 检查每个 module ID 唯一且有 README/CMake/tests/owner；
4. 检查每个端口引用存在的 DATA ID；
5. 检查每个 SCI claim 有 ALG 推导和至少一个独立 TEST；
6. 检查源文件/符号引用有效 ALG/API ID，不接受只出现关键词；
7. 从 Phase IR 生成静态图，从 trace 生成运行图，并比较节点、边和执行次数；
8. 检查每个注册节点的实际 execute symbol 唯一，禁止多个不同节点绑定同一整段 Session；
9. 检查 `cpu_heavy` 节点的 plan、lease、观测 worker 和监控证据；
10. 检查活跃文档中旧产品版本、旧路径、旧入口、旧 HEAD；
11. 检查链接、锚点、schema 和配置示例；
12. 根据 git diff 计算受影响 module/contract/test 集；
13. 检查 L0 的 PASS 数量由 ledger/evidence 自动生成；
14. 对 checker 做 mutation tests，确保删掉一个 README、改一个函数名或替换一个 module ID 时会失败；
15. 所有 checker 必须可在审核包解压后独立运行，不得 import 未打包脚本。

### 11.4 运行图文档

推荐同时生成：

- 构建依赖图：CMake File API；
- include/API 图：Clang AST/clang-doc；
- 静态调用图：Doxygen+Graphviz 或基于 compile database 的 Clang 工具；
- Phase IR 图：项目自有 `astrocs graph phaseN`；
- observed graph：真实 trace 转 Mermaid/DOT；
- graph diff：declared vs observed，任何重复节点、缺节点或额外边失败。

静态调用图只能解释可能调用关系，不能代替 observed graph。

## 12. 工程目录、控制包、工作区和历史归档

### 12.1 仓库内

```text
/
  AGENTS.md                         # 极短入口
  AstroCS_ENGINEERING_CONSTRAINTS.md
  VERSION
  CMakeLists.txt
  CMakePresets.json
  cmake/
  cli/
  include/astrocs/abi/
  lib/<module>/...
  pipelines/phase1|phase2|phase3/
  schemas/
  docs/
    owner/
    science/
    algorithms/
    data/
    architecture/
    api/
    standards/
    modules/                        # 生成索引，不复制模块 README
    history/<release>/
  tests/
    testkit/
    contracts/
    integration/
    acceptance/
  tools/
    docgen/
    quality/
    packaging/
```

控制任务的 ledger、几十轮报告和审核包不应散落到源码树。仓库只跟踪稳定约束、schema、工具和当前产品文档。

### 12.2 Linux 控制节点

```text
/srv/astrocs/
  repo/                             # 唯一 main 工作副本
  control/
    active/<cycle_id>/
      package/
      state/
      ledger/
      assignments/
      decisions/
    archive/<cycle_id>/             # 只读历史控制包
  work/
    foreground/
    modules/<module_id>/<task_id>/  # detached worktree/patch 工作区
  reports/<cycle_id>/
    human/
    machine/
  artifacts/<cycle_id>/
    audit/
    release/
    previews/
  logs/<cycle_id>/<task_id>/
  data/testdata/                    # 只读，不进入审核包
```

### 12.3 Windows Fatduck

Windows 根路径不要硬编码某个用户目录；统一由 `ASTROCS_WORKSPACE` 指定：

```text
%ASTROCS_WORKSPACE%\
  repo\
  build\<preset>\
  run\<run_id>\
  data\testdata\
  artifacts\<cycle_id>\
  logs\<cycle_id>\
```

发布脚本、测试和配置不得出现 `C:\Users\某人\...` 或旧 F 盘绝对路径。

## 13. 前台 Agent 与固定 SubAgent 工作模型

固定 owner 表存放在当前控制周期：

```text
control/active/<cycle>/assignments/AGENT_BINDINGS.yaml
```

建议责任域：governance/docs、runtime/scheduler、io/artifact、CLI/build/package、CPU providers、Phase1 各科学模块、Phase2 sampling、UPM、rejection/integration、Phase3 projection/resample。

前台 Agent 只做：

1. 校验起点 `HEAD=main=origin/main`；
2. 按依赖向固定 owner 分发任务；
3. 验收 patch、机器证据和 README/合同影响；
4. 在 main 上串行集成；
5. 运行受影响测试；
6. 形成单一目的 commit 并立即 push；
7. 更新 ledger 和顶层自动状态；
8. 最终白名单打审核包。

SubAgent 不直接并发写 main。为同时满足“固定 SubAgent”和“main-only”：

- 读审任务可并行；
- 写任务在 detached worktree 完成 patch 和证据；
- 前台 Agent 每次只集成一个 patch 到 main；
- 不创建功能分支，不让多个 Agent 同时提交 main；
- 跨模块变更由 foreground 拆成 Runtime/API 合同任务和模块适配任务，禁止一个 SubAgent横扫全仓。

## 14. Windows 10+ 支持与工具链规范

### 14.1 建议支持矩阵

首个正式版本建议冻结：

| 平台 | 级别 | 说明 |
|---|---|---|
| Windows 11 x64 | Tier 1 | 正式构建、完整测试、真实数据、发布 |
| Windows 10 22H2 x64 | Tier 1 compatibility | 必须有启动、CLI、DLL、baseline/可用 ISA、完整或代表性科学链现场测试 |
| Linux x86_64 | Tier 2 | 控制、静态、sanitizer、小合成、极客 CLI；不驱动 Windows 产品妥协 |
| x86/ARM64 | 不支持 | 当前明确只支持 amd64 |

Windows 10 22H2 已于 2025-10-14 结束微软常规支持；AstroCS 可以承诺技术兼容，但发布说明必须披露操作系统本身的服务状态，不能暗示微软仍提供安全支持：[Microsoft 生命周期说明](https://learn.microsoft.com/en-us/lifecycle/announcements/windows-10-22h2-end-of-support-update)。

### 14.2 正式构建工具链

建议 alpha 锁定以下系列，并在 `toolchain.lock.json` 中记录实际 patch 版本和 SHA：

- Visual Studio 2022 Build Tools 17.14；
- MSVC v143 x64/x86 build tools（只生成 x64 产品）；
- Windows SDK 10.0.26100 系列；
- CMake ≥3.24，正式周期锁定一个实测 patch 版本；CMake 的 VS 2022 generator 从 3.21 起支持：[CMake VS 2022 generator](https://cmake.org/cmake/help/latest/generator/Visual%20Studio%2017%202022.html)；
- Ninja（如选 `Ninja Multi-Config`，则它成为唯一 generator；否则统一用 VS 2022 generator，不能两者结果混称同一 release）；
- Python 3.12 x64（仅测试、文档和打包，不成为 CLI runtime 依赖）；
- Git for Windows；
- LLVM/clang-cl、clang-tidy、clang-format（质量验证 lane，不替代 MSVC release build）；
- Doxygen + Graphviz（代码/API/调用图生成）；
- CTest；
- 可选 vcpkg manifest，必须锁定 baseline commit，不允许用户专属 zlib 路径。

Visual Studio Build Tools 应安装 `Desktop development with C++`、MSVC v143、Windows SDK、CMake tools 和测试工具。当前 Microsoft 组件清单把 Windows 11 SDK 10.0.26100 与 VS 2022 17.14 列为推荐组件：[Build Tools 组件清单](https://learn.microsoft.com/en-us/visualstudio/install/workload-component-id-vs-build-tools?view=visualstudio)。

### 14.3 编译和运行时规范

- C++17；MSVC `/permissive- /Zc:__cplusplus /utf-8 /W4 /WX`（第三方单独隔离）；
- Release `/O2`，科学关键模块默认 `/fp:precise`；任何 `/fp:fast` 必须按 kernel 单独科学验证，不得全局打开；
- DLL/EXE 使用统一动态 CRT `/MD`，避免跨 DLL CRT/allocator 混乱；
- 安装器检查或安装最新受支持的 x64 Visual C++ Redistributable。Microsoft 说明 VS 2015 以后 v14 runtime 保持二进制兼容：[VC++ Redistributable](https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170)；
- baseline target 不使用 `/arch:AVX*`；AVX2/AVX-512 只在 provider target；
- 所有 first-party warning 当错误；第三方 warning 通过 SYSTEM/private target 隔离，禁止全局 `/w`；
- 不使用 MinGW/MSYS2 头或库混入 MSVC 产品；HiPS Browser 的 Qt 工具链另立文档；
- public C ABI 不暴露 Windows handle、STL、CRT FILE、exception；
- 所有 DLL 使用同一 product build ID，release manifest 校验；
- Windows 长路径、Unicode 路径、无管理员权限、只读输入、磁盘不足和取消必须测试。

### 14.4 CMake presets

最少保留：

```text
windows-msvc-release      # 唯一正式产品构建
windows-msvc-debug        # 单测/调试
windows-clang-analysis    # clang-tidy/AST/静态分析
linux-gcc-smoke           # 轻量编译/单测
linux-clang-sanitizer     # 小合成 sanitizer
```

Linux PASS 不能自动生成 release-ready；`windows-msvc-release` 和 Win10/Win11 运行证据是发布硬门。

## 15. Phase3 多投影重新设计

### 15.1 科学边界

Phase3 是独立的球面 HiPS → 平面 FITS 重投影器。它不修复 Phase2 接缝，也不改变输入天区的科学背景；如果 Phase2 输入已经有接缝，Phase3 应如实投影并在质量图中暴露，不得用平滑掩盖。

HiPS 1.0 要求 NESTED 编号，但不强制重采样算法；tile width 也应从 properties 读取，不能把 512 当成普适科学常数：[IVOA HiPS 1.0](https://www.ivoa.net/documents/HiPS/20161122/PR-HiPS-1.0-20161122.pdf)。FITS 输出必须符合官方 FITS 4.0 及 FITS-WCS 约定：[FITS 4.0](https://fits.gsfc.nasa.gov/fits_standard.html)、[FITS WCS Paper II](https://www.aanda.org/articles/aa/pdf/2002/45/aah3860.pdf)。

### 15.2 首版投影集合

建议 Phase3 alpha 的 REQUIRED 集合：

| code | 用途 | 关键性质/限制 |
|---|---|---|
| TAN | 小/中视场局部成像 | 切平面；远离投影中心畸变快速增大，不能全空 |
| SIN | 正交视图/半球局部图 | 可表示一个半球，边界需 mask |
| ZEA | 局部/半球等面积分析 | 保面积，形状随距离畸变 |
| CAR | 简单经纬矩形/条带 | 极区面积和形状畸变大，需明确 RA wrap |
| AIT | 全空等面积展示 | 椭圆边界，边界外必须 invalid |

OPTIONAL 后续：ARC、STG、MOL、MER。架构从第一天支持 provider 扩展，但未通过独立 Oracle 的 code 不出现在 `modules list` 的 production capability 中。

投影选择属于用户科学意图。`phase3 run` 应要求显式 projection；可另提供 `phase3 recommend-projection` 输出建议和理由，但不得在 run 中静默自动换投影。

### 15.3 Projection Provider 接口

`astrocs_p3_projection.dll` 内部定义统一接口：

```text
ProjectionSpec
  code, frame, CRVAL, CRPIX, CD/PC+CDELT, LONPOLE/LATPOLE, PV[]

ProjectionCapabilities
  local/global, equal_area, conformal, valid_native_domain,
  singularities, periodic_longitude, required_parameters

ProjectionPlan
  output footprint, boundary mask, estimated distortion,
  pixel solid-angle/Jacobian requirements

inverse_batch(pixel_xy → sky_lonlat + validity)
forward_batch(sky_lonlat → pixel_xy + validity)
jacobian_batch(pixel_xy → dΩ/dA)
emit_fits_keywords()
```

不要在 `P3WcsDescriptor` 中固定 `projection="TAN"`。投影参数 schema 应按 code 使用 discriminated union，未知参数和缺参数必须拒绝。

优先评估将 WCSLIB 作为投影实现后端并封装在该 DLL 内，以减少手写标准投影风险；WCSLIB 实现 FITS-WCS，并以 LGPL 发布，若采用必须完成依赖许可和动态链接告知：[WCSLIB](https://www.atnf.csiro.au/computing/software/wcs/)。即使使用 WCSLIB，项目仍需维护不复用生产库的解析/高精度测试 Oracle。

### 15.4 采样语义必须重写

当前 `p3_sample_bilinear()` 不是严格的 HEALPix bilinear：它在局部切平面选四象限最近中心，缺象限时复制最近点，再套矩形双线性权重。文档却声称四 leaf 面积重叠权重。两者不一致，且对不规则 HEALPix 邻域没有充分科学证明。

建议明确三种名字和语义：

1. `nearest`：取包含球面坐标的 HEALPix leaf；
2. `healpix_interp4`：基于明确定义的四邻域球面插值，权重、极区和 face 边界规则写入 ALG；
3. `area_average`：对输出像素球面 footprint 做面积平均/足够阶数 quadrature，用于可靠降采样。

不要继续把非矩形球面插值泛称 bilinear。首个可发布版本至少需要 `nearest` 和经独立 Oracle 验证的 `healpix_interp4`；如果没有 `area_average`，必须明确声明大幅降采样可能 alias，不能宣称 flux-conserving。

### 15.5 单位和守恒模式

至少区分：

- `surface_brightness`：插值权重归一，常数场保持，BUNIT 不变；
- `integrated_flux`：只有实现输出像素 footprint/solid angle 积分后才能启用；
- `unknown`：只允许无量纲几何重投影，不进行单位转换。

当前 alpha 可以继续显式拒绝 `flux-per-pixel`，但不能把点采样称作通量守恒。

### 15.6 order/LOD

当前代码计算 `order_sel`，但 sampler 仍按输入最深 `leaf_nside` 采样，因此 `order_sel` 主要写进 provenance，没有真正控制采样。下一版 `SamplingPlan` 必须把实际 order 传给 reader/sampler：

- 从 properties 读取真实 `hips_order` 和 `hips_tile_width`；
- 使用 HEALPix 像素固体角 `Ω=π/(3Nside²)` 推导等效角尺度；
- 根据输出 footprint 和 sampler 决定 LOD，而非只比较中心像素线性尺度；
- 读取所选 order 的真实 tile；若只有深层 tile，降级规则必须显式生成/平均，禁止假装已选低 order；
- manifest 同时写 requested/selected/actual source order 和理由。

### 15.7 流式内存和共享 cache

当前最大 20000×20000 输出同时分配 signal+coverage 两个 float 数组，单这两项约 3.2GB；每个 worker 又打开独立 sampler 和 cache。对 2C2G Linux 明显不可行，对 Windows 大图也不稳。

应改为：

```text
projection tile/row block
  → batch inverse WCS
  → shared read-through HiPS cache
  → sampler
  → bounded output block
  → 单 writer 顺序写临时 FITS
  → fsync/close/verify/atomic rename
```

cache 容量来自 Runtime memory lease，不由输出像素数推一个固定上限；多个 worker 共享只读 tile，禁止每 worker 复制完整 cache。missing tile、NaN value、geometric outside 和 coverage 应使用不同 mask/状态，不得都压成一个 0/1 coverage。

### 15.8 Phase3 独立验证矩阵

每个 projection 都必须有：

- Paper II/独立解析实现的 forward/inverse roundtrip；
- 中心、边缘、奇点附近、极区、RA 0/360 wrap 网格；
- FITS 1-based CRPIX、CTYPE、CRVAL、CD/PC、LONPOLE/LATPOLE/PV 校验；
- projection domain 外像素 mask；
- 常数球面场；
- 解析球谐/光滑场误差收敛；
- 点源/δ 场的位置和积分响应；
- equal-area projection 的 Jacobian/面积性质；
- HEALPix face/tile/order 边界连续性；
- missing tile、NaN、unknown BUNIT；
- 1 worker/N worker 结果一致；
- baseline/各 ISA 等价；
- 取消、磁盘满、原子写、超内存计划；
- 独立 FITS reader 重开和 WCS roundtrip；
- 大图 RSS 上界和 CPU 利用率。

## 16. 下一阶段建议实施顺序（设计方向，不是控制任务单）

### A. Truth Reset

- 将本轮负责人决定合并进正式 `AstroCS_ENGINEERING_CONSTRAINTS.md` 并提交 main；
- 重写极短 `AGENTS.md`：Linux 是 Agent 执行节点，Windows 是正式产品/发布平台；三个 Phase 独立；
- 重写根 README、REVIEW、memory、L0 状态；
- 把旧 Vxx 工程文档移到 `docs/history/`，旧控制包移到服务器 control/archive；
- 废除错误/过期 checker 的 PASS；
- 生成当前真实执行清单，不宣称 canonical 完成。

### B. Skeleton First

- 冻结 C ABI、module manifest、product manifest；
- 建立唯一根 CMake 和 Windows MSVC release preset；
- 建成安全 DLL loader、registry、Artifact service、日志/metrics/cancel；
- 建成单共享 executor 和真实 ThreadBudget；
- 用无科学意义的 fixture modules 验证 DLL 生命周期、端口、失败、取消、并发和 observed graph；
- 骨架未通过前不迁移全部科学算法。

### C. Module Migration

按科学风险和依赖逐个迁移：

1. I/O/HiPS/FITS；
2. calibration；
3. star/PSF/WCS/photometry/noise；
4. drizzle；
5. Phase2 coverage/sampling；
6. UPM fit/apply；
7. rejection/integration/writer；
8. Phase3 projection/resample/writer。

每迁一个模块：旧符号作对照但不反复跑历史整版；以 SCI/ALG、合成 Oracle、性质测试为主。节点 execute 唯一后才允许 registry 标为 ACTIVE。

### D. Windows Qualification

- Fatduck 安装并冻结工具链；
- MSVC Debug/Release、DLL ABI、自测、benchmark；
- Win10 22H2 和 Win11 兼容；
- 32R/银心真实数据仅在候选版本和相关接缝修复时运行；
- 每个 heavy node同时采集 CPU/RSS/I/O/线程；
- Phase2 接缝以专门合成 overlap/gradient/UPM 实验先定位，再用三板块真实图人工审核；
- 最后生成 Windows release bundle、SBOM、license、hash 和审核包。

## 17. 下一版控制包应具有的形态

本轮不生成控制包。下一版控制包应在负责人确认本文方向后拆成：

```text
00_READ_FIRST.md
01_OWNER_CONSTRAINTS.md
02_CURRENT_TRUTH.md
03_DEPENDENCY_GRAPH.yaml
04_FOREGROUND_RUNBOOK.md
05_AGENT_BINDINGS.yaml
tasks/
  governance_docs/*.yaml
  runtime/*.yaml
  io/*.yaml
  cpu/*.yaml
  phase1/<module>/*.yaml
  phase2/<module>/*.yaml
  phase3/<module>/*.yaml
checklists/
schemas/
validators/
package_policy/
```

每个 task 必须给固定 owner、允许路径、禁止路径、输入 SHA、前置任务、精确修改目标、不得改变的科学合同、命令、超时、预期输出、自动验收、失败分类、commit message、push 条件和审核包白名单。前台 Agent 不做科学自由发挥，只按图分发和验收。

## 18. 在出控制包前建议负责人冻结的两个默认选择

若无反对，建议下一轮按以下默认值编包：

1. Windows 最低正式兼容环境：Windows 10 22H2 x64；Windows 11 x64 为主发布环境；Linux x86_64 为 Tier 2。
2. Phase3 alpha REQUIRED projections：TAN、SIN、ZEA、CAR、AIT；`run` 要求显式选择，不做静默 auto；采样先实现 `nearest` 与科学定义清晰的 `healpix_interp4`。

这两个选择不影响当前对现状的否定结论，但会决定下一版任务拆分和 Windows 验收矩阵。

## 19. 最终判定

当前 `c169615... / 0.10.0-alpha.2` 可以作为下一轮重构输入基线，但不能作为发布候选基线。现有代码质量评价为：

- 科学算法遗产：有价值，但需逐模块重新挂接和验证；
- 架构基础：有雏形，生产接线未完成；
- 模块化：名义完成、实质未完成；
- 并行资源治理：合同和单测存在，生产路径未实现；
- 文档质量：数量充足，但当前状态、版本和实现一致性不合格；
- 机器检查：部分可复用，现有总 PASS 结论不可信；
- Windows 发布：未验证；
- Phase3：原型可复用，科学/算法/多投影/内存模型需重新设计。

因此下一轮的目标不应写成“继续 V6.1 剩余任务”，而应写成：

> 在不改变已冻结科学定义的前提下，把 AstroCS 从 Session 包装和历史多入口，迁移为 Windows-first、三 Phase 独立、真实 DLL 模块、统一资源执行器、模块自证和机器追溯的 Alpha 架构基线。
