#!/usr/bin/env python3
"""生产代码线程模型门禁；注释、测试和集中式 host 探测不计作生产违规。"""
from __future__ import annotations
import argparse,json,re
from pathlib import Path
def strip_comments(s):
    s=re.sub(r"/\*.*?\*/"," ",s,flags=re.S); return re.sub(r"//[^\n]*"," ",s)
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",required=True); ap.add_argument("--candidate-root",default=""); ap.add_argument("--json-out",default=""); ap.add_argument("--strict",action="store_true"); a=ap.parse_args(); target=Path(a.candidate_root or a.root).resolve(); errors=[]; warnings=[]
    if not a.candidate_root: return done(errors,warnings,a,{"design_mode":True})
    roots=("apps","include","runtime","modules","providers","lib","cli")
    files=[p for top in roots if (target/top).exists() for p in (target/top).rglob("*") if p.is_file() and p.suffix.lower() in {".c",".cc",".cpp",".cxx",".h",".hpp",".cmake"}]
    allow=("runtime/scheduler/","runtime/core/","lib/backend_host/")
    hits={}
    for p in files:
        rel=p.relative_to(target).as_posix(); t=strip_comments(p.read_text(encoding="utf-8",errors="replace"))
        if rel.startswith("tests/") or rel.startswith("tools/"): continue
        for name,pat in {"private_pool":r"(ThreadPool|thread_pool|create_thread_pool|workers_\\s*=\\s*[0-9]+)","bypass_lease":r"(std::async|std::thread|ThreadLease::make|omp_set_num_threads)","fixed_worker":r"\\bworkers?\\s*=\\s*[0-9]+","direct_hw_probe":r"hardware_concurrency\\s*\\("}.items():
            if re.search(pat,t,re.I): hits.setdefault(name,[]).append(rel)
    for name,paths in hits.items():
        bad=[x for x in paths if not x.startswith(allow)]
        if name in {"private_pool","bypass_lease","fixed_worker"} and bad: errors.append(name+": "+",".join(sorted(bad)))
        elif name=="direct_hw_probe" and bad: warnings.append("direct hardware probe outside host: "+",".join(sorted(bad)))
    if not any("ThreadBudget" in strip_comments(p.read_text(encoding="utf-8",errors="replace")) for p in files): errors.append("ThreadBudget absent")
    return done(errors,warnings,a,{"scanned_files":len(files),"hits":{k:len(v) for k,v in hits.items()}})
def done(errors,warnings,a,extra):
    rep={"checker":"THREAD_BUDGET","status":"FAIL" if errors or (a.strict and warnings) else "PASS","errors":errors,"warnings":warnings}; rep.update(extra)
    if a.json_out: Path(a.json_out).write_text(json.dumps(rep,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    for x in errors: print("ERROR",x)
    print("THREAD_BUDGET_FAIL" if errors or (a.strict and warnings) else "THREAD_BUDGET_PASS")
    return 1 if errors or (a.strict and warnings) else 0
if __name__=="__main__": raise SystemExit(main())
