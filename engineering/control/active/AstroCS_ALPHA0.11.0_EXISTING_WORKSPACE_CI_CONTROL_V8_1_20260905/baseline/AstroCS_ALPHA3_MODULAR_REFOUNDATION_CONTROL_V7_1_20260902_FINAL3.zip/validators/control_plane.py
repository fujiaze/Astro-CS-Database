#!/usr/bin/env python3
"""可执行控制面：状态初始化、READY/DISPATCH、结果/范围校验、rebase 和 Gate 重算。"""
from __future__ import annotations
import argparse, csv, fnmatch, hashlib, json, re, sys
from datetime import datetime, timezone
from pathlib import Path
from common import validate_instance

STATES={"NOT_STARTED","READY","DISPATCHED","RETURNED","INTEGRATED","CLOSED","FAIL","BLOCKED","WAITING_RESOURCE","REBASE_REQUIRED","SUPERSEDED"}
TERMINAL={"CLOSED","BLOCKED","SUPERSEDED"}
def sha(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(1048576),b""): h.update(b)
    return h.hexdigest()
def rows(root):
    with (root/"TASK_LEDGER.csv").open(newline="",encoding="utf-8") as f: return list(csv.DictReader(f))
def owners(root):
    text=(root/"05_FIXED_SUBAGENT_BINDINGS.yaml").read_text(encoding="utf-8")
    return {x for x in re.findall(r"id:\s*(SA-[A-Z0-9-]+|FG-[A-Z0-9-]+)",text)}
def load_state(p):
    return json.loads(p.read_text(encoding="utf-8"))
def write(p,obj):
    p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(obj,ensure_ascii=False,indent=2,sort_keys=True)+"\n",encoding="utf-8")
def rowmap(root): return {r["task_id"]:r for r in rows(root)}
def main():
    ap=argparse.ArgumentParser()
    sub=ap.add_subparsers(dest="op",required=True)
    for n in ("init-state","ready","dispatch","validate-result","scope","rebase","gates"): sub.add_parser(n)
    sub.choices["init-state"].add_argument("--root",required=True); sub.choices["init-state"].add_argument("--state",required=True); sub.choices["init-state"].add_argument("--main-sha",required=True)
    sub.choices["ready"].add_argument("--root",required=True); sub.choices["ready"].add_argument("--state",required=True)
    d=sub.choices["dispatch"]; d.add_argument("--root",required=True); d.add_argument("--state",required=True); d.add_argument("--task-id",required=True); d.add_argument("--base-sha",required=True); d.add_argument("--output",required=True)
    vr=sub.choices["validate-result"]; vr.add_argument("--root",required=True); vr.add_argument("--result",required=True)
    sc=sub.choices["scope"]; sc.add_argument("--root",required=True); sc.add_argument("--owner-id",required=True); sc.add_argument("--paths",required=True)
    rb=sub.choices["rebase"]; rb.add_argument("--root",required=True); rb.add_argument("--state",required=True); rb.add_argument("--current-sha",required=True)
    g=sub.choices["gates"]; g.add_argument("--root",required=True); g.add_argument("--state",required=True); g.add_argument("--output",required=True); g.add_argument("--evidence-dir",default="")
    a=ap.parse_args(); root=Path(getattr(a,"root","")).resolve() if hasattr(a,"root") else None
    if a.op=="init-state":
        if not re.fullmatch(r"[0-9a-f]{40}",a.main_sha): return fail("invalid main sha")
        ledger=root/"TASK_LEDGER.csv"; state={"ledger_sha256":sha(ledger),"main_sha":a.main_sha,"updated_utc":datetime.now(timezone.utc).isoformat(),"tasks":[]}
        for r in rows(root): state["tasks"].append({"task_id":r["task_id"],"status":"NOT_STARTED","attempt":0,"owner_id":r["owner_id"],"dispatch_id":None,"result_path":None,"integrated_main_sha":None,"evidence_ids":[]})
        write(Path(a.state),state); print("TASK_STATE_INITIALIZED",len(state["tasks"])); return 0
    state=load_state(Path(a.state)) if hasattr(a,"state") else None; rm=rowmap(root)
    if a.op=="ready":
        ready=[]
        for x in state["tasks"]:
            if x["status"] not in {"NOT_STARTED","RETURNED","REBASE_REQUIRED"}: continue
            r=rm.get(x["task_id"]); deps=[z for z in (r.get("depends_on","") or "").split(";") if z and z!="-"]
            by={y["task_id"]:y["status"] for y in state["tasks"]}
            if all(by.get(dep)=="CLOSED" for dep in deps): ready.append(x["task_id"])
        print(json.dumps({"ready":sorted(ready)},ensure_ascii=False)); return 0
    if a.op=="dispatch":
        x=next((z for z in state["tasks"] if z["task_id"]==a.task_id),None); r=rm.get(a.task_id)
        if not x or not r: return fail("unknown task")
        if x["status"] not in {"READY","NOT_STARTED","RETURNED","REBASE_REQUIRED"}: return fail("task not dispatchable: "+x["status"])
        deps=[z for z in (r.get("depends_on","") or "").split(";") if z and z!="-"]; by={z["task_id"]:z["status"] for z in state["tasks"]}
        if not all(by.get(dep)=="CLOSED" for dep in deps): return fail("dependencies not closed")
        spec=root/r["spec_ref"]; obj={"dispatch_id":"DSP-"+datetime.now(timezone.utc).strftime("%Y%m%d-%H%M"),"task_id":a.task_id,"owner_id":r["owner_id"],"base_main_sha":a.base_sha,"mode":"read_only" if r["kind"] in {"audit","evidence"} else "write_patch","resource_class":r["resource_class"],"mutex_lock":r["mutex_lock"],"inputs":[],"outputs":[r["acceptance"]],"acceptance":[r["acceptance"]],"timeout_seconds":1800,"forbidden_actions":["push","branch","force push","relax tolerance","modify other owner paths"],"spec_sha256":sha(spec)}
        write(Path(a.output),obj); x["status"]="DISPATCHED"; x["dispatch_id"]=obj["dispatch_id"]; x["base_main_sha"]=a.base_sha; x["attempt"]+=1; write(Path(a.state),state); print("DISPATCH_WRITTEN",a.task_id); return 0
    if a.op=="validate-result":
        obj=json.loads(Path(a.result).read_text(encoding="utf-8")); r=rm.get(obj.get("task_id",""))
        if not r: return fail("result unknown task")
        schema=json.loads((root/"schemas/task_result.schema.json").read_text(encoding="utf-8"))
        schema_errors=validate_instance(obj,schema)
        if schema_errors: return fail("task_result schema: "+"; ".join(schema_errors[:8]))
        if obj.get("owner_id")!=r["owner_id"]: return fail("result owner mismatch")
        if not re.fullmatch(r"[0-9a-f]{40}",obj.get("base_main_sha","")): return fail("invalid base_main_sha")
        forbidden={"result_main_sha","integrated_main_sha","commit","push"}
        if forbidden & obj.keys(): return fail("SubAgent result contains foreground-only field")
        for k in ("changed_files_digest","review_notes","scope_clean","scientific_change"): 
            if k not in obj: return fail("missing "+k)
        if not isinstance(obj["scope_clean"],bool): return fail("scope_clean must be boolean")
        print("TASK_RESULT_PASS",obj["task_id"]); return 0
    if a.op=="scope":
        text=(root/"05_FIXED_SUBAGENT_BINDINGS.yaml").read_text(encoding="utf-8"); blocks=text.split("  - {id:")
        block=next((b for b in blocks if b.startswith(a.owner_id+",")),None)
        if not block: return fail("owner not found")
        allowed=re.findall(r'"([^"]+)"',block.split("}",1)[0].split("write:",1)[-1] if "write:" in block else "")
        bad=[]
        for path in Path(a.paths).read_text(encoding="utf-8").splitlines():
            path=path.strip()
            if path and not any(fnmatch.fnmatch(path,g) or fnmatch.fnmatch(path,g.rstrip("*")) for g in allowed): bad.append(path)
        if bad: return fail("out of owner allowlist: "+",".join(bad))
        print("SCOPE_PASS"); return 0
    if a.op=="rebase":
        changed=[]
        for x in state["tasks"]:
            if x["status"] in {"DISPATCHED","RETURNED"} and x.get("base_main_sha") and x["base_main_sha"]!=a.current_sha:
                x["status"]="REBASE_REQUIRED"; changed.append(x["task_id"])
        state["main_sha"]=a.current_sha; state["updated_utc"]=datetime.now(timezone.utc).isoformat()
        write(Path(a.state),state); print(json.dumps({"rebase_required":sorted(changed)},ensure_ascii=False)); return 0
    if a.op=="gates":
        by={z["task_id"]:z for z in state["tasks"]}
        evid={}; current_open=[]
        if a.evidence_dir:
            edir=Path(a.evidence_dir)
            index=edir/"evidence_index.csv"
            if index.exists():
                with index.open(newline="",encoding="utf-8") as f:
                    for e in csv.DictReader(f):
                        if e.get("evidence_id"): evid[e["evidence_id"]]=e
            findings=edir/"findings.csv"
            if findings.exists():
                with findings.open(newline="",encoding="utf-8") as f:
                    for fnd in csv.DictReader(f):
                        if fnd.get("status","").upper() not in {"CLOSED","RESOLVED","PASS"}:
                            current_open.append(fnd)
        req={}
        gatefile=root/"GATE_REQUIREMENTS.csv"
        if not gatefile.exists(): return fail("GATE_REQUIREMENTS.csv missing")
        with gatefile.open(newline="",encoding="utf-8") as f:
            for row in csv.DictReader(f): req[row["gate_id"]]=[x for x in row.get("required_tasks","").split(";") if x]
        out=[]
        aliases={r["task_id"]:r.get("alias_of","") for r in rows(root)}
        def evidence_for(tid, seen=None):
            seen=seen or set()
            if tid in seen: return []
            seen.add(tid)
            direct=by.get(tid,{}).get("evidence_ids",[]) or []
            if direct: return direct
            alias=aliases.get(tid,"")
            return evidence_for(alias,seen) if alias else []
        for gid,tasks in req.items():
            per_task={t:evidence_for(t) for t in tasks}
            ids=sorted({e for values in per_task.values() for e in values})
            stale=[e for e in ids if e not in evid or evid[e].get("main_sha")!=state["main_sha"] or evid[e].get("status","").upper()!="PASS"]
            missing_tasks=[t for t,values in per_task.items() if not values]
            missing_evidence=not a.evidence_dir or bool(missing_tasks)
            ok=all(by.get(t,{}).get("status")=="CLOSED" for t in tasks) and not missing_evidence and not stale and not current_open
            reason="evidence_dir_not_provided" if not a.evidence_dir else ("task_without_evidence:"+",".join(missing_tasks) if missing_tasks else ("stale_or_missing_evidence" if stale else ("open_findings" if current_open else "")))
            out.append({"gate_id":gid,"main_sha":state["main_sha"],"status":"PASS" if ok else "NOT_READY","required_tasks":tasks,"evidence_ids":ids,"open_p0":sum(f.get("severity")=="P0" for f in current_open),"open_p1":sum(f.get("severity")=="P1" for f in current_open),"computed_at":datetime.now(timezone.utc).isoformat(),"reason":reason})
        verdict="READY_FOR_OWNER_REVIEW" if all(g["status"]=="PASS" for g in out) and not current_open else "NOT_READY"
        write(Path(a.output),{"gates":out,"verdict":verdict,"computed_from":"TASK_STATE.json+evidence_index.csv+findings.csv"}); print("GATES_RECOMPUTED",len(out),verdict); return 0
def fail(msg):
    print("CONTROL_PLANE_FAIL",msg); return 1
if __name__=="__main__": raise SystemExit(main())
