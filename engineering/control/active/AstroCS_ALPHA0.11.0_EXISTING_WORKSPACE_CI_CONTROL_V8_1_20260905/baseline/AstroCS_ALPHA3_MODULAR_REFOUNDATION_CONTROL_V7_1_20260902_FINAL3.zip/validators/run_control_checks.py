#!/usr/bin/env python3
"""运行控制包设计阶段全部可执行检查；不运行源码重计算。"""
from __future__ import annotations
import argparse,subprocess,sys,os
from pathlib import Path
def main()->int:
    p=argparse.ArgumentParser(); p.add_argument("--root",default=str(Path(__file__).resolve().parents[1])); p.add_argument("--json-dir",default=""); a=p.parse_args(); root=Path(a.root).resolve(); v=Path(__file__).resolve().parent; failures=[]
    checks=["validate_control.py","validate_tasks.py","validate_docs.py","validate_traceability.py","validate_module_contracts.py","validate_abi_manifest.py","validate_dag_phase.py","validate_thread_budget.py","validate_cpu_providers.py","validate_results.py","validate_templates.py","selftest.py"]
    for name in checks:
        cmd=[sys.executable,str(v/name),"--root",str(root)]
        if name=="selftest.py": cmd=[sys.executable,str(v/name)]
        if a.json_dir and name!="selftest.py": cmd += ["--json-out",str(Path(a.json_dir)/(name.replace(".py",".json")))]
        print("RUN", " ".join(cmd)); env=dict(os.environ); env["PYTHONDONTWRITEBYTECODE"]="1"; r=subprocess.run(cmd,cwd=root,text=True,env=env)
        if r.returncode!=0: failures.append(name)
    if failures:
        print("CONTROL_SUITE_FAIL", ",".join(failures)); return 1
    print(f"CONTROL_SUITE_PASS checks={len(checks)}"); return 0
if __name__=="__main__": raise SystemExit(main())
