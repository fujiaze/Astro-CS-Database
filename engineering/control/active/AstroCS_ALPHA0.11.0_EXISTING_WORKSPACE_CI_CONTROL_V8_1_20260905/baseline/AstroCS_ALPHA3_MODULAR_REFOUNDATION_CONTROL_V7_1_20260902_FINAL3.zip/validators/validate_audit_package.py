#!/usr/bin/env python3
"""最终审核包严格校验：白名单、源快照、逐字节 SHA、计数、容量和安全路径。"""
from __future__ import annotations
import argparse,hashlib,json,re,tarfile
from pathlib import Path
def digest(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda:f.read(1048576),b""): h.update(b)
    return h.hexdigest()
REQUIRED=["00_READ_FIRST.md","REVIEW_MANIFEST.json","SHA256SUMS","source/SOURCE_MANIFEST.json","source/source_tree.tar.gz","evidence/SUMMARY.json","evidence/identity.json","evidence/host_toolchain.json","evidence/task_ledger_snapshot.csv","evidence/gate_results.json","evidence/evidence_index.csv","evidence/findings.csv","evidence/traceability.csv","docs/L0_OWNER_REVIEW.md","docs/L1_ENGINEERING_STATUS.md","docs/L2_SCIENCE_ALGORITHM_INDEX.md","docs/L3_MACHINE_TRACEABILITY.md","configs/product_manifest.json","references/references.lock.json","provenance/build_commands.json"]
TEXT={".md",".json",".csv",".txt",".yaml",".yml",".rst",".toml"}
ALLOWED_PREFIXES=("00_READ_FIRST.md","REVIEW_MANIFEST.json","SHA256SUMS","evidence/","source/","docs/","configs/","tests/","references/","provenance/")
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",required=True); ap.add_argument("--json-out",default=""); ap.add_argument("--strict",action="store_true"); a=ap.parse_args(); root=Path(a.root).resolve(); errors=[]; warnings=[]
    if not root.is_dir(): return done(errors+["root not directory"],warnings,a,{})
    allpaths={p.relative_to(root).as_posix():p for p in root.rglob("*") if p.is_file()}
    if any(p.is_symlink() for p in root.rglob("*")): errors.append("symlink present")
    total=sum(p.stat().st_size for p in allpaths.values())
    if total>50*1024*1024: errors.append("review package exceeds 50 MiB")
    for rel,p in allpaths.items():
        low=rel.lower()
        if not any(rel==prefix or rel.startswith(prefix) for prefix in ALLOWED_PREFIXES): errors.append("path outside audit allowlist: "+rel)
        if rel not in {"source/source_tree.tar.gz","SHA256SUMS"} and (low.endswith((".zip",".tar",".tar.gz",".tgz",".fits",".fit",".fz",".pdb",".dmp")) or any(x in p.parts for x in {".git","build","out","install","testdata","__pycache__"})): errors.append("forbidden artifact/path: "+rel)
        if p.suffix.lower() in TEXT:
            t=p.read_text(encoding="utf-8",errors="replace")
            if re.search(r"(?i)(password|secret|api[_-]?key|access[_-]?token)\s*[:=]",t): errors.append("possible secret: "+rel)
            if re.search(r"(?i)([A-Z]:[\\\\/]|/home/|/Users/|/root/)",t): errors.append("absolute path: "+rel)
    for rel in REQUIRED:
        if rel not in allpaths: errors.append("missing required: "+rel)
    if allpaths.get("source/source_tree.tar.gz"):
        try:
            with tarfile.open(allpaths["source/source_tree.tar.gz"],"r:gz") as z:
                names=set()
                for m in z.getmembers():
                    if m.issym() or m.islnk(): errors.append("source archive link: "+m.name)
                    if m.name.startswith("/") or ".." in Path(m.name).parts: errors.append("source archive traversal: "+m.name)
                    if m.name in names: errors.append("source archive duplicate: "+m.name)
                    names.add(m.name)
                    if m.size>5*1024*1024: errors.append("source member >5 MiB: "+m.name)
        except Exception as exc: errors.append("source archive invalid: "+str(exc))
    manifest=allpaths.get("REVIEW_MANIFEST.json")
    if manifest:
        try:
            m=json.loads(manifest.read_text(encoding="utf-8")); records={x["path"]:x for x in m.get("files",[])}
            if m.get("package_format")!="astrocs-review-v2": errors.append("package_format mismatch")
            if m.get("product_version")!="0.11.0-alpha.1": errors.append("product version mismatch")
            if not re.fullmatch(r"[0-9a-f]{40}",m.get("source_commit","")): errors.append("source_commit invalid")
            if set(records)!=(set(allpaths)-{"REVIEW_MANIFEST.json","SHA256SUMS"}): errors.append("REVIEW_MANIFEST file set mismatch")
            for rel,p in allpaths.items():
                if rel in {"REVIEW_MANIFEST.json","SHA256SUMS"}: continue
                x=records.get(rel,{})
                if x.get("size_bytes")!=p.stat().st_size or x.get("sha256")!=digest(p): errors.append("REVIEW_MANIFEST hash/size mismatch: "+rel)
        except Exception as exc: errors.append("REVIEW_MANIFEST invalid: "+str(exc))
    sums=allpaths.get("SHA256SUMS")
    if sums:
        got={}
        for no,line in enumerate(sums.read_text(encoding="utf-8").splitlines(),1):
            x=line.split("  ",1)
            if len(x)!=2 or not re.fullmatch(r"[0-9a-f]{64}",x[0]): errors.append(f"bad SHA256SUMS line {no}"); continue
            if x[1] in got: errors.append("duplicate SHA path "+x[1])
            got[x[1]]=x[0]
        expected=set(allpaths)-{"SHA256SUMS"}
        if set(got)!=expected: errors.append("SHA256SUMS file set mismatch")
        for rel in expected:
            if got.get(rel)!=digest(allpaths[rel]): errors.append("SHA mismatch "+rel)
    try:
        sm=json.loads(allpaths["source/SOURCE_MANIFEST.json"].read_text(encoding="utf-8"))
        if not re.fullmatch(r"[0-9a-f]{40}",sm.get("source_commit","")): errors.append("source manifest commit invalid")
        if not isinstance(sm.get("files"),list) or not sm["files"]: errors.append("source manifest files empty")
        for x in sm.get("files",[]):
            if not re.fullmatch(r"[0-9a-f]{64}",x.get("sha256","")): errors.append("source manifest bad hash")
    except Exception as exc: errors.append("source manifest invalid: "+str(exc))
    try:
        summary=json.loads(allpaths["evidence/SUMMARY.json"].read_text(encoding="utf-8"))
        if summary.get("verdict") not in {"READY_FOR_OWNER_REVIEW","NOT_READY","BLOCKED_EXTERNAL","PACKAGE_INVALID"}: errors.append("invalid verdict")
        counts=summary.get("counts",{})
        if not isinstance(counts,dict): errors.append("summary counts not object")
    except Exception as exc: errors.append("summary invalid: "+str(exc))
    return done(errors,warnings,a,{"file_count":len(allpaths),"total_bytes":total})
def done(errors,warnings,a,extra):
    rep={"checker":"AUDIT_PACKAGE","status":"FAIL" if errors or (a.strict and warnings) else "PASS","errors":errors,"warnings":warnings}; rep.update(extra)
    if a.json_out: Path(a.json_out).write_text(json.dumps(rep,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    for e in errors: print("ERROR",e)
    print("AUDIT_PACKAGE_FAIL" if errors or (a.strict and warnings) else "AUDIT_PACKAGE_PASS")
    return 1 if errors or (a.strict and warnings) else 0
if __name__=="__main__": raise SystemExit(main())
