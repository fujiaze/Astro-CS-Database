#!/usr/bin/env python3
"""模板与 JSON schema 的结构闭合检查。"""
from __future__ import annotations
import argparse,json
from pathlib import Path
from common import validate_instance
PAIRS={"DISPATCH.json":"dispatch.schema.json","TASK_RESULT.json":"task_result.schema.json","TASK_STATE.json":"task_state.schema.json","EVIDENCE_RECORD.json":"evidence_record.schema.json","INDEPENDENT_FINDING.json":"finding.schema.json"}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",required=True); ap.add_argument("--json-out",default=""); ap.add_argument("--strict",action="store_true"); a=ap.parse_args(); root=Path(a.root); errors=[]; checked=0
    for t,s in PAIRS.items():
        try:
            tv=json.loads((root/"templates"/t).read_text(encoding="utf-8")); sv=json.loads((root/"schemas"/s).read_text(encoding="utf-8")); checked+=1
            props=set(sv.get("properties",{})); keys=set(tv)
            extra=keys-props
            if extra: errors.append(f"{t}: unknown schema properties {sorted(extra)}")
            missing=set(sv.get("required",[]))-keys
            if missing: errors.append(f"{t}: missing required template keys {sorted(missing)}")
            if t=="TASK_RESULT.json" and {"result_main_sha","integrated_main_sha","commit","push"} & keys: errors.append("TASK_RESULT contains foreground-only field")
            errors.extend(validate_instance(tv, sv, t, allow_placeholders=True))
        except Exception as exc: errors.append(f"{t}/{s}: {exc}")
    rep={"checker":"TEMPLATES","status":"FAIL" if errors else "PASS","errors":errors,"checked":checked}
    if a.json_out: (root/a.json_out).write_text(json.dumps(rep,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    for e in errors: print("ERROR",e)
    print("TEMPLATES_FAIL" if errors else "TEMPLATES_PASS",f"checked={checked}")
    return 1 if errors else 0
if __name__=="__main__": raise SystemExit(main())
