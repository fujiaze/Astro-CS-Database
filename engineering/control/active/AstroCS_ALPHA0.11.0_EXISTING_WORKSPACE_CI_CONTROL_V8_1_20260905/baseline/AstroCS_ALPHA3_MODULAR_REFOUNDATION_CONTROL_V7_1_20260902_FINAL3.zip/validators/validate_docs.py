#!/usr/bin/env python3
"""控制包文档结构/版本/可读性预检；候选源码审计时可复用。"""
from __future__ import annotations
import re
from pathlib import Path
from common import root_arg, finish, rel_files
def main()->int:
    parser=root_arg("AstroCS active document checker")
    parser.add_argument("--candidate-root", default="", help="候选源码根；提供后扫描 active 文档内容")
    args=parser.parse_args(); root=Path(args.root).resolve(); target=Path(args.candidate_root).resolve() if args.candidate_root else root; errors=[]; warnings=[]
    for n in range(23):
        p=root/("START_PROMPT.txt" if n==0 else f"{n:02d}_" )
        if n==0: continue
    required=["00_READ_FIRST.md","01_OWNER_FROZEN_CONSTRAINTS.md","03_TARGET_PRODUCT_AND_ARCHITECTURE.md","07_CHECKPOINTS_AND_GATES.md","16_SCIENCE_DOCUMENT_AND_TRACEABILITY_STANDARD.md"]
    for rel in required:
        p=root/rel
        if not p.exists(): errors.append(f"missing active contract: {rel}")
        elif len(p.read_text(encoding="utf-8"))<200: errors.append(f"document too short: {rel}")
    # 控制包规范本身必须讨论违规路径/旧版本，因此设计模式不把这些文字误报为候选源码问题。
    if args.candidate_root:
        active_index=target/"docs/DOCUMENT_INDEX.yaml"
        if not active_index.exists(): errors.append("candidate missing docs/DOCUMENT_INDEX.yaml")
        for pth in target.rglob("*"):
            if not pth.is_file() or pth.suffix.lower() not in {".md",".yaml",".yml",".txt",".rst"}: continue
            rel=pth.relative_to(target).as_posix(); text=pth.read_text(encoding="utf-8",errors="replace")
            if "/archive/" in f"/{rel}" or rel.startswith("docs/archive/") or rel.startswith("engineering/control/archive/"): continue
            if re.search(r"(?i)(C:\\\\|[A-Z]:/|/home/|/Users/|F:/)",text): warnings.append(f"absolute path mention: {rel}")
            if re.search(r"(?i)\b(V18|V19|V4|V5|V6|R18|R19)\b",text): warnings.append(f"legacy version in active candidate doc: {rel}")
            if "TODO" in text: warnings.append(f"TODO in active candidate doc: {rel}")
    mod=root/"templates/MODULE_README.md"
    for section in ["负责范围","输入与输出","合同链接","实现事实","并发与资源","验证"]:
        if mod.exists() and section not in mod.read_text(encoding="utf-8"): errors.append(f"module template missing section {section}")
    report={"file_count":sum(1 for _ in rel_files(root)),"required_active_docs":len(required)}
    return finish("DOCS",errors,warnings,report,args.json_out,args.strict)
if __name__=="__main__":
    try: raise SystemExit(main())
    except Exception as exc:
        print(f"DOCS_TOOLING_FAILURE {type(exc).__name__}: {exc}"); raise
