#!/usr/bin/env python3
"""任务台账严格检查：唯一 ID、owner/spec、状态机、单调波次、DAG/Gate 闭合和提交语义。"""
from __future__ import annotations
import argparse,csv,re
from pathlib import Path
STATES={"NOT_STARTED","READY","DISPATCHED","RETURNED","INTEGRATED","CLOSED","FAIL","BLOCKED","WAITING_RESOURCE","REBASE_REQUIRED","SUPERSEDED"}
MODULE_PREFIXES={"CAT-GAIA","P1-CAL","P1-COS","P1-STAR","P1-PSF","P1-WCS","P1-PHOT","P1-NOISE","P1-DRZ","P1-HIPS","P2-COV","P2-SAMP","P2-UPM","P2-REJ","P2-INT","P2-HIPS","P3-PROJ","P3-RSMP","P3-FITS","P1-SESSION","P2-SESSION"}
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",required=True); ap.add_argument("--json-out",default=""); ap.add_argument("--strict",action="store_true"); a=ap.parse_args(); root=Path(a.root).resolve(); errors=[]; warnings=[]
    lp=root/"TASK_LEDGER.csv"; op=root/"05_FIXED_SUBAGENT_BINDINGS.yaml"
    if not lp.exists(): return finish(errors+["missing TASK_LEDGER.csv"],warnings,a)
    try:
        with lp.open(newline="",encoding="utf-8") as f: rs=list(csv.DictReader(f))
    except Exception as e: return finish(errors+["ledger parse failure: "+str(e)],warnings,a)
    ids=[r.get("task_id","") for r in rs]; idset=set(ids)
    if not rs or len(ids)!=len(idset): errors.append("empty or duplicate task_id")
    own=set(re.findall(r"id:\s*(SA-[A-Z0-9-]+|FG-[A-Z0-9-]+)",op.read_text(encoding="utf-8") if op.exists() else ""))
    waves={}
    for r in rs:
        tid=r.get("task_id",""); owner=r.get("owner_id",""); depstr=r.get("depends_on","") or ""
        if owner not in own: errors.append(f"{tid}: owner not frozen: {owner}")
        try: waves[tid]=int(str(r.get("wave","W-1")).lstrip("W"))
        except Exception: errors.append(f"{tid}: invalid wave")
        if r.get("resource_class") not in {"LINUX_LIGHT","WINDOWS_HEAVY","STATIC_READ"}: errors.append(f"{tid}: invalid resource class")
        if r.get("kind") in {"audit","evidence","gate"} and r.get("commit_subject") not in {"no-commit","evidence-only"}: errors.append(f"{tid}: audit/evidence task cannot commit")
        if r.get("commit_subject") not in {"no-commit","evidence-only"} and not re.search(r"[一-龥]",r.get("commit_subject","")): errors.append(f"{tid}: commit subject lacks Chinese purpose")
        for d in filter(None,depstr.split(";")):
            if d=="-": continue
            if re.fullmatch(r"G[0-8]",d): errors.append(f"{tid}: task may not depend on computed Gate {d}")
            elif d not in idset: errors.append(f"{tid}: unknown dependency {d}")
    for r in rs:
        tid=r["task_id"]
        for d in filter(None,(r.get("depends_on","") or "").split(";")):
            if d in waves and waves[d]>waves.get(tid,999): errors.append(f"later-wave dependency {tid}(W{waves[tid]}) -> {d}(W{waves[d]})")
    graph={r["task_id"]:[d for d in (r.get("depends_on","") or "").split(";") if d in idset] for r in rs}; visiting=set(); done=set()
    def visit(n):
        if n in visiting: errors.append("DAG cycle at "+n); return
        if n in done: return
        visiting.add(n)
        for d in graph[n]: visit(d)
        visiting.remove(n); done.add(n)
    for n in graph: visit(n)
    def reaches(start,target,seen=None):
        seen=seen or set()
        if start==target: return True
        if start in seen: return False
        seen.add(start)
        return any(reaches(x,target,seen) for x in graph.get(start,[]))
    for prefix in MODULE_PREFIXES:
        for suffix in ("DOC","TEST","IMPL","INT"):
            tid=f"{prefix}-{suffix}"
            if tid not in idset: errors.append("missing module task "+tid)
        if f"{prefix}-DOC" in idset:
            doc=next(r for r in rs if r["task_id"]==f"{prefix}-DOC")
            for suffix in ("TEST","IMPL","INT"):
                t=next((x for x in rs if x["task_id"]==f"{prefix}-{suffix}"),None)
                if t and not reaches(t["task_id"],f"{prefix}-DOC"): errors.append(f"{t['task_id']}: does not transitively depend on DOC")
    gatefile=root/"GATE_REQUIREMENTS.csv"
    # Gate references, if supplied, must be existing tasks and must not introduce dependency cycles.
    if gatefile.exists():
        with gatefile.open(newline="",encoding="utf-8") as f:
            for x in csv.DictReader(f):
                for t in filter(None,(x.get("required_tasks","") or "").split(";")):
                    if t not in idset: errors.append(f"{x.get('gate_id')}: unknown required task {t}")
    return finish(errors,warnings,a,{"row_count":len(rs),"task_count":len(idset),"owner_count":len(own)})
def finish(errors,warnings,a,extra=None):
    rep={"checker":"TASK_LEDGER","status":"FAIL" if errors or (a.strict and warnings) else "PASS","errors":errors,"warnings":warnings}; rep.update(extra or {})
    if a.json_out: Path(a.json_out).write_text(__import__("json").dumps(rep,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    for x in errors: print("ERROR",x)
    for x in warnings: print("WARN",x)
    print("TASK_LEDGER_FAIL" if errors or (a.strict and warnings) else "TASK_LEDGER_PASS",f"tasks={rep.get('task_count',0)}")
    return 1 if errors or (a.strict and warnings) else 0
if __name__=="__main__": raise SystemExit(main())
