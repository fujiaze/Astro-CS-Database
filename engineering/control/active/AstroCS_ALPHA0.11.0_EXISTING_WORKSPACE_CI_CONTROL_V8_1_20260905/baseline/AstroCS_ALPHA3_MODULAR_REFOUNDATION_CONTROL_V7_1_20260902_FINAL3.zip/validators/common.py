#!/usr/bin/env python3
"""V7 控制包校验器公共函数；仅依赖 Python 标准库。"""
from __future__ import annotations
import argparse, hashlib, json, os, re, sys
from pathlib import Path

def root_arg(description: str) -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=description)
    p.add_argument("--root", default=str(Path(__file__).resolve().parents[1]), help="控制包或审核包根目录")
    p.add_argument("--json-out", default="", help="可选 JSON 报告路径")
    p.add_argument("--strict", action="store_true", help="严格模式；任一警告也失败")
    return p

def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def rel_files(root: Path):
    for p in sorted(root.rglob("*")):
        if p.is_file():
            yield p.relative_to(root).as_posix(), p

def load_json(path: Path):
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)

def validate_instance(value, schema: dict, path: str = "$", allow_placeholders: bool = False) -> list[str]:
    """标准库最小 JSON-Schema 实例检查，覆盖本控制包使用的约束。"""
    errors = []
    if allow_placeholders and isinstance(value, str) and "<" in value and ">" in value:
        return errors
    expected = schema.get("type")
    types = expected if isinstance(expected, list) else [expected] if expected else []
    def matches(t):
        return {"object": isinstance(value, dict), "array": isinstance(value, list),
                "string": isinstance(value, str), "integer": isinstance(value, int) and not isinstance(value, bool),
                "number": isinstance(value, (int, float)) and not isinstance(value, bool),
                "boolean": isinstance(value, bool), "null": value is None}.get(t, True)
    if types and not any(matches(t) for t in types): return [f"{path}: expected {expected}"]
    if "const" in schema and value != schema["const"]: errors.append(f"{path}: const mismatch")
    if "enum" in schema and value not in schema["enum"]: errors.append(f"{path}: enum mismatch")
    if isinstance(value, str):
        if len(value) < schema.get("minLength", 0): errors.append(f"{path}: shorter than minLength")
        pat = schema.get("pattern")
        if pat and not (allow_placeholders and "<" in value and ">" in value) and not re.search(pat, value): errors.append(f"{path}: pattern mismatch")
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if "minimum" in schema and value < schema["minimum"]: errors.append(f"{path}: below minimum")
        if "maximum" in schema and value > schema["maximum"]: errors.append(f"{path}: above maximum")
    if isinstance(value, list):
        if len(value) < schema.get("minItems", 0): errors.append(f"{path}: fewer than minItems")
        if "items" in schema:
            for i, item in enumerate(value): errors.extend(validate_instance(item, schema["items"], f"{path}[{i}]", allow_placeholders))
    if isinstance(value, dict):
        for key in schema.get("required", []):
            if key not in value: errors.append(f"{path}: missing required {key}")
        props = schema.get("properties", {})
        if schema.get("additionalProperties") is False:
            for key in value:
                if key not in props: errors.append(f"{path}: unknown property {key}")
        for key, subschema in props.items():
            if key in value: errors.extend(validate_instance(value[key], subschema, f"{path}.{key}", allow_placeholders))
    return errors

def write_report(path: str, payload: dict):
    if path:
        out = Path(path)
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")

def finish(name: str, errors: list[str], warnings: list[str], report: dict, json_out: str, strict: bool = False) -> int:
    report.update({"checker": name, "errors": errors, "warnings": warnings, "status": "FAIL" if errors or (strict and warnings) else "PASS"})
    write_report(json_out, report)
    for x in errors:
        print(f"ERROR {x}")
    for x in warnings:
        print(f"WARN {x}")
    if errors or (strict and warnings):
        print(f"{name}_FAIL errors={len(errors)} warnings={len(warnings)}")
        return 1
    print(f"{name}_PASS files={report.get('file_count', 0)}")
    return 0

def is_sha256(value: str) -> bool:
    return bool(re.fullmatch(r"[0-9a-fA-F]{64}", value or ""))

def is_sha1(value: str) -> bool:
    return bool(re.fullmatch(r"[0-9a-fA-F]{40}", value or ""))
