#!/usr/bin/env python3
"""审核证据结构、基础字段、当前 SHA 和计数一致性检查。"""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",required=True)
    ap.add_argument("--json-out",default="")
    ap.add_argument("--strict",action="store_true")
    a=ap.parse_args()
    root=Path(a.root)
    ev=root/"evidence"
    errors=[]
    warnings=[]
    if not ev.exists():
        print("RESULTS_PASS design_mode=true")
        return 0
    required=["SUMMARY.json","gate_results.json","identity.json","evidence_index.csv","findings.csv","task_ledger_snapshot.csv","traceability.csv"]
    for rel in required:
        if not (ev/rel).exists():
            errors.append("missing evidence/"+rel)
    try:
        summary=json.loads((ev/"SUMMARY.json").read_text(encoding="utf-8"))
    except Exception as exc:
        summary={}
        errors.append("bad SUMMARY: "+str(exc))
    tables={}
    for name in ("evidence_index.csv","findings.csv","task_ledger_snapshot.csv","traceability.csv"):
        q=ev/name
        if q.exists():
            try:
                with q.open(newline="",encoding="utf-8") as f:
                    tables[name]=list(csv.DictReader(f))
            except Exception as exc:
                errors.append("bad "+name+": "+str(exc))
    for row in tables.get("findings.csv",[]):
        if row.get("severity") not in {"P0","P1","P2","P3"}:
            errors.append("invalid finding severity")
        if row.get("status") not in {"OPEN","FIXED","ACCEPTED","SUPERSEDED"}:
            errors.append("invalid finding status")
    counts=summary.get("counts",{}) if isinstance(summary,dict) else {}
    findings_counts=counts.get("findings",{}) if isinstance(counts,dict) else {}
    for sev in ("P0","P1","P2","P3"):
        actual=sum(x.get("severity")==sev and x.get("status")=="OPEN" for x in tables.get("findings.csv",[]))
        if isinstance(findings_counts,dict) and sev in findings_counts and findings_counts[sev]!=actual:
            errors.append("finding count mismatch "+sev)
    rep={"checker":"RESULTS","status":"FAIL" if errors else "PASS","errors":errors,"warnings":warnings,"table_counts":{k:len(v) for k,v in tables.items()}}
    if a.json_out:
        Path(a.json_out).write_text(json.dumps(rep,ensure_ascii=False,indent=2)+chr(10),encoding="utf-8")
    for x in errors:
        print("ERROR",x)
    print("RESULTS_FAIL" if errors else "RESULTS_PASS")
    return 1 if errors else 0
if __name__=="__main__":
    raise SystemExit(main())
