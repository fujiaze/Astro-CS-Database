#!/usr/bin/env python3
"""CPU provider 真实结构检查；不以注释关键词作为资格证据。"""
from __future__ import annotations
import argparse,json,re
from pathlib import Path
def code(p):
    s=p.read_text(encoding="utf-8",errors="replace"); s=re.sub(r"/\*.*?\*/"," ",s,flags=re.S); return re.sub(r"//[^\n]*"," ",s)
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",required=True); ap.add_argument("--candidate-root",default=""); ap.add_argument("--json-out",default=""); ap.add_argument("--strict",action="store_true"); a=ap.parse_args(); target=Path(a.candidate_root or a.root).resolve(); errors=[]; warnings=[]
    if not a.candidate_root: return done(errors,warnings,a,{"design_mode":True})
    providers=target/"providers/cpu"
    if not providers.is_dir(): errors.append("providers/cpu missing")
    dirs={p.name:p for p in providers.iterdir() if p.is_dir()} if providers.is_dir() else {}
    for name in ("baseline","avx2","avx512"):
        if name not in dirs: errors.append("missing provider directory "+name)
        else:
            src=[p for p in dirs[name].rglob("*") if p.is_file() and p.suffix.lower() in {".c",".cc",".cpp",".cxx",".h",".hpp",".cmake"}]
            txt="\n".join(code(p) for p in src)
            if not txt.strip(): errors.append("empty provider "+name)
            if "self_test" not in txt and "selftest" not in txt.lower(): errors.append(name+" lacks executable self-test symbol")
            if "benchmark" not in txt.lower(): errors.append(name+" lacks benchmark hook")
    cmakes=list(providers.rglob("CMakeLists.txt")) if providers.exists() else []
    ctext="\n".join(code(p) for p in cmakes)
    if not re.search(r"baseline",ctext,re.I): errors.append("provider CMake baseline target missing")
    if not re.search(r"avx2",ctext,re.I): errors.append("provider CMake avx2 target missing")
    if not re.search(r"avx512",ctext,re.I): errors.append("provider CMake avx512 target missing")
    if re.search(r"ARCH[^\\n]*(AVX|avx)",ctext,re.I): warnings.append("inspect global architecture flag scope")
    allsrc="\n".join(code(p) for p in providers.rglob("*") if p.is_file() and p.suffix.lower() in {".c",".cc",".cpp",".cxx",".h",".hpp",".cmake",".json",".yaml",".yml"})
    for token in ("XGETBV","OSXSAVE","fallback","profile"):
        if token.lower() not in allsrc.lower(): errors.append("executable provider contract missing "+token)
    return done(errors,warnings,a,{"provider_dirs":sorted(dirs)})
def done(errors,warnings,a,extra):
    rep={"checker":"CPU_PROVIDER","status":"FAIL" if errors or (a.strict and warnings) else "PASS","errors":errors,"warnings":warnings}; rep.update(extra)
    if a.json_out: Path(a.json_out).write_text(json.dumps(rep,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    for x in errors: print("ERROR",x)
    print("CPU_PROVIDER_FAIL" if errors or (a.strict and warnings) else "CPU_PROVIDER_PASS")
    return 1 if errors or (a.strict and warnings) else 0
if __name__=="__main__": raise SystemExit(main())
