#!/usr/bin/env python3
"""SCI→ALG→DATA/API/ARCH→MOD→SRC→TEST→EVID 的当前提交闭环检查。"""
from __future__ import annotations
import argparse,csv,re,json
from pathlib import Path
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",required=True); ap.add_argument("--candidate-root",default=""); ap.add_argument("--current-sha",default=""); ap.add_argument("--json-out",default=""); ap.add_argument("--strict",action="store_true"); a=ap.parse_args(); root=Path(a.root).resolve(); target=Path(a.candidate_root).resolve() if a.candidate_root else root; errors=[]; warnings=[]
    if not a.candidate_root:
        for rel in ["science/PHASE3_PROJECTION_ALGORITHM_CONTRACT.md","science/PHASE2_SEAM_AND_INTEGRATION_CONTRACT.md","science/CPU_PROVIDER_QUALIFICATION_CONTRACT.md","tasks/MODULE_MIGRATION_MATRIX.csv"]:
            if not (root/rel).exists(): errors.append("missing control contract "+rel)
        text=(root/"16_SCIENCE_DOCUMENT_AND_TRACEABILITY_STANDARD.md").read_text(encoding="utf-8") if (root/"16_SCIENCE_DOCUMENT_AND_TRACEABILITY_STANDARD.md").exists() else ""
        for token in ("SCI-","ALG-","DATA-","API-","ARCH-","MOD-","TEST-","EVID-"):
            if token not in text: errors.append("missing ID family "+token)
    else:
        table=next((p for p in [target/"docs/traceability.csv",target/"contracts/traceability/traceability.csv",target/"tools/traceability/traceability.csv"] if p.exists()),None)
        if not table: errors.append("candidate missing traceability.csv")
        else:
            with table.open(newline="",encoding="utf-8") as f: rs=list(csv.DictReader(f))
            required={"sci_id","alg_id","data_ids","api_ids","arch_id","module_id","source_symbols","test_ids","evidence_ids"}
            if not rs: errors.append("traceability empty")
            elif not required.issubset(rs[0]): errors.append("traceability columns missing "+str(sorted(required-set(rs[0]))))
            alltext="\\n".join(p.read_text(encoding="utf-8",errors="replace") for p in target.rglob("*") if p.is_file() and p.suffix.lower() in {".md",".yaml",".yml",".json",".h",".hpp",".c",".cc",".cpp",".cxx",".cmake"})
            seen=set()
            for no,r in enumerate(rs,1):
                for key in required:
                    if not r.get(key): errors.append(f"row {no} missing {key}")
                for key,prefix in [("sci_id","SCI-"),("alg_id","ALG-"),("arch_id","ARCH-"),("module_id","MOD-"),("test_ids","TEST-"),("evidence_ids","EVID-")]:
                    for ident in re.findall(r"[A-Z]+-[A-Z0-9-]+",r.get(key,"")):
                        if ident in seen and key in {"sci_id","alg_id","module_id"}: warnings.append("duplicate reference "+ident)
                        seen.add(ident)
                        if ident not in alltext and not (key=="evidence_ids" and (target/"evidence").exists()): errors.append(f"row {no} reference not found {ident}")
                for sym in re.split(r"[;| ]+",r.get("source_symbols","")):
                    if sym and sym not in alltext: errors.append(f"row {no} source symbol not found {sym}")
                for test in re.findall(r"TEST-[A-Z0-9-]+",r.get("test_ids","")):
                    if test not in alltext: errors.append(f"row {no} test ID not registered {test}")
                for ev in re.findall(r"EVID-[A-Z0-9-]+",r.get("evidence_ids","")):
                    ep=target/"evidence"/(ev+".json")
                    if ep.exists():
                        try:
                            eo=json.loads(ep.read_text(encoding="utf-8"))
                            if a.current_sha and eo.get("main_sha")!=a.current_sha: errors.append(f"stale evidence {ev}")
                        except Exception as exc: errors.append(f"bad evidence {ev}: {exc}")
                    else: warnings.append("evidence file not colocated "+ev)
    rep={"checker":"TRACEABILITY","status":"FAIL" if errors or (a.strict and warnings) else "PASS","errors":errors,"warnings":warnings,"candidate":bool(a.candidate_root)}
    if a.json_out: Path(a.json_out).write_text(json.dumps(rep,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    for x in errors: print("ERROR",x)
    print("TRACEABILITY_FAIL" if errors or (a.strict and warnings) else "TRACEABILITY_PASS")
    return 1 if errors or (a.strict and warnings) else 0
if __name__=="__main__": raise SystemExit(main())
