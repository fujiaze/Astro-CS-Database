#!/usr/bin/env python3
"""源码快照范围、容量、路径和秘密扫描。"""
from __future__ import annotations
import argparse,re
from pathlib import Path
from common import finish, rel_files
def main()->int:
    p=argparse.ArgumentParser(); p.add_argument("--source",required=True); p.add_argument("--allowlist",default=""); p.add_argument("--json-out",default=""); p.add_argument("--strict",action="store_true"); a=p.parse_args(); root=Path(a.source).resolve(); errors=[]; warnings=[]
    if not root.is_dir(): return finish("SOURCE_SCOPE",[f"source not directory: {root}"],[],{},a.json_out,a.strict)
    allow=[]
    if a.allowlist and Path(a.allowlist).exists(): allow=[x.strip() for x in Path(a.allowlist).read_text(encoding="utf-8").splitlines() if x.strip() and not x.startswith("#")]
    total=0; binary=0
    for rel,pth in rel_files(root):
        size=pth.stat().st_size; total+=size
        if size>5*1024*1024: errors.append(f">5 MiB: {rel}")
        if pth.suffix.lower() in {".fits",".fit",".fz",".pdb",".dmp",".zip",".tar",".gz"}: errors.append(f"forbidden artifact: {rel}")
        if any(part in {".git","build","out","install","testdata","node_modules","__pycache__"} for part in pth.parts) or pth.suffix==".pyc": errors.append(f"forbidden path: {rel}")
        if pth.is_symlink(): errors.append(f"symlink forbidden: {rel}")
        if pth.suffix.lower() in {".exe",".dll",".so",".a",".o",".obj"}: binary+=1
        if pth.suffix.lower() in {".md",".yaml",".yml",".json",".txt",".csv",".h",".hpp",".c",".cc",".cpp",".cxx",".cmake"}:
            t=pth.read_text(encoding="utf-8",errors="replace")
            if re.search(r"(?i)(password|secret|api[_-]?key|token)\s*[:=]",t): errors.append(f"possible secret: {rel}")
    if allow:
        # Allowlist entries are prefix rules; only report unexpected source files.
        for rel,_ in rel_files(root):
            if not any(rel==x or rel.startswith(x.rstrip("/")+"/") for x in allow): errors.append(f"not in source allowlist: {rel}")
    return finish("SOURCE_SCOPE",errors,warnings,{"file_count":sum(1 for _ in rel_files(root)),"total_bytes":total,"binary_count":binary},a.json_out,a.strict)
if __name__=="__main__":
    try: raise SystemExit(main())
    except Exception as exc: print(f"SOURCE_SCOPE_TOOLING_FAILURE {type(exc).__name__}: {exc}"); raise
