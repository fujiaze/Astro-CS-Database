#!/usr/bin/env python3
"""控制面负测；每个破坏性样例都必须被对应 validator 拒绝。"""
from __future__ import annotations
import csv, json, os, shutil, subprocess, sys, tempfile
from pathlib import Path
sys.dont_write_bytecode=True
def run(cmd,cwd):
    env=dict(os.environ); env["PYTHONDONTWRITEBYTECODE"]="1"
    return subprocess.run(cmd,cwd=cwd,text=True,capture_output=True,env=env)
def fail_case(name,fn):
    with tempfile.TemporaryDirectory(prefix="astrocs-negative-") as td:
        dst=Path(td)/"pkg"; shutil.copytree(Path(__file__).resolve().parents[1],dst,ignore=shutil.ignore_patterns("__pycache__"))
        fn(dst)
        r=run([sys.executable,str(dst/"validators/validate_control.py"),"--root",str(dst)],dst)
        if r.returncode==0: raise RuntimeError(name+" unexpectedly passed")
def main():
    root=Path(__file__).resolve().parents[1]; checker=root/"validators/validate_control.py"; taskcheck=root/"validators/validate_tasks.py"
    cases={
      "missing":lambda d:(d/"22_FAILURE_ESCALATION.md").unlink(),
      "tamper":lambda d:(d/"01_OWNER_FROZEN_CONSTRAINTS.md").write_text("tampered",encoding="utf-8"),
      "extra":lambda d:(d/"UNREGISTERED.md").write_text("extra",encoding="utf-8"),
      "bad_manifest":lambda d:(d/"CONTROL_MANIFEST.json").write_text(json.dumps({"files":[]}),encoding="utf-8"),
      "bad_schema":lambda d:(d/"schemas/task_state.schema.json").write_text("{",encoding="utf-8"),
    }
    for name,fn in cases.items(): fail_case(name,fn)
    with tempfile.TemporaryDirectory(prefix="astrocs-template-negative-") as td:
        dst=Path(td)/"pkg"; shutil.copytree(root,dst,ignore=shutil.ignore_patterns("__pycache__"))
        x=json.loads((dst/"templates/TASK_RESULT.json").read_text(encoding="utf-8")); x["result_main_sha"]="bad"; (dst/"templates/TASK_RESULT.json").write_text(json.dumps(x),encoding="utf-8")
        r=run([sys.executable,str(dst/"validators/validate_templates.py"),"--root",str(dst)],dst)
        if r.returncode==0: raise RuntimeError("template schema mismatch unexpectedly passed")
    for label,mut in {
      "nested_type":lambda x: x["commands"][0].update(exit_code="bad"),
      "nested_enum":lambda x: x.update(status="NOT_A_RESULT_STATUS"),
    }.items():
      with tempfile.TemporaryDirectory(prefix="astrocs-template-schema-negative-") as td:
        dst=Path(td)/"pkg"; shutil.copytree(root,dst,ignore=shutil.ignore_patterns("__pycache__"))
        x=json.loads((dst/"templates/TASK_RESULT.json").read_text(encoding="utf-8")); mut(x); (dst/"templates/TASK_RESULT.json").write_text(json.dumps(x),encoding="utf-8")
        r=run([sys.executable,str(dst/"validators/validate_templates.py"),"--root",str(dst)],dst)
        if r.returncode==0: raise RuntimeError(label+" schema violation unexpectedly passed")
    with tempfile.TemporaryDirectory(prefix="astrocs-template-minimum-negative-") as td:
      dst=Path(td)/"pkg"; shutil.copytree(root,dst,ignore=shutil.ignore_patterns("__pycache__"))
      x=json.loads((dst/"templates/TASK_STATE.json").read_text(encoding="utf-8")); x["tasks"][0]["attempt"]=-1; (dst/"templates/TASK_STATE.json").write_text(json.dumps(x),encoding="utf-8")
      r=run([sys.executable,str(dst/"validators/validate_templates.py"),"--root",str(dst)],dst)
      if r.returncode==0: raise RuntimeError("minimum constraint violation unexpectedly passed")
    for payload in ({"task_id":"NO-SUCH"},{"task_id":"CTL-001"}):
      with tempfile.TemporaryDirectory(prefix="astrocs-result-negative-") as td:
        dst=Path(td)/"pkg"; shutil.copytree(root,dst,ignore=shutil.ignore_patterns("__pycache__")); rp=Path(td)/"result.json"; rp.write_text(json.dumps(payload),encoding="utf-8")
        r=run([sys.executable,str(dst/"validators/control_plane.py"),"validate-result","--root",str(dst),"--result",str(rp)],dst)
        if r.returncode==0: raise RuntimeError("invalid TASK_RESULT unexpectedly passed")
    with tempfile.TemporaryDirectory(prefix="astrocs-gate-negative-") as td:
      dst=Path(td)/"pkg"; shutil.copytree(root,dst,ignore=shutil.ignore_patterns("__pycache__")); state=Path(td)/"state.json"; ev=Path(td)/"evidence"; ev.mkdir()
      r=run([sys.executable,str(dst/"validators/control_plane.py"),"init-state","--root",str(dst),"--state",str(state),"--main-sha","0123456789abcdef0123456789abcdef01234567"],dst)
      if r.returncode: raise RuntimeError("gate setup failed")
      data=json.loads(state.read_text(encoding="utf-8")); [x.update(status="CLOSED") for x in data["tasks"]]; state.write_text(json.dumps(data),encoding="utf-8")
      (ev/"evidence_index.csv").write_text("evidence_id,main_sha,status\n",encoding="utf-8"); (ev/"findings.csv").write_text("finding_id,severity,status\n",encoding="utf-8")
      r=run([sys.executable,str(dst/"validators/control_plane.py"),"gates","--root",str(dst),"--state",str(state),"--output",str(Path(td)/"gates.json"),"--evidence-dir",str(ev)],dst)
      if r.returncode or json.loads((Path(td)/"gates.json").read_text(encoding="utf-8"))["verdict"]!="NOT_READY": raise RuntimeError("empty evidence gate unexpectedly passed")
    for name,mut in {
      "duplicate":lambda rs: rs.append(dict(rs[0])),
      "unknown_dep":lambda rs: rs[0].update(depends_on="NO-SUCH-TASK"),
      "cycle":lambda rs:(rs[0].update(depends_on=rs[1]["task_id"]),rs[1].update(depends_on=rs[0]["task_id"])),
      "later_wave":lambda rs: (rs[0].update(depends_on=rs[-1]["task_id"]),rs[-1].update(wave="W9")),
    }.items():
      with tempfile.TemporaryDirectory(prefix="astrocs-task-negative-") as td:
        dst=Path(td)/"pkg"; shutil.copytree(root,dst,ignore=shutil.ignore_patterns("__pycache__"))
        with (dst/"TASK_LEDGER.csv").open(newline="",encoding="utf-8") as f: rs=list(csv.DictReader(f)); fields=rs[0].keys()
        mut(rs)
        with (dst/"TASK_LEDGER.csv").open("w",newline="",encoding="utf-8") as f:
          w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rs)
        r=run([sys.executable,str(dst/"validators/validate_tasks.py"),"--root",str(dst)],dst)
        if r.returncode==0: raise RuntimeError(name+" task unexpectedly passed")
    print("VALIDATOR_SELFTEST_PASS cases=16")
    return 0
if __name__=="__main__":
    try: raise SystemExit(main())
    except Exception as exc: print("VALIDATOR_SELFTEST_FAIL",exc); raise
