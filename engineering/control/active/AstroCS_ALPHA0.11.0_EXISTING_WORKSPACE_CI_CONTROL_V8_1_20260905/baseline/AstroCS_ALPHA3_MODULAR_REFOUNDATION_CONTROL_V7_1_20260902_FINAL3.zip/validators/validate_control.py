#!/usr/bin/env python3
"""控制包严格自校验：文件集合、逐字节 SHA、manifest、schema、路径和归档禁带物。"""
from __future__ import annotations
import argparse, csv, hashlib, json, re
from pathlib import Path

REQUIRED = [
 "START_PROMPT.txt","00_READ_FIRST.md","01_OWNER_FROZEN_CONSTRAINTS.md",
 "02_CURRENT_BASELINE_AUDIT.md","03_TARGET_PRODUCT_AND_ARCHITECTURE.md",
 "04_FOREGROUND_AGENT_RUNBOOK.md","05_FIXED_SUBAGENT_BINDINGS.yaml",
 "06_TASK_GRAPH_AND_WAVES.md","07_CHECKPOINTS_AND_GATES.md",
 "08_GIT_MAIN_ONLY_INTEGRATION.md","09_WINDOWS_TOOLCHAIN_LOCK.md",
 "10_LINUX_CONTROL_NODE.md","11_MODULE_SOURCE_TEST_STANDARD.md",
 "12_DLL_ABI_AND_LOADER_STANDARD.md","13_DATA_PIPELINE_AND_ARTIFACT_STANDARD.md",
 "14_RUNTIME_SCHEDULER_AND_TRACE_STANDARD.md","15_CPU_PROVIDER_AND_RESOURCE_STANDARD.md",
 "16_SCIENCE_DOCUMENT_AND_TRACEABILITY_STANDARD.md","17_INDEPENDENT_REVIEWER.md",
 "18_AUDIT_PACKAGE_SPEC.md","19_MACHINE_CHECKS.md","20_RELEASE_GATES.md",
 "21_PRIMARY_REFERENCES.md","22_FAILURE_ESCALATION.md","TASK_LEDGER.csv",
 "CONTROL_MANIFEST.json","SHA256SUMS","package_policy/PACKAGE_POLICY.json",
 "package_policy/SOURCE_ALLOWLIST.txt","package_policy/AUDIT_ALLOWLIST.txt",
 "science/PHASE3_PROJECTION_ALGORITHM_CONTRACT.md",
 "science/PHASE2_SEAM_AND_INTEGRATION_CONTRACT.md",
 "science/CPU_PROVIDER_QUALIFICATION_CONTRACT.md",
 "templates/AGENTS.md","validators/control_plane.py","validators/validate_templates.py","GATE_REQUIREMENTS.csv","toolchain.lock.json","23_GRAPH_AND_DOC_TOOL_POLICY.md",
]
FORBIDDEN_PARTS={".git","build","out","install","node_modules","testdata","__pycache__"}
FORBIDDEN_SUFFIXES={".fits",".fit",".fz",".pdb",".dmp",".core",".pyc",".zip",".tgz",".gz"}

def digest(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda:f.read(1024*1024),b""): h.update(block)
    return h.hexdigest()

def regular_files(root: Path):
    for p in sorted(root.rglob("*")):
        rel=p.relative_to(root).as_posix()
        if p.is_symlink(): yield rel,p,"SYMLINK"
        elif p.is_file(): yield rel,p,"FILE"

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument("--root",required=True)
    ap.add_argument("--json-out",default="")
    args=ap.parse_args()
    root=Path(args.root).resolve(); errors=[]; warnings=[]
    if not root.is_dir(): print("CONTROL_FAIL root_not_directory"); return 1
    entries=list(regular_files(root)); filemap={r:p for r,p,k in entries if k=="FILE"}
    for rel,p,k in entries:
        if k=="SYMLINK": errors.append("symlink forbidden: "+rel)
        if any(x in Path(rel).parts for x in FORBIDDEN_PARTS): errors.append("generated path forbidden: "+rel)
        if p.suffix.lower() in FORBIDDEN_SUFFIXES: errors.append("forbidden suffix: "+rel)
        if k=="FILE" and p.stat().st_size>5*1024*1024: errors.append("file exceeds 5 MiB: "+rel)
    total=sum(p.stat().st_size for p in filemap.values())
    if total>20*1024*1024: errors.append(f"package exceeds 20 MiB: {total}")
    for rel in REQUIRED:
        if rel not in filemap: errors.append("missing required file: "+rel)
        elif filemap[rel].stat().st_size==0: errors.append("empty required file: "+rel)
    prompt=filemap.get("START_PROMPT.txt")
    if prompt and len(prompt.read_text(encoding="utf-8"))>100: errors.append("START_PROMPT exceeds 100 characters")
    manifest=filemap.get("CONTROL_MANIFEST.json")
    manifest_records={}
    if manifest:
        try:
            m=json.loads(manifest.read_text(encoding="utf-8"))
            if m.get("package_id")!="ASTROCS-ALPHA3-MODULAR-REFOUNDATION-V7.1": errors.append("manifest package_id mismatch")
            for rec in m.get("files",[]):
                path=rec.get("path","")
                if path in manifest_records: errors.append("duplicate manifest path: "+path)
                manifest_records[path]=rec
        except Exception as exc: errors.append("manifest JSON invalid: "+str(exc))
    expected_manifest=set(filemap)-{"CONTROL_MANIFEST.json","SHA256SUMS"}
    if set(manifest_records)!=expected_manifest:
        errors.append("CONTROL_MANIFEST file set mismatch")
    for rel in sorted(expected_manifest):
        rec=manifest_records.get(rel,{})
        if rec.get("size_bytes")!=filemap[rel].stat().st_size: errors.append("manifest size mismatch: "+rel)
        if rec.get("sha256")!=digest(filemap[rel]): errors.append("manifest SHA mismatch: "+rel)
    sums=filemap.get("SHA256SUMS"); sum_records={}
    if sums:
        for no,line in enumerate(sums.read_text(encoding="utf-8").splitlines(),1):
            parts=line.split("  ",1)
            if len(parts)!=2 or not re.fullmatch(r"[0-9a-f]{64}",parts[0]): errors.append(f"invalid SHA256SUMS line {no}"); continue
            if parts[1] in sum_records: errors.append("duplicate SHA entry: "+parts[1])
            sum_records[parts[1]]=parts[0]
        expected_sums=set(filemap)-{"SHA256SUMS"}
        if set(sum_records)!=expected_sums: errors.append("SHA256SUMS file set mismatch")
        for rel in sorted(expected_sums):
            if sum_records.get(rel)!=digest(filemap[rel]): errors.append("SHA256SUMS mismatch: "+rel)
    for rel in ["schemas/dispatch.schema.json","schemas/task_result.schema.json","schemas/task_state.schema.json","schemas/evidence_record.schema.json","schemas/finding.schema.json","schemas/gate_result.schema.json","schemas/module_manifest.schema.json","schemas/audit_summary.schema.json","schemas/artifact_manifest.schema.json","package_policy/PACKAGE_POLICY.json"]:
        q=filemap.get(rel)
        if not q: errors.append("missing JSON schema: "+rel); continue
        try: json.loads(q.read_text(encoding="utf-8"))
        except Exception as exc: errors.append("invalid JSON "+rel+": "+str(exc))
    ledger=filemap.get("TASK_LEDGER.csv")
    if ledger:
        try:
            rows=list(csv.DictReader(ledger.open(newline="",encoding="utf-8")))
            ids=[r.get("task_id","") for r in rows]
            if not rows or len(ids)!=len(set(ids)): errors.append("TASK_LEDGER empty or duplicate task_id")
        except Exception as exc: errors.append("TASK_LEDGER parse failure: "+str(exc))
    report={"checker":"CONTROL","status":"FAIL" if errors else "PASS","errors":errors,"warnings":warnings,"file_count":len(filemap),"total_bytes":total}
    if args.json_out: Path(args.json_out).write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    for e in errors: print("ERROR",e)
    print("CONTROL_FAIL" if errors else f"CONTROL_PASS files={len(filemap)}")
    return 1 if errors else 0
if __name__=="__main__":
    raise SystemExit(main())
