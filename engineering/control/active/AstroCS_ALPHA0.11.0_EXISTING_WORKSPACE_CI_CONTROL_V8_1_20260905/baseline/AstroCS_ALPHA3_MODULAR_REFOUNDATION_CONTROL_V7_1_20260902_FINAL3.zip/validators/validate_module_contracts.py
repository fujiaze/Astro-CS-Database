#!/usr/bin/env python3
"""候选源码的 module.yaml、README、CMake、导出和测试真实交叉检查。"""
from __future__ import annotations
import argparse,re
from pathlib import Path
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",required=True); ap.add_argument("--candidate-root",default=""); ap.add_argument("--json-out",default=""); ap.add_argument("--strict",action="store_true"); a=ap.parse_args(); base=Path(a.root).resolve(); target=Path(a.candidate_root).resolve() if a.candidate_root else base; errors=[]; warnings=[]
    if not a.candidate_root:
        t=target/"templates/MODULE_README.md"; m=target/"tasks/MODULE_MIGRATION_MATRIX.csv"
        if not t.exists() or not m.exists(): errors.append("control module template/matrix missing")
        return out(errors,warnings,a,{"design_mode":True})
    mods=target/"modules"; manifests=sorted(mods.rglob("module.yaml")) if mods.exists() else []
    if not manifests: errors.append("candidate has no modules/**/module.yaml")
    sections=["负责范围","输入与输出","合同链接","实现事实","并发与资源","验证"]
    for y in manifests:
        d=y.parent; text=y.read_text(encoding="utf-8",errors="replace"); readme=d/"README.md"; cmake=d/"CMakeLists.txt"; tests=d/"tests"
        if not readme.exists(): errors.append(f"{d}: README missing")
        else:
            rt=readme.read_text(encoding="utf-8",errors="replace")
            for sec in sections:
                if sec not in rt: errors.append(f"{readme}: section missing {sec}")
        if not cmake.exists(): errors.append(f"{d}: CMakeLists missing")
        else:
            ct=cmake.read_text(encoding="utf-8",errors="replace")
            if not re.search(r"add_library\\s*\\([^)]*\\bSHARED\\b",ct,re.I): errors.append(f"{cmake}: no SHARED module target")
        if not tests.is_dir(): errors.append(f"{d}: tests missing")
        elif not any(p.suffix.lower() in {".c",".cc",".cpp",".cxx",".h",".hpp"} for p in tests.rglob("*")): errors.append(f"{d}: tests has no source")
        for key in ("id:","module_id:","module_version:","abi_version:","phase_scope:","entrypoint:","artifacts:","input_ports:","output_ports:","science_contracts:","algorithm_contracts:","data_contracts:","api_contracts:","source_symbols:","test_ids:","threading_model:","resource_class:","determinism:"):
            if key not in text: errors.append(f"{y}: missing {key}")
        for key in ("science_contracts:","algorithm_contracts:","data_contracts:","api_contracts:","source_symbols:","test_ids:"):
            line=next((x.strip() for x in text.splitlines() if x.strip().startswith(key)), "")
            if line.endswith("[]") or line.endswith(":"): errors.append(f"{y}: empty {key}")
        if "astrocs_module_query_v1" not in text: errors.append(f"{y}: entrypoint not declared")
        source=list(d.rglob("*.c"))+list(d.rglob("*.cc"))+list(d.rglob("*.cpp"))+list(d.rglob("*.cxx"))+list(d.rglob("*.h"))+list(d.rglob("*.hpp"))
        src="\\n".join(p.read_text(encoding="utf-8",errors="replace") for p in source)
        symbols=re.findall(r"^\\s*-\\s*([A-Za-z_][A-Za-z0-9_:]*)\\s*$",text,re.M)
        for sym in symbols:
            if sym not in src: errors.append(f"{y}: source symbol not found {sym}")
        if "astrocs_module_query_v1" not in src: errors.append(f"{d}: query export symbol not found in source")
        if tests.is_dir():
            testtext="\\n".join(p.read_text(encoding="utf-8",errors="replace") for p in tests.rglob("*") if p.is_file() and p.suffix.lower() in {".cmake",".txt",".c",".cc",".cpp",".cxx"})
            if "add_test" not in testtext and "CTest" not in testtext: errors.append(f"{d}: tests are not registered with CTest")
    return out(errors,warnings,a,{"design_mode":False,"manifest_count":len(manifests)})
def out(errors,warnings,a,extra):
    import json
    rep={"checker":"MODULE_CONTRACT","status":"FAIL" if errors or (a.strict and warnings) else "PASS","errors":errors,"warnings":warnings}; rep.update(extra)
    if a.json_out: Path(a.json_out).write_text(json.dumps(rep,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    for x in errors: print("ERROR",x)
    print("MODULE_CONTRACT_FAIL" if errors or (a.strict and warnings) else "MODULE_CONTRACT_PASS")
    return 1 if errors or (a.strict and warnings) else 0
if __name__=="__main__": raise SystemExit(main())
