#!/usr/bin/env python3
"""生成控制包内部清单和 SHA256SUMS；不把自身/校验文件哈希写入 manifest。"""
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path
def digest(p:Path)->str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()
def main()->int:
    p=argparse.ArgumentParser(); p.add_argument('--root',required=True); a=p.parse_args(); root=Path(a.root).resolve()
    records=[]
    for f in sorted(root.rglob('*')):
        if not f.is_file() or "__pycache__" in f.parts or f.suffix==".pyc": continue
        rel=f.relative_to(root).as_posix()
        if rel in {'CONTROL_MANIFEST.json','SHA256SUMS'}: continue
        records.append({'path':rel,'size_bytes':f.stat().st_size,'sha256':digest(f)})
    manifest={'manifest_version':2,'package_id':'ASTROCS-ALPHA3-MODULAR-REFOUNDATION-V7.1','product_version':'0.11.0-alpha.1','source_reference':'c1696156583c68c9a3a65287639c726937e9f6e7','generated_by':'validators/build_control_manifest.py','files':records}
    (root/'CONTROL_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    lines=[]
    for f in sorted(root.rglob('*')):
        if not f.is_file() or f.name=='SHA256SUMS' or "__pycache__" in f.parts or f.suffix==".pyc": continue
        lines.append(f"{digest(f)}  {f.relative_to(root).as_posix()}")
    (root/'SHA256SUMS').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(f"CONTROL_MANIFEST_BUILT files={len(records)}")
    return 0
if __name__=='__main__': raise SystemExit(main())
