#!/usr/bin/env python3
"""候选源码 ABI 与产品/module manifest 的最小安全检查。"""
from __future__ import annotations
import argparse,re
from pathlib import Path
from common import finish
def main()->int:
    p=argparse.ArgumentParser(); p.add_argument("--root",default="."); p.add_argument("--candidate-root",default=""); p.add_argument("--json-out",default=""); p.add_argument("--strict",action="store_true"); a=p.parse_args(); root=Path(a.candidate_root or a.root).resolve(); errors=[]; warnings=[]
    if not a.candidate_root: return finish("ABI_MANIFEST",errors,warnings,{"design_mode":True},a.json_out,a.strict)
    headers=list(root.rglob("*.h"))+list(root.rglob("*.hpp")); public=[x for x in headers if any(s in x.as_posix() for s in ("include/","public"))]
    for h in public:
        t=h.read_text(encoding="utf-8",errors="replace")
        if re.search(r"\bstd::(vector|string|map|unique_ptr|shared_ptr)\b",t): errors.append(f"STL in public ABI header: {h.relative_to(root)}")
        if re.search(r"\bthrow\b|catch\s*\(",t): warnings.append(f"exception token in public header: {h.relative_to(root)}")
        if "struct_size" not in t and "abi_version" not in t and "astrocs" in t.lower(): warnings.append(f"ABI header lacks version fields: {h.relative_to(root)}")
    text="\n".join(x.read_text(encoding="utf-8",errors="replace") for x in headers)
    if "astrocs_module_query_v1" not in text: errors.append("approved query entrypoint not found")
    for manifest in list(root.rglob("module.yaml")):
        if "abi_version: 1" not in manifest.read_text(encoding="utf-8",errors="replace"): errors.append(f"manifest ABI != 1: {manifest.relative_to(root)}")
    return finish("ABI_MANIFEST",errors,warnings,{"header_count":len(public)},a.json_out,a.strict)
if __name__=="__main__":
    try: raise SystemExit(main())
    except Exception as exc: print(f"ABI_MANIFEST_TOOLING_FAILURE {type(exc).__name__}: {exc}"); raise
