#!/usr/bin/env python3
"""只扫描生产源和正式配置的 Phase 隔离/DAG 检查。"""
from __future__ import annotations
import argparse,json,re
from pathlib import Path
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",required=True); ap.add_argument("--candidate-root",default=""); ap.add_argument("--json-out",default=""); ap.add_argument("--strict",action="store_true"); a=ap.parse_args(); target=Path(a.candidate_root or a.root).resolve(); errors=[]; warnings=[]
    if not a.candidate_root: return done(errors,warnings,a,{"design_mode":True})
    roots=("apps/cli","cli","runtime","modules","providers","contracts/config")
    files=[target/x for top in roots if (target/top).exists() for x in (target/top).rglob("*") if x.is_file() and x.suffix.lower() in {".c",".cc",".cpp",".cxx",".h",".hpp",".json",".yaml",".yml",".cmake"}]
    text="\n".join(p.read_text(encoding="utf-8",errors="replace") for p in files)
    if re.search(r"--phases|--pipeline",text,re.I): errors.append("continuous multi-phase CLI option in production")
    if not re.search(r"phase1",text,re.I) or not re.search(r"phase2",text,re.I) or not re.search(r"phase3",text,re.I): errors.append("not all phase commands present")
    for cmd in ("validate","plan","run","inspect"):
        if not re.search(r"\b"+cmd+r"\b",text,re.I): errors.append("CLI verb missing "+cmd)
    for phase in ("phase1","phase2","phase3"):
        if re.search(r"p[123]_session_run",text,re.I): warnings.append("legacy session symbol present; confirm not production route")
    # Formal pipeline configs must not contain cross-phase edges.
    for p in files:
        if p.suffix.lower() in {".json",".yaml",".yml"} and ("pipeline" in p.as_posix() or "phase" in p.name):
            t=p.read_text(encoding="utf-8",errors="replace")
            if re.search(r"phase1.*phase2|phase2.*phase3|phase1.*phase3",t,re.I|re.S): errors.append("cross-phase edge in "+p.relative_to(target).as_posix())
    return done(errors,warnings,a,{"scanned_files":len(files)})
def done(errors,warnings,a,extra):
    rep={"checker":"PHASE_DAG","status":"FAIL" if errors or (a.strict and warnings) else "PASS","errors":errors,"warnings":warnings}; rep.update(extra)
    if a.json_out: Path(a.json_out).write_text(json.dumps(rep,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    for x in errors: print("ERROR",x)
    print("PHASE_DAG_FAIL" if errors or (a.strict and warnings) else "PHASE_DAG_PASS")
    return 1 if errors or (a.strict and warnings) else 0
if __name__=="__main__": raise SystemExit(main())
