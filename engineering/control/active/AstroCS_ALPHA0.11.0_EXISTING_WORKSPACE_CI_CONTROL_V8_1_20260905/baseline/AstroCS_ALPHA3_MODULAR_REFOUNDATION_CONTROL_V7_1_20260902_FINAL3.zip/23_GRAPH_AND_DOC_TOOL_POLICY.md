# 运行图、代码文档和工具版本策略

## 1. 两类图必须分开

静态架构图来自当前提交的 CMake File API、compile_commands、module manifest 和 pipeline JSON；真实运行图来自同一 run_id 的 run-trace.jsonl。静态图表示声明依赖，运行图表示实际调用、耗时、DLL/hash、provider、workers 和 artifact hash；禁止以静态计划冒充运行事实。

## 2. 固定生成链

1. CMake configure 生成 File API reply 和 compile_commands.json；
2. tools/graph 读取 reply、module manifest 和正式 pipeline，输出 graph-static.json、graph-static.dot；
3. 运行时输出 graph-runtime.json、graph-runtime.dot；
4. 若主机有已登记 Graphviz，使用其 dot 生成 SVG；否则保留 DOT/JSON，不临时安装未知版本；
5. 每张图写 generator version、source SHA、config SHA、输入文件 hash；SVG 是派生展示物，DOT/JSON 才是可审计事实。

## 3. 文档一致性

Doxygen/clang AST 只能从当前 compile_commands 生成 API/source symbol 索引；模块 README 的 source_symbols、module.yaml、导出表、CTest 注册和 traceability 必须由脚本交叉验证。函数名、参数、单位、线程模型和错误码变更必须同步更新对应接口文档。

## 4. 工具安装限制

Linux 控制节点优先使用现有 Python 标准库、CMake File API、DOT 文本生成；Windows 使用工具链锁中已登记的 CMake/LLVM/clang-tidy。禁止 Agent 因生成一张图自行下载或切换未记录版本。工具不可用时返回 WAITING_RESOURCE，不能把缺图标记 PASS；只要 DOT/JSON 已生成，其他不依赖 SVG 的任务继续。
