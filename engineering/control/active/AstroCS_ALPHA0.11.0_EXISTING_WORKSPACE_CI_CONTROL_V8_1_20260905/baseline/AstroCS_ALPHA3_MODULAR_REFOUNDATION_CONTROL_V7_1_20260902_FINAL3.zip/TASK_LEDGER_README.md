# TASK_LEDGER.csv 使用规则

`TASK_LEDGER.csv` 是静态任务定义单源；它不保存动态状态。前台 Agent 每次从它复制到工作根 `TASK_STATE.json`，状态由 `schemas/task_state.schema.json` 校验，完成后把 state snapshot 放入审核包。

任务状态只能按下列方向迁移；以下是唯一状态机，schema、控制面脚本、模板和报告必须使用同一枚举：

```text
NOT_STARTED → READY → DISPATCHED → RETURNED → INTEGRATED → CLOSED
                                  ↘ FAIL / BLOCKED / WAITING_RESOURCE
旧 base 任务 → REBASE_REQUIRED → DISPATCHED
旧证据/结果 → SUPERSEDED
```

`INTEGRATED` 必须已有一个只含该 task 目的的 main commit；`CLOSED` 必须已有当前 SHA 的测试和 evidence。`BLOCKED` 只用于真实科学冲突/工具链阻断/外部资源阻断，普通实现失败必须继续修复。状态不能靠 Agent 自报，前台依据结果 schema、Git SHA、Gate 重算。SubAgent 结果只有 `base_main_sha`、`patch_sha256` 和 changed-files digest；`integrated_main_sha` 只能出现在前台状态快照或证据中。
