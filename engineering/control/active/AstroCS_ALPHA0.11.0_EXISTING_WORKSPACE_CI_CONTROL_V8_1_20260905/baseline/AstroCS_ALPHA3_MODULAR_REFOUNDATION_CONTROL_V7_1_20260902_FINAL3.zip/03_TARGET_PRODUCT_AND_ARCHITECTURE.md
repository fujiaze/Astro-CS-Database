# 目标产品、目录与 DLL 架构

## 1. 目标不是大爆炸重写

目标架构允许彻底替换当前伪模块化，但实施使用 strangler 迁移：先把合同、宿主、C ABI、Artifact、资源执行器做成可测试骨架，再逐模块把现有实现装入独立 DLL；新入口逐项与当前可用函数直调做小合成等价，最后才删除旧 Session/factory。任何任务不得先删可用实现再重写。

## 2. 仓库规范

目标目录如下；迁移中允许短期存在旧路径，但每个旧路径必须有 owner、退出 task 和截止 Gate。

```text
AstroCS/
  AGENTS.md
  VERSION
  CMakeLists.txt
  CMakePresets.json
  apps/cli/
  include/astrocs/abi/
  include/astrocs/contracts/
  runtime/
    module_loader/
    registry/
    pipeline/
    scheduler/
    artifact_store/
    logging/
    monitoring/
  modules/
    phase1/<module>/
    phase2/<module>/
    phase3/<module>/
    services/catalog_gaia/
  providers/cpu/{baseline,avx2,avx512}/
  contracts/{data,pipeline,config,traceability}/
  docs/
    owner/
    science/
    algorithms/
    architecture/
    interfaces/
    modules/
    generated/
    archive/
  tests/{testkit,abi,contract,integration,pipeline,release}/
  tools/{doccheck,traceability,graph,monitoring,packaging}/
  engineering/control/{active,archive}/
```

运行时内容必须在仓库外：

```text
ASTROCS_WORK_ROOT/
  build/ install/ runs/ cache/ reports/ audit/ tmp/
  worktrees/ returns/ locks/ dispatch/
```

禁止把 build、runs、testdata、HiPS tile tree、远端克隆数据、审核包和控制包散落进源码目录。根目录只保留当前入口和少量 L0 文档。

## 3. 用户命令面

正式命令必须稳定且互相独立：

```text
astrocs version --json
astrocs doctor [--json]
astrocs modules list|verify [--json]
astrocs config validate --phase <1|2|3> <file>
astrocs phase1 validate|plan|run|inspect <config>
astrocs phase2 validate|plan|run|inspect <config>
astrocs phase3 validate|plan|run|inspect <config>
astrocs benchmark cpu [--suite quick|release] [--output profile.json]
astrocs selftest [--module ID] [--provider ID]
```

删除/拒绝：

```text
astrocs run --phases 1,2,3
astrocs --pipeline phase1,phase2,phase3
任何一个进程隐式衔接三个阶段的等价入口
```

每个 `validate` 只解析 schema/路径/manifest/资源计划，不执行科学重算；`plan` 输出静态 typed DAG、work units、内存、I/O、并行轴；`run` 才执行；`inspect` 只读既有 run/product manifest。

## 4. Windows 安装树

```text
AstroCS-0.11.0-alpha.1-win-x64/
  astrocs.exe
  astrocs.product.json
  astrocs_runtime.dll
  astrocs_io.dll
  modules/
    astrocs_p1_calibration.dll
    astrocs_p1_cosmetic.dll
    astrocs_p1_star_detection.dll
    astrocs_p1_psf.dll
    astrocs_p1_wcs.dll
    astrocs_p1_photometry.dll
    astrocs_p1_noise.dll
    astrocs_p1_drizzle.dll
    astrocs_p1_hips_writer.dll
    astrocs_p2_coverage.dll
    astrocs_p2_sampling.dll
    astrocs_p2_upm.dll
    astrocs_p2_rejection.dll
    astrocs_p2_integration.dll
    astrocs_p2_hips_writer.dll
    astrocs_p3_projection.dll
    astrocs_p3_resample.dll
    astrocs_p3_fits_writer.dll
    astrocs_catalog_gaia.dll
  providers/
    astrocs_cpu_baseline.dll
    astrocs_cpu_avx2.dll
    astrocs_cpu_avx512.dll
  pipelines/{phase1,phase2,phase3}.default.json
  schemas/
  licenses/
  README.txt
```

### 4.1 DLL 边界冻结

| 交付单元 | 负责 | 不负责 |
|---|---|---|
| `astrocs.exe` | 参数、配置、稳定 JSON/退出码、进程控制 | 科学算法、私有线程池、直接 FITS/HiPS 解析 |
| `astrocs_runtime.dll` | loader/registry/DAG/scheduler/ArtifactStore/log/metrics/cancel | 科学公式、第三方 I/O |
| `astrocs_io.dll` | FITS、HiPS、manifest、原子/流式 I/O | DAG、科学公式、线程策略 |
| module DLL | 一个明确科学/工程操作 | 整阶段隐藏 Session、文件路径猜测 |
| provider DLL | 已登记热点 kernel | 整套科学算法、调度 |
| catalog DLL | Gaia 等数据访问和缓存合同 | plate solve 科学求解 |

`common` 只保留 POD/value/header contracts，不能成为全项目万能 DLL。第三方 CFITSIO/zlib/zstd/lz4 由 I/O 私有封装，不泄漏进模块 ABI。HiPS Browser、Qt 和 ACR/CUDA 不进入 product manifest。

## 5. Phase 内部 DAG

每个 Phase 启动独立 Runtime 实例。默认 pipeline 文件是声明式 JSON；不嵌入 TypeScript/JavaScript VM。DSL 提供类似 TypeScript 的静态类型检查：端口 type/schema/unit/coordinate/shape/invalid policy 必须匹配。

### Phase1

```text
read → calibration → cosmetic → star_detection → psf → wcs
     → photometry → noise → drizzle → hips_writer
```

允许按明确依赖并行的只读分析节点，但每节点只运行一次，并以 typed artifact 连接。

### Phase2

```text
input_manifest → coverage → sampling → upm_fit → upm_apply
               → rejection → integration → hips_writer
```

必须明确 signal、variance/ivar、weight、support、coverage、validity、rejection mask 的不同数据类型；不得把 support/coverage 当科学权重。

### Phase3

```text
input_hips → projection_plan → resample_blocks → fits_stream_writer
```

投影/重采样/写出是真实独立节点，不允许三个节点重复调用一个完整 `p3_session_run`。

## 6. 静态图与真实运行图

每次 run 必须生成：

```text
run-plan.json
run-graph.json
run-graph.dot
run-graph.svg
run-trace.jsonl
resource-timeseries.csv
resource-summary.json
artifact-manifest.json
```

`run-plan` 是计划；`run-trace` 是观测。trace 至少记录实际 DLL/hash/build ID/entrypoint/provider/workers/artifacts/call count/timing/errors。禁止把配置的预算、预计 provider 或硬编码 `baseline` 写成实际观测。

## 7. 迁移完成定义

只有同时满足以下条件，一个旧组件才可退出：

1. 新 module manifest、README、SCI/ALG/API/DATA/TEST 链完整；
2. 独立 DLL/`.so` 加载和负面 ABI 测试通过；
3. 新节点只执行声明操作；
4. 旧函数直调与新 DLL 调用的小合成等价通过；
5. 资源 plan 和实际 trace 一致；
6. 无旧调用者的机器检查通过；
7. 单独删除旧入口的 commit 已验证并 push。

不允许以“新目录已建立”“DLL 文件存在”“pipeline 图好看”作为迁移完成。
