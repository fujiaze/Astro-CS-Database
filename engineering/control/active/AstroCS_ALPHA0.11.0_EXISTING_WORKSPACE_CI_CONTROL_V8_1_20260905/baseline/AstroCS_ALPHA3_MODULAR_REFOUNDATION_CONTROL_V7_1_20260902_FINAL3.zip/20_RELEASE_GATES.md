# Alpha 0.11.0 发布门禁

## 严重级别

- **P0**：科学定义/数据/ABI/线程模型/安全加载/结果完整性错误，或 validator/trace 造假/崩溃；不得发布。
- **P1**：关键功能缺失、接缝/守恒失败、Windows/Win10/工具链证据缺失、DLL/文档映射不一致、heavy 低利用率；不得发布。
- **P2**：非关键可维护性、次要文档缺口、性能改进建议；可带 owner review，但必须登记。
- **P3**：排版/未来增强；不影响候选状态。

## Gate 规则

| Gate | 必须全部满足 | 失败结果 |
|---|---|---|
| G0 | 起点 SHA、main、主机、工作区、控制包 | `PACKAGE_INVALID` 或 `NOT_READY` |
| G1 | SCI/ALG/DATA/API/ARCH/线程/ABI/Phase3 合同 | `NOT_READY` |
| G2 | 唯一 CMake、真实 DLL loader、ArtifactStore、共享 executor/trace | `NOT_READY` |
| G3 | 19 组模块 DOC/TEST/IMPL/INT 全闭环 | `NOT_READY` |
| G4 | 旧路由/静态 factory/连续 phase/伪 trace 删除 | `NOT_READY` |
| G5 | Linux static/light/synthetic 全通过 | `NOT_READY` |
| G6 | Windows clean build、ABI、provider、heavy、Win10 smoke、Win11 full、一次 32R | `BLOCKED_EXTERNAL` 或 `NOT_READY` |
| G7 | L0-L3、AST/图、注释、依赖、追溯、历史清理 | `NOT_READY` |
| G8 | 独立审计当前 SHA、P0/P1=0、白名单三层复验 | `READY_FOR_OWNER_REVIEW` |

## 强制科学/性能门

- Phase1/2/3 必须分别启动、分别 `plan/run/inspect`；没有 `--phases` 连续入口。
- 重 CPU span 必须 `resource_class=cpu_heavy`、`work_units>1`、动态 lease；若计划并行度 1，没有 `tiny_work`/`serial_reason` 立即 FAIL。
- heavy 连续 ≥5s：平均归一化利用率 U≥0.80；≥70% 样本≥0.75；可运行工作连续 10s 不得低于 0.50；2/1 worker speedup≥1.60（以 Windows 现场为正式证据）。
- 结果必须通过独立合成 oracle、属性、负测、接缝/守恒/单位/NaN/确定性；历史版本全量差分不是必需条件。
- 无 benchmark/profile 时只能 baseline；provider 选择不能硬编码 CPU 核心数或“AVX-512 必快”。

## 最终 verdict

```text
package/hash/schema invalid                   -> PACKAGE_INVALID
P0 或 P1、Gate FAIL、关键科学测试 FAIL      -> NOT_READY
外部 Windows/真实数据资源尚未在线            -> BLOCKED_EXTERNAL
全部 Gate 通过且仅 P2/P3                     -> READY_FOR_OWNER_REVIEW
```

Agent 不得自行把 `READY_FOR_OWNER_REVIEW` 改成 `RELEASED`，不得用 waiver 掩盖 P0/P1。

