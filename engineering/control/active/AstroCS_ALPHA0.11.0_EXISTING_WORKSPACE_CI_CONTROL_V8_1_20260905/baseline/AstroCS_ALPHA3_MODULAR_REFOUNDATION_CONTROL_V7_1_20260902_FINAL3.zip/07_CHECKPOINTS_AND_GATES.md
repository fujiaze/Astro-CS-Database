# 检查点、自动 Gate 与推进

检查点是机器记录和自动判定，不是等待负责人逐关批准。前台必须自动推进所有不依赖失败项的工作；只有真实外部阻断或最终审核结果才联系负责人。

## G0 起点事实

必需：控制包校验、main/origin/main/HEAD、dirty 外部变化、主机资源、工作区/锁/账本、AUD-001。失败：控制包 invalid、未知提交/非快进、工作区无法隔离、来源不明修改。证据：身份、host、workspace、初始 finding。

## G1 合同冻结

必需：工程约束入 main、active/history 索引、唯一 VERSION、C ABI、Data/Product、Phase isolation、DAG、ThreadBudget、日志、CPU profile、Phase3 SCI/ALG、module DOC、testkit schema。失败：公式/单位/版本命名含糊；phase 仍暗示顺序；ABI 传 STL；资源合同缺门限；模块没有负责人。

## G2 宿主骨架

必需：唯一 CMake、固定 toolchain preset、SHARED noop/runtime/io/baseline targets、安全 loader、dynamic registry、ArtifactStore production wiring、shared executor/ThreadBudget、真实 trace/monitor、独立 CLI 命令。失败：科学算法仍静态塞 CLI；第二构建入口；伪 `ThreadLease::make`；无监控 heavy 运行能成功；DLL 缺失仍静态 fallback。

## G3 模块真实执行

对 `MODULE_MIGRATION_MATRIX.csv` 每行执行 DOC/TEST/IMPL/INT；所有模块 manifest/README/CTest/ABI/typed ports/plan/trace/合成 oracle 通过；Phase1/2/3 内每节点一次真实入口。失败：节点重复整 Session；module 只注册不执行；测试期望由生产函数生成；科学变更未分 task；资源低利用率。

## G4 旧路由移除

必需：无旧调用者；删除 partial session adapters/static factory/第二 CMake/`--phases`/假 artifact/旧 standalone stage2/伪 trace；每删除项独立 commit。失败：仍可走旧生产路径或新路径不完整。

## G5 Linux 控制

必需：轻量 compile、全 machine checks、模块小合成、sanitizer、运行图、监控冒烟、包预检。Linux PASS 只限控制节点，不能推出 Windows/32R/HiPS 浏览器性能；Windows 项可 WAITING_RESOURCE。

## G6 Windows 发布验证

必需：固定 MSVC clean build、PE/ABI/loader、全模块合成、CPU benchmark/provider、heavy 资源门、三 Phase independent、Win10 22H2 smoke、Win11 full、一次 32R、HiPS/FITS/fitsverify、发布 manifest。失败：任一 P0/P1、Windows 证据旧 SHA/缺失、低利用率、单线程 heavy、Win10 未证实却声称支持。

## G7 文档/质量收敛

必需：L0/L1/L2/L3、AST API、Doxygen/Graphviz、source symbols/exports/README/YAML/CMake、stale docs、secret/license/SBOM、完整 traceability、注释审查。失败：active 陈旧版本/路径、validator crash/漏查、函数名漂移、SCI/ALG/SRC/TEST 断链。

## G8 独立终审/打包

必需：AUD-005 在 final SHA 只读复审；每 finding 有证据；P0/P1=0；task/gate/evidence 计数机器重算；白名单包三层复验。输出 `READY_FOR_OWNER_REVIEW`、`NOT_READY`、`BLOCKED_EXTERNAL` 或 `PACKAGE_INVALID`，不能 `RELEASED`。

## 自动判定

## 机器化 Gate 任务集合

Gate evaluator 只读取下表和 TASK_STATE/evidence/findings，不接受手写 counts 或 status。Gate 本身不是 task dependency；任何 task 禁止依赖 G0-G8。每个集合在该 Gate 计算前必须全部 CLOSED，证据必须是当前 main SHA。

| Gate | required task 集合 |
|---|---|
| G0 | CTL-001;ID-001;ID-002;ID-003;AUD-001 |
| G1 | GOV-001;GOV-002;GOV-003;GOV-004;GOV-005;DOC-001;TST-001;ARC-001;BLD-001;DATA-001;DATA-002;LOG-001 |
| G2 | BLD-002;BLD-003;ABI-001;ABI-002;ABI-003;ABI-004;ABI-005;CLI-001;CLI-002;RT-001;RT-002;RT-003;RT-004 |
| G3 | 全部模块 DOC/TEST/IMPL/INT；P1/P2/P3 装配 INT |
| G4 | P1-LEGACY-RETIRE;P2-LEGACY-RETIRE |
| G5 | LNX-002;LNX-003;LNX-004;LNX-005;LNX-006;AUD-002 |
| G6 | WIN-003;WIN-004;WIN-005;WIN-006;WIN-007;WIN-009;WIN-010;WIN-011;WIN-012;WIN-013;WIN-014;AUD-003 |
| G7 | QA-001;QA-002;QA-003;QA-004;QA-005;QA-006;QA-007;QA-008;AUD-004 |
| G8 | AUD-005;FG-VERIFY-001;PKG-001;PKG-002;PKG-003;GATE-OWNER-001 |

G3 的完整模块集合由 TASK_LEDGER.csv 中 kind=module-* 的 task 自动展开，禁止手写子集。真实 32R 只由 WIN-010 产生，其他报告引用同一 evidence ID；P1/P3 真实样本不得另起相同运行。

```text
package/schema/hash/path invalid                  → PACKAGE_INVALID
任一 P0/P1、Gate FAIL、Task FAIL          → NOT_READY
Windows关键证据/Win10现场/外部数据长期缺失 → BLOCKED_EXTERNAL
关键 E3/E4 证据缺失或独立 reviewer 非 ready → NOT_READY
上述均无且 owner review 材料完整          → READY_FOR_OWNER_REVIEW
```

P2/P3 不能由 Agent 自行 waiver；如需负责人选择，列 `WAIVER_REQUIRED`，不隐瞒。
