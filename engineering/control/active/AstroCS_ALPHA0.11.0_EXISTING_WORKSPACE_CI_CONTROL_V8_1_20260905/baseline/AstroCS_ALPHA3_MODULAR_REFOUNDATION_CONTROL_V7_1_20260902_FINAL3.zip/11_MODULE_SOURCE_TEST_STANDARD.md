# 模块源码、README、测试与目录标准

## 1. 模块是最小可拥有单元

一个 module 必须能独立理解、构建、加载、测试和替换；模块 owner 对源码、SCI/ALG/API/DATA/TEST 链和证据负责。Phase Session 只装配，不拥有算法。

## 2. 固定目录

```text
modules/<phase>/<module_id>/
  README.md
  module.yaml
  CMakeLists.txt
  include/astrocs/<module_id>/public_api.h
  include/astrocs/<module_id>/types.h
  src/module_entry.cpp
  src/*.cpp
  tests/CMakeLists.txt
  tests/unit/
  tests/properties/
  tests/oracle/
  tests/fixtures/  # generator优先，禁止大二进制
  tests/negative/
  tests/performance/
```

## 3. README 固定章节

1. `MOD-*` ID、DLL target、module/ABI/doc revision、owner、状态；
2. 负责/不负责；
3. 输入/输出 ports、DATA ID、单位、坐标、dtype、shape、invalid；
4. SCI/ALG/API/ARCH/TEST 链接；
5. public entry 和实际主要 source symbols；
6. config schema/default/错误码；
7. threading/parallel axis/lease/memory/I/O/cancel/checkpoint；
8. provider 能力和 fallback；
9. oracle/property/boundary/performance/容差来源；
10. build/test 命令、已知限制、未实现项。

README 不能写“已实现”而没有当前 evidence ID；函数签名由 AST 索引核对，不得手抄另一版本。

## 4. module.yaml 必填

```yaml
id: MOD-...
module_id: astrocs.p2.integration
dll_name: astrocs_p2_integration.dll
module_version: 0.11.0-alpha.1
abi_version: 1
phase_scope: phase2
node_operations: [integrate]
entrypoint: astrocs_module_query_v1
input_ports: []
output_ports: []
science_contracts: []
algorithm_contracts: []
data_contracts: []
api_contracts: []
source_symbols: []
test_ids: []
threading_model: host_executor_lease
resource_class: cpu_heavy
cpu_providers: [baseline, avx2, avx512]
determinism: fixed_reduction_order
```

实际字段可扩展，但不得删除必填项或把未知写成空字符串；未知状态写 `MISSING` 并 FAIL。

## 5. 测试复用规则

`tests/testkit` 只含 harness、seed RNG、临时目录、artifact fixture、report writer，不含生产算法。每模块的测试 label 为 `module:<module_id>`，测试元数据包含：当前 commit、配置 digest、seed、input/output hash、oracle、tolerance source、workers/provider、命令/退出码。

独立 oracle 不能调用同一个生产 symbol 或复制同一公式；可以使用解析解、朴素高精度参考、隔离 test-only WCSLIB/HEALPix。大 fixture 用 generator；若必须二进制，单文件≤256 KiB、模块总量≤2 MiB并列来源/hash。

## 6. 必备测试类型

- unit：单函数/端口/错误码；
- properties：常数保持、守恒、单调、边界、不变量；
- oracle：独立参考；
- negative：坏输入、缺 DLL、错误 ABI、NaN/Inf、取消、磁盘满、重复 publish；
- performance：1/N worker、provider/ISA、内存/IO/队列、确定性；
- integration：只与直接上/下游连接，不隐式拉入其他 Phase。

没有故障注入、没有独立期望、没有当前 commit 记录的测试不得作为关键通过证据。
