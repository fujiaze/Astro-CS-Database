# 科学/服务模块四任务迁移模板

`MODULE_MIGRATION_MATRIX.csv` 每一行严格展开为 `<prefix>-DOC/TEST/IMPL/INT`，不得合并提交。

## `<prefix>-DOC`：冻结合同与 README

输入：现有源码、历史科学文档（仅作材料）、matrix 的科学专项。  
动作：

1. 查出真实当前函数、输入、输出、单位、坐标、dtype、shape、invalid、错误、并发、内存、I/O；不相信旧 README。
2. 明确模块负责/不负责；禁止整 Phase 行为。
3. 从 SCI 推导 ALG；列连续数学定义、离散公式、近似、边界、复杂度、误差来源。
4. 定义 DATA/API、配置 schema、C ABI adapter、plan、execute、cancel、inspect。
5. 列出唯一生产源符号和计划迁移旧符号。
6. 先写合成 fixture、独立 oracle、不变量、负面、串并行、ISA、资源测试设计及冻结容差。
7. 写 `README.md` 和 `module.yaml`；所有 ID 可机器解析。

产物：SCI/ALG/API/DATA 更新、README、module.yaml、trace row。  
验收：文档和 manifest schema；ID/链接/符号存在；不含“IMPLEMENTED”无证据陈述；独立 reviewer 核对公式与源实现差异并记录。  
禁止：改生产算法；根据代码错误反向修改 SCI。

## `<prefix>-TEST`：先建立可复用验证

1. 在模块 `tests/{unit,properties,oracle,fixtures,negative,performance}` 建立 CMake target/CTest label。
2. fixture 由固定 seed+参数生成，不提交大二进制。
3. oracle 不调用被测函数、不复制同一实现；可用解析解、高精度朴素实现或许可隔离的测试参考库。
4. 覆盖正常、空/单元素、边界、NaN/Inf、invalid、取消、错误、确定性、1/N worker。
5. 尚未迁移前，测试应能调用冻结旧实现或明确以 expected-fail 捕获缺陷；不得写永远 PASS 的占位。
6. 每个 threshold 在测试元数据中引用 ALG 段落，不能事后改。

产物：测试源码、fixture generator、oracle、CTest 注册、expected baseline report。  
验收：测试可单独运行；故障注入能让测试失败；覆盖 matrix 专项；无生产函数生成期望值。

## `<prefix>-IMPL`：迁移到独立模块

1. 通过 C ABI adapter 包装/迁移现有实现；一个 `execute` 只完成本模块操作。
2. 输入为 typed artifact handles，输出为事务 sink；禁止任意拼路径。
3. heavy 工作使用 host executor/lease；不得私建 pool 或硬编码 worker。
4. 错误/异常转换稳定 status，日志/metrics/cancel 走 host。
5. `plan()` 由输入元数据计算 work_units/memory/I/O/parallel axis/min/max workers。
6. DLL 内捕获全部 C++ exception；跨边界内存使用 host allocator/opaque handle。
7. 直调旧实现与 DLL 调用在 frozen fixtures 上比较；非 SIMD/归约变化默认 bitwise。

产物：public/internal source、DLL target、adapter、direct-vs-plugin report。  
验收：DLL/`.so` 构建；export 只有批准 C ABI；负面 ABI；全部模块测试。
默认迁移任务的 scope 为 `scientific_change=false`；但是 Phase3 的投影、重采样
和 FITS WCS 是本轮新增科学实现，必须明确写 `scientific_change=true`，并附 SCI
reviewer 签核、WCS Paper I/II 与独立 WCSLIB/HEALPix oracle 证据。只有纯 I/O
复用或不改变数学定义的搬迁才可声明等价迁移。

## `<prefix>-INT`：注册和 Phase DAG 接入

1. 生成本模块 integration descriptor、typed ports 和调用计数测试；不直接修改全局 pipeline。
2. 由 SA-RT-05 的 assembly task 在主线注册节点且只调用一次本 module entry；调用计数测试必须准确。
3. 输入/输出端口由 Pipeline compiler 静态校验；运行时 ArtifactStore 真实传 handle。
4. plan/trace 显示真实 DLL、entry、worker、provider、artifact；不得填预测值。
5. 缺 DLL、重复 ID、错误 ABI/hash、节点重复执行必须失败。
6. 与上游/下游最小合成 integration 通过后，才标记旧入口可退出；退出在 W4 单独 task。

产物：pipeline JSON/registry/install manifest/integration tests/plan+trace。  
验收：static graph 与 runtime call counts 一致；无 hidden session；阶段隔离；资源 trace 通过。
