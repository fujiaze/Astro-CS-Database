# Phase1 模块与装配任务

## 1. 固定迁移顺序

`CAT-GAIA → P1-CAL → P1-COS → P1-STAR → P1-PSF → P1-WCS → P1-PHOT → P1-NOISE → P1-DRZ → P1-HIPS → P1-SESSION`。

每个前缀严格执行模板的 DOC/TEST/IMPL/INT 四 task；matrix 的 `depends_on_int` 是硬依赖。不能把多个模块合并成“Phase1 全部迁移”一个任务。

## 2. P1-SESSION-DOC（SA-P1-R19）

写 Phase1 assembly README/contract，只描述装配和本阶段 DAG，不定义校准、星点、WCS、噪声或 drizzle 公式；列所有节点、端口、artifact schema 和外部输入。  
验收：文档不宣称 session 自己完成算法；每节点能指到 module ID/entry/TEST；不含 Phase2/3 edge。

## 3. P1-SESSION-TEST（SA-P1-R19）

建立 Phase1 小链测试：mock 每个 module entry 记录调用次数、输入输出 handle、顺序和失败传播；真实模块用最小合成 frame。  
验收：每声明节点恰好调用一次；缺任何模块/错误 ABI/坏 artifact/取消不会写完成 manifest；仅 Phase1 run ID。

## 4. P1-SESSION-IMPL（SA-P1-R19）

删除 `p1_session_run` 作为隐藏全链实现的职责；assembly 只编译/执行 typed DAG，不能直接访问子模块内部函数、路径或私池。保留旧 session 仅作兼容测试直到 W4。  
验收：调用图中 assembly 不包含科学算法实现；plan/trace 节点和真实 DLL 对应；Phase2/3 未加载。

## 5. P1-SESSION-INT（SA-P1-R19）

注册 Phase1 default pipeline；运行 `astrocs phase1 validate|plan|run|inspect`。输出每帧标准 HiPS + manifest，不能输出 Phase2 mosaic。  
验收：CLI 独立新进程可运行；输出 hash/provenance；小合成链完整；性能 heavy 节点资源证据；旧路径还未删除前用 direct-vs-plugin 报告守住科学结果。

## 6. P1-SEAM-001（SA-P1-D18，commit）单帧边界/接缝合成验收

使用恒定场、三维方向余弦线性场、梯度、点源和跨 tile/order/seam 的确定性 HiPS fixture；检查 drizzle 映射、support、mask、flux conservation、单帧无规则摩尔纹。  
验收：指标来自 `SCI/ALG`；不得以肉眼“差不多”；保存每 tile/boundary residual、coverage histogram、输出小预览。

## 7. P1-REAL-SAMPLE（SA-WIN-30，只读证据）

Windows 在线时只取少量已哈希真实 R 帧辅助：校准→单帧 HiPS→manifest，记录异常但不替代合成测试。不得在 Linux 2c2g 跑大批量。

## 8. P1-LEGACY-RETIRE（SA-P1-R19，W4）

先运行 `validate_no_callers.py --symbol p1_session_run`、调用图和 direct-vs-plugin 证据；再单独删除旧生产入口/静态 adapter。保留历史源码只能移入 `docs/archive` 或 `engineering/control/archive`，不能继续构建。  
验收：删除后全量轻编译、模块测试、Phase1 最小 run 和 independent reviewer PASS；一个 commit 仅删除旧路由。
