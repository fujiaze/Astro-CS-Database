# Phase3 球面到平面 FITS 任务

## 1. 固定产品边界

Phase3 是独立 `astrocs phase3` 产品：输入任一符合 HiPS/FITS DATA 合同的产品，输出平面 FITS + provenance；不做校准、测光、UPM、排异、积分、STF、去噪，也不能隐式调用 Phase1/2。

## 2. P3-PROJ-DOC（SA-P3-P25）

逐投影冻结 SCI/ALG/API：TAN、SIN、ZEA、CAR、AIT；正逆变换、域、奇点、经纬 wrap、frame、CRPIX/CRVAL/CD、单位、NaN/MASK 语义。引用 FITS WCS Paper I/II；不能把 hand-coded tangent approximation 写成标准 WCS。  
验收：每投影有公式/定义域/边界/不支持参数；生成 golden vectors，期望值不调用生产代码。

## 3. P3-PROJ-TEST（SA-P3-P25）

每投影至少测试中心、四角、四边中点、wrap 两侧、极区/边界、奇点/域外和 100 个固定伪随机点；pixel↔sky round-trip 与独立 WCS oracle。  
建议门限：内部点角误差 ≤1e-10 rad；边界压力点分类一致且角误差 ≤1e-8 rad；round-trip ≤1e-7 pixel。边界门限只能在 ALG 文档中冻结，不能测试后调宽。

## 4. P3-PROJ-IMPL（SA-P3-P25）

实现双向 pixel-center mapping：`pixel→intermediate plane→native inverse→celestial
inverse Euler`，以及 `celestial→native forward Euler→native forward projection→pixel`；
数组 `(x,y)` 与 FITS `(x+1,y+1)` 明确；投影显式选择，禁止自动换投影；写标准
`CTYPE/CUNIT/CRPIX/CRVAL/CD/RADESYS`，不同时写 PC/CDELT/CROTA；域外写 NaN + MASK。
验收：projection code 改变确实改变 sky coordinates；invalid 不被夹到边界；
`CRVAL/LONPOLE/LATPOLE` 驱动 Euler；ICRS/Galactic frame 无猜测转换。

## 5. P3-RSMP-DOC/TEST/IMPL/INT（SA-P3-S26）

必须显式 `source_order: integer|auto`；整数必须在合法范围且真实决定读取 tile order；auto 按源 cell angular scale 与目标 pixel scale 选择，tie 规则写文档；provenance 写实际 order。该重采样实现属于新增科学实现，scope 必须 `scientific_change=true`，有 SCI reviewer 签核和独立 HEALPix/WCS oracle。

实现并区分：

- `nearest`：逆投影→选定 HEALPix order 的 `ang2pix_nest`→唯一 cell→读对应 tile/pixel；
- `healpix_interp4`：目标点上下 iso-latitude ring 各取两点，周期经度处理，四权重非负且和为1；任一缺失/NaN/invalid 时 SCI NaN、support partial、MASK bit4，不剩余权重重归一。

禁止 quadrant-nearest 冒充 bilinear；禁止 sampler 无视 `order_sel` 读取最深实际 order；variance 仅按 `Σw² Var` 传播且声明无空间协方差。

测试：常数、方向余弦线性场、cell-id 编码、order 不同常数、seam、极区、missing、partial coverage、NaN、mask/support、1/N 确定性；独立 HEALPix 3.83/高精度 oracle（仅 test-only，许可证隔离）。

## 6. P3-FITS-DOC/TEST/IMPL/INT（SA-P3-F27）

输出 Primary `SCI`、`SUPPORT` float32、`MASK` uint8 和声明的 ancillary planes；mask bits 0..5 语义固定；每 HDU 尺寸/WCS/BUNIT/EXTNAME/`DATASUM/CHECKSUM`；fitsverify。  
采用二维 block/行块流式写；共享有界 cache、completed-block queue、writer 可串行但 compute heavy 必须用 shared executor；不分配完整 signal+coverage+mask。唯一输出名来自配置，默认不覆盖，临时→验证→hash→原子 rename→完成 manifest。WCS header/FITS 输出实现属于新增科学实现，scope 必须 `scientific_change=true`，有 SCI reviewer 签核和独立 WCS oracle。

验收：4096² 与 16384² 虚拟输出峰值 RSS 比 ≤1.25（固定 block/cache）；中断不写完成；不同输出路径并行不覆盖；缺 tile/域外/invalid/missing 分离；性能 U≥0.80。

## 7. P3-SESSION（SA-P3-X28）

assembly 只装 projection→resample blocks→writer；三个 node 各一次、各真实入口；Phase3 命令可从任意兼容 fixture 独立启动；缺 Phase1/2 不影响；无旧完整 `p3_session_run` fanout。

## 8. P3-REAL-SAMPLE / 浏览审核（SA-WIN-30）

先在合成 fixture 完整验证五投影，再从真实 HiPS 取最小样本确认 header/order/单位/显示；大规模输出只在 Fatduck final candidate 执行。生成 FITS 预览、mask/support 预览、WCS 信息和 HiPS/FITS viewer 打开说明；图像仅辅助人工审核，不替代数值 oracle。
