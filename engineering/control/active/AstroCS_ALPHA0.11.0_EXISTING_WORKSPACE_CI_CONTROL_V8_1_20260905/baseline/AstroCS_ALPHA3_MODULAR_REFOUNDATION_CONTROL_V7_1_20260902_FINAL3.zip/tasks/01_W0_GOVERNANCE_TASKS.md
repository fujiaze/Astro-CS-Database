# W0/W1 治理与事实任务

## CTL-001（FG-000，无 commit）控制包校验

动作：对 ZIP 外部 hash（若有）、路径安全、`SHA256SUMS`、`CONTROL_MANIFEST.json`、必需文件、YAML/CSV/JSON 和 task/owner/dependency 运行 `validators/validate_control.py`。  
证据：`CONTROL_VALIDATION.json`、stdout/stderr、控制包 SHA。  
PASS：唯一输出含 `CONTROL_PASS` 且 exit 0。validator 异常或缺依赖为 FAIL。

## ID-001（FG-000，无 commit）仓库身份冻结

动作：fetch；保存 HEAD/main/origin/main、ancestor、remote 脱敏、status porcelain v2、submodules、worktree list。执行基线前进流程。  
证据：`SOURCE_START_IDENTITY.json`、`BASELINE_DELTA.csv`、`EXTERNAL_WORKTREE_CHANGES.md`。  
PASS：正式集成起点是干净 main 且等于 origin/main；用户 dirty state 未被修改。

## ID-002（FG-000，无 commit）主机与远程资源冻结

动作：Linux CPU/RAM/disk/OS/tool versions/cgroup quota；Fatduck 连接状态和 OS，仅一次探测。不得输出凭据。  
证据：`HOSTS_START.json`。  
PASS：字段完整；Windows 离线可记 WAITING_RESOURCE，不阻断 W0。

## ID-003（FG-000，无 commit）worktree/锁/账本

动作：在工作根创建 marker、固定 owner detached worktree、locks/dispatch/returns/logs；初始化 ledger，验证没有新 branch。  
证据：`WORKSPACE_LAYOUT.json`、`git worktree list --porcelain`、branch before/after。  
PASS：所有 worktree 在工作根，均 detached，主仓仍 main。

## AUD-001（SA-AUD-99，只读）已知问题初始快照

严格执行 `17_INDEPENDENT_REVIEWER.md` 的 IR-010..IR-180；逐项给出当前代码 `STILL_PRESENT/CONFIRMED_FIXED/INCONCLUSIVE`，不得采用旧 audit SUMMARY。  
证据：`BASELINE_KNOWN_ISSUES.csv`、初始命令记录。  
PASS：25 个固定问题全部有文件/符号/命令/证据等级。

## GOV-001（SA-GOV-01，commit）工程约束进入 main

动作：将本包 `01_OWNER_FROZEN_CONSTRAINTS.md` 的项目级内容整理为根 `AstroCS_ENGINEERING_CONSTRAINTS.md`；精简 `AGENTS.md` 只指向约束、memory、相关模块文档和 Linux/Windows角色，不复制长文。  
验收：文件受 Git 跟踪；机器索引能找到；与本包 hash/修订关系记录；无 Git Bash/默认 PowerShell 开发错误。  
commit：`docs(governance): GOV-001 冻结Alpha工程约束`。

## GOV-002（SA-GOV-01，commit）活动/历史/生成/控制文档边界

动作：枚举全部 md/rst/txt/控制包；生成 `docs/DOCUMENT_INDEX.yaml`，每项唯一标 `ACTIVE_NORMATIVE/ACTIVE_INFORMATIVE/GENERATED/ARCHIVED_NON_NORMATIVE`；移动历史控制文档到 `engineering/control/archive/<date-or-version>/`，历史技术文档到 `docs/archive/`；不得删除有科学来源价值的文档。  
验收：根无散落旧控制包；active index 不包含 archive；archive 每文件头含 `ARCHIVED` 和替代文档链接；所有移动由 Git 追踪。  
commit：`docs(governance): GOV-002 归档非当前工程文档`。

## GOV-003（SA-GOV-01，commit）唯一产品版本源

动作：根 `VERSION` 设 `0.11.0-alpha.1`；定义 product/module/ABI/data-schema/doc-revision/history 五个版本命名空间；CMake/CLI/L0 从根 VERSION 生成产品版本，禁止手抄。  
验收：`astrocs version --json` 预期 schema；active 文档/配置无另一个产品版本；FITS 4.0、HiPS 1.0、ABI v1 不被误判。  
commit：`build(version): GOV-003 统一Alpha版本事实源`。

## GOV-004（SA-GOV-01，commit）L0 负责人文档骨架

动作：建立 `REVIEW.md` 及 `docs/owner/{SCIENCE_OVERVIEW,PIPELINE_OVERVIEW,ARCHITECTURE_OVERVIEW,RELEASE_STATUS,CHANGE_REVIEW}.md`；只汇总权威来源，不复制函数清单；每项使用 PASS/FAIL/NOT_VERIFIED。  
验收：负责人只从 REVIEW 可到全部 L0；三 Phase 隔离、Windows优先、ACR dormant、Phase3 状态一致；没有未验证“已实现”。  
commit：`docs(owner): GOV-004 建立负责人审查入口`。

## GOV-005（SA-GOV-01，commit）旧现状清理与 memory 收敛

动作：逐项审查 README/HANDOVER/memory/CHANGELOG；把 V18/V19/F盘/16线程/11子仓/Python调用DLL/连续Phase 等失效现状迁入 history；memory 只留稳定目标、当前 SHA/版本、模块索引、开放问题。  
验收：`validators/validate_docs.py` 与候选源码 active-index 扫描无 stale-active；不能机械替换标准版本号；CHANGELOG 新增 current alpha 节。  
commit：`docs(governance): GOV-005 清理陈旧现状与记忆`。

## DOC-001（SA-QA-29，commit）追溯 schema

动作：定义 ID 格式、唯一性、跨层关系、CSV/JSON schema 和 source symbol 表达；给每个模块建立空缺显式为 `MISSING` 的初始矩阵。  
验收：不能以空字符串通过；SCI→ALG→DATA/API/ARCH→MOD/SRC→TEST→EVIDENCE 每层必填；机器检查输出具体断链而不崩溃。  
commit：`test(traceability): DOC-001 建立机器追溯合同`。

## TST-001（SA-QA-29，commit）模块测试结构与报告合同

动作：建立 `tests/testkit` 和测试元数据 schema；规定 unit/properties/oracle/fixtures/negative/performance labels、seed、tolerance source、current commit、provider/workers。  
验收：测试可按 `module:<id>` 选择；禁止生产函数生成期望；故障注入证明 harness 会失败。  
commit：`test(testkit): TST-001 冻结模块验证结构`。
