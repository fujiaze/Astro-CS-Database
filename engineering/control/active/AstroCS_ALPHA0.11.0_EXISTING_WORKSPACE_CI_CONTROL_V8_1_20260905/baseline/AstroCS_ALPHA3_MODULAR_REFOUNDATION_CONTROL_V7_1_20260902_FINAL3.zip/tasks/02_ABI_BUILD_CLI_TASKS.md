# 构建、C ABI、加载器与 CLI 任务

## ARC-001（SA-ABI-03，commit）Windows 产品拓扑与 DLL 边界合同

按 `03_TARGET_PRODUCT_AND_ARCHITECTURE.md` 写 ARCH/API；列每个 DLL 唯一责任、依赖方向、导出入口、host service。生成禁止依赖矩阵：CLI→科学实现、module→第三方 I/O、module→私池、跨 DLL STL 均禁止。  
验收：CMake target 计划与安装树一一对应；无“每小函数一个 DLL”或万能 common。  
commit：`docs(architecture): ARC-001 冻结DLL产品边界`。

## BLD-001（SA-BLD-02，commit）固定工具链与 preset

实现 `09_WINDOWS_TOOLCHAIN_LOCK.md`：提交 `.vsconfig`、CMakePresets、toolchain verifier；Windows 正式 generator 只能 VS17 2022，x64/v143/14.44.35207/SDK26100/CMake3.31.12；Linux preset 仅轻验证。  
验收：preset JSON schema；错误 VS/SDK/toolset 必须快速失败；无 `latest`、MinGW/MSYS、VS2026、Ninja 正式路径。  
commit：`build(msvc): BLD-001 冻结Windows发布工具链`。

## BLD-002（SA-BLD-02，commit）唯一根 CMake 构建图

动作：根 CMake 是唯一入口；子目录只声明本 target；移除 `cli/CMakeLists.txt` 和 `lib/phase2/CMakeLists.txt` 的第二产品事实源（若替代尚未接入可先变 compatibility target，禁止正式 install）。  
验收：CMake File API 显示唯一 `astrocs` executable；无第二 `astrocs-stage2` 正式 target；显式源列表。  
commit：`build(cmake): BLD-002 统一根构建图`。

## BLD-003（SA-BLD-02，commit）DLL skeleton 与安装布局

动作：先建立 runtime/io/noop module/baseline provider SHARED targets、export visibility、RPATH/Windows install tree、licenses/schemas；科学模块尚未迁移时不得伪装完成。  
验收：clean install 仅白名单；删除 noop DLL 使 module verify 明确失败；CLI 不含 noop 实现静态副本。  
commit：`build(layout): BLD-003 建立模块化安装骨架`。

## BLD-004（SA-BLD-02，commit）依赖锁与可复现构建

动作：清点 CFITSIO/zlib/zstd/lz4/WCS test oracle 等；锁版本/来源/hash/license；移除机器绝对路径和隐式 MSYS2；若用 vcpkg 必须 manifest + baseline。  
验收：fresh configure 不读取 F盘/用户路径；生产依赖与 test-only oracle 分开；生成 SBOM 输入。  
commit：`build(deps): BLD-004 锁定依赖与许可证边界`。

## ABI-001（SA-ABI-03，commit）版本化纯 C ABI 头

定义 `status_codes.h/host_api_v1.h/module_api_v1.h/artifact_api_v1.h`：固定宽度 POD、struct_size/abi_version、opaque handles、UTF-8 spans、allocator ownership、calling convention、exception boundary。  
验收：头可被 C11 与 C++17 单独编译；layout/static_assert 32/64位预期；AST 检查无 STL/引用/模板/异常类型。  
commit：`feat(abi): ABI-001 定义模块C ABI v1`。

## ABI-002（SA-ABI-03，commit）生命周期、错误、能力协商合同

动作：冻结 query/create/validate/plan/execute/cancel/inspect/destroy/self_test 的调用时序、并发、重复调用、错误码、诊断 buffer、版本协商和兼容规则。  
验收：状态机 property tests；旧/新 struct_size 尾部扩展；错误 ABI major、空回调、double destroy 负面测试。  
commit：`test(abi): ABI-002 冻结ABI生命周期语义`。

## ABI-003（SA-ABI-03，commit）安全 loader

Windows 使用受控绝对路径、`SetDefaultDllDirectories/AddDllDirectory/LoadLibraryExW` 安全 flags；Linux 仅从 product manifest 绝对 canonical path `dlopen`。加载前后校验路径、hash、module ID、ABI/build ID。  
验收：当前目录/PATH DLL 劫持、symlink escape、hash mismatch、缺 symbol、wrong arch/ABI 均拒绝；日志不泄凭据。  
commit：`feat(loader): ABI-003 实现受限DLL加载`。

## ABI-004（SA-ABI-03，commit）动态 registry 与 manifest

动作：运行时 registry 只来自 product manifest + DLL query；检测重复 ID/版本冲突/未登记 DLL/descriptor 不一致；static factory 不再是正式路由。  
验收：module.yaml、embedded descriptor、release manifest 三方机器比对；list/verify 输出实际 hash/entry。  
commit：`feat(registry): ABI-004 接入动态模块注册`。

## ABI-005（SA-ABI-03，commit）noop/echo conformance module

动作：实现无科学含义的 echo module，覆盖 artifact read/write、host allocator、logger、metrics、cancel、executor、error；作为所有平台 ABI 探针。  
验收：Windows/Linux dynamic load；每个 host callback 有正/负测试；删除/替换 DLL 证明无静态 fallback。  
commit：`test(abi): ABI-005 增加跨平台契约探针模块`。

## ABI-006（SA-AUD-99，只读，无 commit）ABI 独立复核

对 public headers/exports/install imports 全查；确认无跨 DLL STL/exception/CRT mismatch/多余 export。输出 `ABI_INDEPENDENT_REVIEW.csv`。任何 P0/P1 返回 owner，其他任务可继续。

## CLI-001（SA-CLI-04，commit）稳定命令和 JSON/exit code

动作：实现 version/doctor/modules/config/phase1/phase2/phase3/benchmark/selftest 命令骨架；定义 stdout JSON 与 stderr 诊断、稳定退出码、UTF-8/UTF-16 path。  
验收：CLI contract tests；未知命令/坏配置/缺 DLL 明确非零；机器输出无混杂进度文字。  
commit：`feat(cli): CLI-001 冻结统一命令面`。

## CLI-002（SA-CLI-04，commit）三 Phase 进程隔离

动作：删除/拒绝 `--phases`、列表 pipeline 和进程内跨 Phase artifact binding；每个命令创建全新 Runtime、run ID 和 manifest。  
验收：negative tests 搜索与动态调用；Phase3 在无 Phase1/2 DLL 时可处理兼容 fixture；三个阶段无共享内存状态。  
commit：`refactor(cli): CLI-002 隔离三个阶段入口`。

## CLI-003（SA-CLI-04，commit）validate/plan/run/inspect 语义

动作：validate/plan 不触发科学 execute 或大 I/O；inspect 不重算；run 明确 output/overwrite/resume。  
验收：调用计数和 I/O spy；validate/plan 对大型 manifest 保持轻量；错误 schema 位置精确。  
commit：`test(cli): CLI-003 固化阶段子命令语义`。

## CLI-004（SA-CLI-04，commit）GUI 可调用进程协议

动作：冻结 JSONL event schema、progress/cancel、exit/status、run directory、stdout/stderr；不实现 GUI。  
验收：外部 harness 可启动、取消、恢复读取 manifest；CLI 无 Qt/HiPS Browser 链接。  
commit：`docs(cli): CLI-004 冻结未来GUI进程协议`。
