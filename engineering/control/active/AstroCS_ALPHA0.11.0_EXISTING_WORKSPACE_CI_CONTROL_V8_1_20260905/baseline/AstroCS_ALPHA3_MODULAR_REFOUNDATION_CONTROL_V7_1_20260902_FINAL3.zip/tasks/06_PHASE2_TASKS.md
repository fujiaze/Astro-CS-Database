# Phase2 模块、接缝与并行任务

## 1. 固定迁移顺序

`P2-COV` 与 `P2-SAMP` 可在合同冻结后并行；`P2-UPM` → `P2-REJ` → `P2-INT` → `P2-HIPS` → `P2-SESSION`。每个模块都必须 DOC/TEST/IMPL/INT 四 task；不得把七个节点包装成一个 Session。

## 2. P2-NODE-CALL-001（SA-P2-X24，commit）真实节点调用计数

建立 fake module registry 和 spy operation；编译每个 Phase2 DAG node 后，断言：module ID、entrypoint、输入 output ports、调用次数、产物类型均唯一；`coverage/sample/upm_fit/upm_apply/rejection/integration/hips_writer` 不得共享同一 function pointer。  
验收：故意把两个节点指向 `p2_session_run` 时测试必须 FAIL；旧 static adapter 不能隐藏调用。

## 3. P2-IMPL-COMPLETE-001（SA-P2-X24，commit）完整执行语义

assembly 只按 DAG 调用真实模块；确认 `upm_apply`、rejection、integration、write 的输出 artifact 都实际产生并在 manifest/provenance 中列出。删除当前只做 coverage/sample/upm_build 的 partial facade。  
验收：每个节点有运行 trace；缺一节点立即失败；最终 mosaic signal/support/variance/mask 不为空或伪造。

## 4. P2-REJ-ACCEPT（SA-P2-R22，无源码提交）排异专项验收

只用固定合成数据验证排异：frame identity 保留，策略配置真实生效，NaN、全拒绝、小样本和异常帧均由独立 oracle 判定。输出 rejection mask、保留帧清单和边界 residual。

## 5. P2-INT-ACCEPT（SA-P2-I23，无源码提交）积分专项验收

只用独立加权积分 oracle 验证 signal、variance/ivar、weight、support/coverage 分离，覆盖零权、缺帧、NaN、归约顺序和接缝窗口；报告 flux、方差传播和 coverage 误差。

## 6. P2-ASSEMBLY-ACCEPT（SA-P2-X24，无源码提交）阶段装配验收

验证 coverage→sampling→UPM fit→UPM apply→rejection→integration→HiPS writer 各节点各调用一次，静态图与真实 trace 一致，禁止完整 Session facade 重复执行节点。

## 5. P2-REAL-032R（SA-WIN-30，只读证据，W6）

从 Fatduck 取冻结 manifest 指定的 32 R + 3 masters，仅执行当前 final candidate 一次。先检查输入 hash、frame identity、配置 digest；输出 mosaic HiPS tree root hash、support/variance/mask/UPM/rejection provenance 和资源原始时间序列。  
验收：三板块所有 R 帧均被 manifest 引用；没有旧 HiPS 冒充；接缝专项指标和负责人预览齐全。

## 7. P2-LEGACY-RETIRE（SA-P2-X24，W4）

接缝的可执行验收由 P2-REJ-ACCEPT、P2-INT-ACCEPT、P2-ASSEMBLY-ACCEPT 三个任务分别完成，不得再使用一个 task 覆盖三个 owner 的职责。

## 8. P2-PERF-DESIGN（SA-QA-29，无源码提交）与 P2-PERF-001（SA-WIN-30，证据）

P2-PERF-DESIGN 先冻结 CPU-heavy、memory-bound、IO-bound、lock/queue-bound 分类及指标；P2-PERF-001 只在 Windows 对最终候选运行一次重计算并提交 effective_available_workers、granted、active、process/system CPU、grant/active/system coverage 和资源时序。低利用率必须 FAIL 或由完整分类证据解释。

## 9. 旧路由退出

在 Linux 合成、静态检查和阶段装配通过后即可执行旧路由删除任务；不得等待 Windows 32R 证据作为删除前置。Windows 只验证最终新路由，不反向决定旧路由是否可删除。

在完整执行语义、三个专项合成验收和最小 Windows run 通过后，分别删除 `p2_session_run` partial facade、静态 registry 和 `astrocs-stage2` 正式 target；每次删除一个 commit。  
验收：`validate_no_session_fanout.py`、CMake target graph、module call count、独立审计均通过；不能以“新节点注册”替代。

## 10. P2-PERF-001（SA-CPU-09/SA-WIN-30，证据 task）

使用足够工作量的合成 HiPS，不跑历史全版本；1/N worker、baseline/选定 provider；监控 compute span。  
验收：worker 来自 lease，active/granted/queue 互相吻合；平均 CPU U≥0.80；低于门限自动生成锁/IO/memory-bandwidth诊断并 FAIL，不能仅报告耗时。
