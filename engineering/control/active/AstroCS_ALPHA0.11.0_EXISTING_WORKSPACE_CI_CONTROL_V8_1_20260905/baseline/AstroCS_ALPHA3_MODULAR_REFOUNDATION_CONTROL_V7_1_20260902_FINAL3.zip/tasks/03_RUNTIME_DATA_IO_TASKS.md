# Runtime、数据、I/O、日志与运行图任务

## DATA-001（SA-DATA-06，commit）typed Artifact schema

定义 Artifact 句柄和 manifest：`artifact_id/type_id/schema_version/storage_uri/content_digest/size/producer/run/node/input_digests/config_digest/status`。字段明确单位、坐标、dtype、shape、plane、invalid policy、所有权。  
验收：JSON Schema 严格拒绝缺字段/NaN/重复 producer/未知 type；C ABI handle 不暴露路径字符串；小型 round-trip tests。  
commit：`feat(data): DATA-001 冻结类型化产物合同`。

## DATA-002（SA-DATA-06，commit）Phase 产品 manifest

分别定义 `phase1_product_v1`、`phase2_mosaic_v1`、`phase3_planar_fits_v1` 输入/输出兼容矩阵；声明跨 Phase 仅磁盘交换。  
验收：Phase3 可接受外部 fixture；Phase2 不要求 Phase1 run ID；缺 manifest/hash/schema/units 拒绝；无隐式 artifact name binding。  
commit：`docs(data): DATA-002 定义三阶段产品交换合同`。

## DATA-003（SA-DATA-06，commit）生产 ArtifactStore 接线

Runtime 启动真实 Store；模块 `execute` 只能拿已校验 handle/reader/writer；写临时对象→完整校验→hash→原子 publish；cancel/fail 无成功对象。  
验收：spy Store 证明每读写经过 Store；绕过路径/producer 重复/错误 schema/磁盘满/进程中断/取消均失败且可恢复；manifest hash 可重算。  
commit：`feat(artifact): DATA-003 接入生产ArtifactStore`。

## DATA-004（SA-DATA-06，commit）provenance 和版本语义

区分 product/module/ABI/data schema/doc revision/history；写 source commit/config/provider/worker/input hashes、science IDs。  
验收：同输入配置产生相同 provenance digest；旧 product 版本不静默接收；privacy scan 不泄露绝对用户路径/凭据。  
commit：`feat(provenance): DATA-004 完善产物溯源`。

## IO-001（SA-IO-07，commit）FITS reader/writer 流接口

将 FITS 第三方库隔离在 `astrocs_io.dll`；提供 header/plane/chunk reader、原子 writer、checksum/verify、错误码；不把 CFITSIO 类型跨 DLL。  
验收：非法 header、截断、dtype/shape/unit mismatch、checksum error、NaN/Inf、取消和磁盘满；read/write bytes 记录到 trace。  
commit：`feat(io): IO-001 建立FITS流式接口`。

## IO-002（SA-IO-07，commit）HiPS tile reader

实现 properties、NESTED tile address、tile width/order、FITS-only scientific plane、partial tree、MOC optional hint、缺 tile 状态；不父 order 静默回退。  
验收：tile width 非 2 次幂/布局不符/缺 properties/未知 frame/PNG-only/parent fallback 均拒绝；fixture 可重建。  
commit：`feat(io): IO-002 建立HiPS输入合同`。

## IO-003（SA-IO-07，commit）原子 HiPS/manifest 输出

每个输出以唯一用户路径或 run ID 目录；临时写、关闭、fitsverify、SHA256、原子 rename、最终完成 manifest；默认不覆盖，显式 overwrite 才可。  
验收：并发不同 run 不互相覆盖；中断后无完成标记；文件权限/路径穿越拒绝；tree hash 可重算。  
commit：`feat(io): IO-003 实现原子产物发布`。

## RT-001（SA-RT-05，commit）typed DAG node

定义 node `id/module_id/operation/input ports/output ports/config/resource class`；compiler 检查 phase scope、类型/单位/shape、必需端口、DAG 无环；每 node 只绑定一个真实 operation。  
验收：7 节点同 session、隐式文件路径、错类型、循环、重复 producer、跨 Phase edge 全部负测；计划图生成。  
commit：`feat(runtime): RT-001 实现类型化运行图`。

## RT-002（SA-RT-05，commit）Phase-isolated Runtime

每条 phase CLI 创建独立 Runtime/Store/RunContext；只加载本 Phase registry；跨 Phase manifest 在进程外读取。  
验收：进程内全局状态 spy；phase1 DLL 缺失不影响 phase3 外部 fixture；禁止 `--phases` 调用图。  
commit：`refactor(runtime): RT-002 隔离阶段运行时生命周期`。

## RT-003（SA-RT-05，commit）真实 ThreadBudget

将全局 `ThreadBudget::acquire/release` 接到 scheduler→RunContext→module host API；lease RAII、异常/取消回收、上限由可用资源和 profile/config 计算，不用 `ThreadLease::make`。  
验收：竞争、嵌套、超额、取消、exception、重复 run、budget=1 负测；静态检查生产路径没有伪授权。  
commit：`feat(scheduler): RT-003 接入原子线程预算`。

## RT-004（SA-RT-05，commit）唯一共享 executor

建立 CPU heavy executor 和有界 I/O executor；模块不得 `std::thread` 私建永久池；允许短 I/O 串行但需标记；OpenMP 若保留，线程由 lease 注入且禁止 nested。  
验收：私池静态扫描/运行 spy；并发任务不超预算；队列有工作时 worker 不空转；取消能唤醒等待。  
commit：`feat(scheduler): RT-004 建立共享执行器`。

## RT-005（SA-RT-05，commit）plan 真实资源估算

每 module plan 从 input metadata 计算 work_units、axis、min/max useful workers、peak memory、read/write bytes、kernel IDs、serial sections；不再固定 1/0/tiles。  
验收：不同图像尺寸/order/输出 projection 改变计划；估算与运行峰值在冻结误差范围；work_units=1 的 heavy 任务拒绝或标明 tiny。  
commit：`feat(runtime): RT-005 完善模块资源计划`。

## RT-006（SA-RT-05，commit）真实 trace 与调用计数

trace 记录实际 module/DLL/hash/build/entry/call count/worker/provider/artifact/timing/error/checkpoint；由 executor/provider/monitor 填写，禁止 config 值冒充观测。  
验收：7 个 P2 节点各一次；修改 provider/worker 反映 trace；隐藏 session/重复调用检测；JSONL 可重放到图。  
commit：`feat(trace): RT-006 记录真实运行事实`。

## RT-007（SA-RT-05，commit）cancel/error/checkpoint

统一取消 token、错误传播、节点失败、临时产物清理、恢复边界；阶段 run 不能误读另一阶段 checkpoint。  
验收：任意重节点注入 cancel/exception/磁盘满；无 false-success manifest；resume 只使用 hash/schema 匹配的已发布 artifact。  
commit：`feat(runtime): RT-007 固化取消失败与恢复语义`。

## LOG-001（SA-LOG-08，commit）结构化日志合同

日志字段：run/task/node/module/phase/commit/host/level/event/units/elapsed/diagnostic；中文可读摘要 + 机器 JSONL；敏感路径脱敏。  
验收：多线程事件顺序有 sequence；错误包含 source/symbol/status；日志 schema 检查和大小上限；无 raw testdata。  
commit：`feat(logging): LOG-001 统一结构化日志接口`。

## LOG-002（SA-LOG-08，commit）资源监控伴随器

heavy run 自动创建 monitor，同一 run ID 每秒采集 process/system CPU、active/granted workers、RSS/private/commit、read/write、queue/lock/io wait、provider/module。  
验收：无 monitor 的 `cpu_heavy` run 失败；I/O/初始化区间分开；原始 CSV 不可手工合成；Linux procfs 与 Windows PDH/ETW 适配分开。  
commit：`feat(monitor): LOG-002 自动采集重任务资源`。

## LOG-003（SA-LOG-08，commit）运行图渲染工具

从 plan/trace 生成 DOT/SVG/JSON；标出真实入口、数据边、并行轴、workers、provider、耗时、资源。Doxygen/Graphviz 仅生成文档，不改变产品执行。  
验收：图与 trace 调用计数、DLL hash、artifact hash 一致；旧手绘图不再作为规范来源。  
commit：`docs(graph): LOG-003 生成计划与实际运行图`。
