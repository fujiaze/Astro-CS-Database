# 独立审计、最终 Gate 与审核包任务

## AUD-002/AUD-003/AUD-004（SA-AUD-99，只读）阶段复核

W1、W3、W6 后，在前台提供的同一 main SHA detached read-only snapshot 上运行 `17_INDEPENDENT_REVIEWER.md` 对应章节。只写工作根 reviewer 目录；不得修代码、改 ledger、改开发 SUMMARY。源码变化后标记旧报告 superseded。

## AUD-005（SA-AUD-99，只读）最终独立报告

完整执行 IR-010..IR-180；高风险 runtime/ABI/CPU/Session/Phase3 100%；其余模块 deterministic ≥30% 且强制覆盖 exports/error/cancel/parallel/memory。每 finding 有要求/命令/exit/源码文件+symbol/原始证据/风险/修复需要/证据等级。最终仅给 `READY_FOR_OWNER_REVIEW/NOT_READY/BLOCKED_EXTERNAL`，不给发布批准。

## FG-VERIFY-001（FG-000，无 commit）最终主线复验

验证 clean `main`、HEAD/main/origin/main、全 task result/commit ledger/traceability/gates；重新运行所有非重计算 validators。不能修改独立报告。

## PKG-001（SA-PKG-31，commit）打包器和源码范围

实现 strict whitelist、source snapshot、Git tree manifest、excluded tracked 大文件清单、build input closure、denylist/secret/path/size/zip-bomb 检查；本包规则为总包目标≤20MiB、普通单文件≤5MiB、模块 fixture 单文件≤256KiB/模块总量≤2MiB。  
验收：故意放入 `.git/build/testdata/*.fits/旧zip/绝对路径/密钥` 均失败；允许唯一控制包副本和源码快照例外。  
commit：`feat(packaging): PKG-001 固化审核包白名单`。

## PKG-002（SA-PKG-31，commit）审核证据汇总

按 `18_AUDIT_PACKAGE_SPEC.md` 生成固定 `evidence/`、`source/`、`docs/`、`configs/`、`tests/`、`references/`、`provenance/` 目录；32R/HiPS/二进制以外部 manifest 引用，不能嵌入大树。  
验收：每 PASS 关联原始命令/退出码/日志/hash；计数从 ledger 重算；P0/P1/open/Windows 缺证据影响 verdict。  
commit：`feat(packaging): PKG-002 汇总可复核审核证据`。

## PKG-003（SA-PKG-31，验证 task）三层复验

用控制包可信 validator 校验最终 ZIP；解压到全新目录重验；fresh shallow clone exact final SHA + `--repo` 重验；保存 package SHA sidecar。任何异常必须具体列出而不是 traceback。

## GATE-OWNER-001（FG-000，无 commit）返回负责人审核

仅当所有 Gate 计算结果、独立报告、P0/P1/P2/P3、Win10/Win11 状态、发布限制和未完成项齐全，返回 `READY_FOR_OWNER_REVIEW`。不存在 `RELEASED/APPROVED` 自动状态。
