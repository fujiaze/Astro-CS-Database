# 机器质量与 Linux 控制节点任务

## QA-001（SA-QA-29，commit）源符号/API 提取

用 Clang AST/compile_commands 或 MSVC dump/clang-cl 生成真实 public 函数、参数、类型、导出和可见性索引；API 文档只解释，不伪造签名。  
验收：文档列出的每个 public symbol 能定位到当前文件/行；删除/改名会失败；C ABI 无 STL/exception/RTTI；compile_commands 中路径脱敏。  
commit：`test(api): QA-001 生成源符号与接口索引`。

## QA-002（SA-QA-29，commit）manifest/README/CMake/exports 一致性

对每个模块比较 `module.yaml`、README、CMake target、DLL query descriptor、exports、source_symbols、tests；ID/版本/owner/phase/thread/resource/data ports 三方不一致即 FAIL。  
验收：缺 README 的任何生产模块被捕获；只检查五个模块不算通过；validator 不崩溃。  
commit：`test(doccheck): QA-002 全量模块一致性检查`。

## QA-003（SA-QA-29，commit）SCI→ALG→DATA/API→SRC→TEST 矩阵

实现全量追溯检查：ID 唯一、路径存在、symbol 可定位、test 注册、evidence 当前 commit、Gate 引用；输出断链列表和 exit code。  
验收：删除任一链接会 FAIL；不依赖旧 `artifacts/prerelease_v5`；异常捕获后输出结构化失败，不 traceback 充当 PASS。  
commit：`test(traceability): QA-003 全链追溯检查`。

## QA-004（SA-QA-29，commit）调用语义和私池扫描

实现全仓 AST/文本 + 调用图检查：重复完整 session fanout、`workers_=2`/`work_units=1` heavy、`ThreadLease::make` 生产、私有 `std::thread/async/pool`、伪 provider、跨 Phase edge、ACR release link。每命中列文件/符号/调用者/分类。  
验收：当前已知问题可被 synthetic regression 捕获；TEST_ONLY/SHORT_IO 允许但必须有注释和 manifest；误报不能静默忽略。  
commit：`test(architecture): QA-004 固化执行语义扫描`。

## QA-005（SA-QA-29，commit）活动文档/版本/路径扫描

仅扫描 active index：产品版本必须来自 VERSION；历史版本只在 archive/history；扫描旧 commit/F盘/旧入口/旧线程数/旧平台角色/ACR implemented/Phase3 prototype-vs-production。标准 FITS/HiPS/ABI 版本不误报。  
验收：每命中带分类 `VALID_CURRENT/ARCHIVED_VALID/STALE_ACTIVE/AMBIGUOUS`；active stale >0 FAIL。  
commit：`test(doccheck): QA-005 阻止活动文档漂移`。

## QA-006（SA-QA-29，commit）运行图自动生成

用 CMake graph/File API + pipeline JSON + runtime trace 生成 architecture/phase/runtime DOT/SVG/JSON；图为生成物，加入 evidence，不手改。  
验收：target/DLL/entry/artifact/worker/provider/call count 与真实 manifest/trace 一致；图缺节点/重复 session 失败。  
commit：`docs(graph): QA-006 自动生成工程运行图`。

## QA-007（SA-QA-29，commit）静态质量与注释审核

配置 `/W4 /WX /permissive-`（自有代码）、clang-tidy 19.1.5/clang-cl 仅辅助、clang-format check、include-what-you-use 可选；扫描裸 owner、异常边界、NaN/Inf、未检查 IO、注释复述/错定义。  
验收：警告清零；每个 public function 注释有用途/单位/前置/后置/所有权/线程/错误/SCI/ALG/API/TEST；无无依据算法注释。  
commit：`quality(code): QA-007 统一静态质量和接口注释`。

## QA-008（SA-QA-29，commit）ASan/UBSan/泄漏小样本

Linux Clang ASan/UBSan；Windows MSVC ASan 或 Debug 验证；仅小合成数据，长任务有 timeout；检查 artifact 生命周期、DLL destroy、cancel/exception。  
验收：无已知 sanitizer/泄漏；工具不支持时记录 INCONCLUSIVE，不得 PASS。  
commit：`test(safety): QA-008 增加内存与未定义行为检查`。

## LNX-001（FG-000/SA-QA-29，无源码 commit）Linux 主机指纹

保存 OS/kernel/arch/2c2g quota/compiler/cmake/python/clang/git/disk；所有命令有 timeout；不把 Linux 资源限制误当 Windows 性能。证据 `linux/host_toolchain.json`。

## LNX-002（SA-BLD-02，证据 task）轻量 configure/build

运行 Linux light preset；并行编译默认 `-j1`，只有实际可用资源足够才 `-j2`；保存 configure/build/CTest stdout/stderr 和资源。禁止因为 Linux 没 Ninja 就改变 Windows generator。

## LNX-003（SA-QA-29，证据 task）Linux 结构检查全集

运行 layout/version/manifest/ABI/phase-isolation/no-fanout/no-private-pool/no-hardcoded-worker/traceability/doc/link/package validators；每个 exit code 都入 evidence，脚本崩溃为 FAIL。

## LNX-004（SA-QA-29，证据 task）合成模块验证

在 2c2g 只运行确定性小 fixture 的 module unit/property/oracle/negative；不运行 32R、不生成大型 HiPS；保存 seed/参数/输出 hash/报告。

## LNX-005（SA-LOG-08，证据 task）Linux 资源冒烟

选一个足够但小于内存限制的 heavy kernel；采集 `/proc` CPU/RSS/io/threads/queue；验证 monitor 自动伴随和 1/N worker 结果，不宣称 Windows 发布性能。

## LNX-006（SA-PKG-31，证据 task）Linux 审核包预检

在 Windows 未执行时完成审核包结构、源码闭包、敏感信息、历史/大文件 denylist、manifest/SHA validator 预检；Windows 证据缺失只能标 BLOCKED_EXTERNAL。
