# 所有 Task 的共同执行合同

每个 task spec 与本文件共同构成完整要求。缺字段时不得猜测，应按 `24_FAILURE_ESCALATION.md` 返回 `SPEC_ERROR`。

## A. 开始前

1. 校验 `DISPATCH.json`：task ID、owner ID、spec SHA、base SHA、允许/禁止路径、锁、资源类。
2. `git rev-parse HEAD` 必须等于 base SHA；worktree 必须 detached；不得在主工作树。
3. 读取根 `AGENTS.md`、冻结约束、相关 SCI/ALG/DATA/API/README 和直接依赖 public headers。
4. 保存 `PRECHECK.json`，列出需求理解、非目标、风险、预计修改文件、验收命令。
5. 若科学公式或容差尚未冻结，停止本 task 并返回 `CONTRACT_MISSING`；不自行补公式。

## B. 修改纪律

1. 只改允许路径；不格式化无关文件。
2. 纯架构迁移任务写 `scientific_change=false`；Phase3 投影/重采样/FITS WCS
   新增科学实现必须写 `scientific_change=true`，附 SCI reviewer 签核和独立
   WCS/HEALPix oracle。若其他任务发现必须改算法，保持补丁不含该改动并提交 finding。
3. 新公共符号同时更新 API/manifest/test；删除符号必须机器证明无引用。
4. 不创建私有线程池、不读取核心数做私有决策、不硬编码 worker。
5. 不绕过 ArtifactStore 猜路径；不绕过 host logger/metrics/cancel/executor。
6. 不新增 `TODO` 代替本 task；真实未完成则 task FAIL。
7. 不提交二进制、生成目录、原始数据、缓存、绝对机器路径和敏感信息。

## C. 测试与证据

每条命令记录 argv/cwd/host/source SHA/start/end/timeout/exit/stdout/stderr/hash。测试必须在同一 worktree 当前补丁上执行。执行失败不得删日志。

开发 task 最低验证：

- 格式/语法；
- 相关 target build 或 syntax-only；
- 相关 unit/property/oracle/negative；
- manifest/contract/source symbol；
- 无新旧版本字符串/硬编码 worker/私池/C++ ABI；
- 修改涉及 heavy kernel 时 1/N worker 与资源冒烟；
- 修改涉及 SIMD 时 baseline 等价；
- 修改涉及 I/O 时失败/取消/原子发布。

## D. 返回

`TASK_RESULT.json` 必须列 task/spec/owner/base SHA、status、scientific change、changed files/symbols/contracts/tests/commands/limits、patch SHA、changed-files digest 和 scope_clean。SubAgent 不得填写主线提交；返回 patch 必须可由 `git apply --check` 应用。

SubAgent 的 PASS 只是申请验收。前台必须在 main 上重新运行 acceptance；独立 auditor 可以推翻开发自报。

## E. Task 完成条件

仅当：返回完整 → scope clean → 主线验收通过 → 独立抽检无阻断 → 前台原子 commit → push → fetch 后三 SHA 相同，task 才能 CLOSED。

“代码写完”“本地能编译”“文档已更新”“看起来正常”均不是完成状态。
