# Windows Fatduck 构建、批量验证和发布证据任务

`SA-WIN-30` 不改源码、不 commit；只能在 `$ASTROCS_WORK_ROOT/reports/windows` 和 `$ASTROCS_WORK_ROOT/install/windows` 写证据/产物。每项记录来源 commit；发现源码缺陷返回对应 owner。

## WIN-001 远程可用性与身份

通过既定 SSH/远程方式探测 Fatduck 在线、OS edition/version/build、x64、磁盘/RAM/CPU、工作目录；不把凭据写入日志。离线只记 `WAITING_RESOURCE`，继续 Linux。

## WIN-002 工具链安装/锁定

严格按 `09_WINDOWS_TOOLCHAIN_LOCK.md` 验证 VS Build Tools 17.14.39/build 17.14.37614.0、VCTools 14.44.35207、SDK 10.0.26100.0、CMake 3.31.12、clang-tidy 19.1.5、Python 3.12.10。若已有版本不匹配，不在旧环境勉强编译；使用隔离固定实例或返回 WAITING。保存完整 `toolchain_manifest.json`。

## WIN-003 clean Release/RelWithDebInfo 构建

在短路径新建 build tree；固定 `Visual Studio 17 2022 -A x64 -T v143,host=x64,version=14.44.35207`；`/std:c++17 /W4 /WX /permissive- /utf-8 /fp:precise`；Debug `/MDd`，其他 `/MD`；禁 `/fp:fast /GL /LTCG /PGO`。保存 configure/build/install logs、CMake cache 摘要、target graph。

## WIN-004 DLL/ABI/装载负测

验证 PE x64、exports/imports/dependents、manifest hash、C ABI query、无 STL/exception、无 Debug CRT；删除 DLL、错误 ABI/hash/arch、当前目录同名 DLL、PATH 污染均清晰失败；没有静态算法副本。

## WIN-005 全模块合成 CTest

按 label 运行所有 module unit/properties/oracle/negative/performance 适当规模；测试当前 commit；oracle 不使用生产函数期望。失败保存完整原始日志，不删旧失败。

## WIN-006 CPU benchmark/provider

先 baseline selftest，再能力检测，再 AVX2/AVX512 selftest，最后 benchmark。运行 `astrocs benchmark cpu --suite release --output <profile>`；逐 kernel 选择；profile 失效/未运行时重新证明 baseline。保存 CPU 指纹、provider DLL hashes、warmup/rounds/median/MAD、数值对照、资源曲线。

## WIN-007 heavy 资源门禁

对 Phase2 integration/Phase3 resample 等足够工作量合成 fixture 伴随 monitor；至少 1 worker 与 N worker；active/granted/queue/provider/CPU/RSS/I/O 同源。U 平均≥0.80、70%样本≥0.75、队列有工作时不得连续10秒<0.50；2 worker/1 worker 加速≥1.60（工作量足够）。低利用率必须 FAIL 并分类。

## WIN-008 阶段独立 CLI

分别在全新进程执行 `phase1 validate/plan/run/inspect`、`phase2 ...`、`phase3 ...`；检查 run ID/manifest/内存状态不跨进程；Phase3 用外部 HiPS fixture，不启 Phase1/2；grep/trace 证明无 `--phases`。

## WIN-009 Phase1 小真实帧

从 Fatduck 冻结 manifest 取少量真实 R 帧和 masters；先 hash 再运行当前 candidate 一次；记录 calibration/noise/drizzle/hips manifest、异常和预览。真实数据只作辅助，不替代 synthetic oracle。

## WIN-010 Phase2 32R 一次候选验收

仅在合成接缝/UPM/拒绝/积分/资源门禁通过后运行 32 R（11+11+10）+3 masters；先核对 35 文件 hashes；三板块所有输入必须出现在 manifest；输出 mosaic HiPS tree root、support/variance/mask、UPM/rejection/integration provenance、seam metrics 和资源原始时间序列。不得跑历史版本对比。

## WIN-011 Phase3 五投影与流式大输出

先五投影小 fixture，再任选真实兼容 HiPS 抽查；投影显式 TAN/SIN/ZEA/CAR/AIT；检查 WCS/header/mask/support/order/interp4；运行虚拟大输出验证 RSS 与尺寸无关；fitsverify/原子 writer。大计算只一次，不反复历史 run。

## WIN-012 Win10 22H2 兼容烟测

在真实 Windows 10 22H2 x64 或已授权 VM 执行 version/doctor/selftest/每 Phase 最小合成/安全 DLL load；dumpbin imports 禁止仅 Win11 API，缺 API 必须 fallback。没有 Win10 现场证据时标 `WAITING_PLATFORM`，不把 Win11 结果冒充 Win10。

## WIN-013 Win11 主平台完整验收

在 Windows 11 x64 干净工作目录、无开发环境 PATH 下执行 install tree CLI/version/modules verify/全合成/benchmark/profile/必要真实数据；校验 VC runtime 依赖和发布目录不含 PDB/obj/cache。

## WIN-014 发布候选物与外部清单

生成 `AstroCS_0.11.0-alpha.1_win-x64` 二进制包、DLL/module/provider manifest、每文件 SHA、依赖/licenses/SBOM；发布包与审核包分离。用户包不含 testdata、build、历史、PDB、原始 benchmark；不签名时明确 unsigned alpha。
