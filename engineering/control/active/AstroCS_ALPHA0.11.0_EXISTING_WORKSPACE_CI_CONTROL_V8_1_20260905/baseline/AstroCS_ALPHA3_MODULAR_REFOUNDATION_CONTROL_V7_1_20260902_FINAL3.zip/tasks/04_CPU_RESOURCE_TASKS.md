# CPU provider、benchmark 与资源门禁任务

## CPU-001（SA-CPU-09，commit）能力探测与安全矩阵

实现 AMD64 CPUID 叶、AVX/AVX2/FMA/AVX512F/CD/BW/DQ/VL、BMI2、OSXSAVE 和 XGETBV 检查；区分“硬件支持”和“OS 可安全执行”。不得调用高级 provider 后才检测。  
验收：模拟 feature matrix；缺 AVX/OS state/子集拒绝；Windows/Linux 输出同一 schema；不读取硬编码核心数。  
commit：`feat(cpu): CPU-001 实现ISA与OS安全探测`。

## CPU-002（SA-CPU-B10，commit）baseline provider

建立不带 `/arch:AVX*` 的 AMD64 baseline DLL；包含所有注册 kernel 的可靠实现或明确 unsupported→baseline；provider query/self_test/export/ABI 完整。  
验收：仅 SSE2 默认；任意 AMD64 安装树可加载；科学 oracle、NaN/Inf、边界、确定性、1/N worker tests；无全局 SIMD 静态初始化。  
commit：`feat(cpu): CPU-002 提供保守基线后端`。

## CPU-003（SA-CPU-A11，commit）AVX2/FMA provider

只迁移 profile 指定的热点 kernel；target 单独 `/arch:AVX2`；函数入口由 provider 表查询，不复制科学模块；其余 kernel 回落 baseline。  
验收：非支持 CPU 不加载；CPUID/XGETBV negative；baseline 对照容差；FMA 是否改变归约顺序记录；性能不是唯一通过条件。  
commit：`feat(cpu): CPU-003 增加AVX2热点后端`。

## CPU-004（SA-CPU-X12，commit）AVX-512 provider

只迁移实测可能获益的 kernel；target 单独 `/arch:AVX512`；明确所需 AVX-512 子集和 XCR0 ZMM；防止 AVX-512 降频使全局性能变差。  
验收：缺任何子集/OS ZMM state 拒绝；非法指令保护测试；baseline/AVX2/AVX512 oracle；每 kernel 可退回。  
commit：`feat(cpu): CPU-004 增加AVX512热点后端`。

## CPU-005（SA-CPU-09，commit）provider 数值自测与路由表

实现 query→self_test→eligible→benchmark→select 顺序；路由以 `kernel_id` 粒度；profile 不合格、build/CPU/OS hash 变化、缺 benchmark 一律 baseline。  
验收：伪造 profile/错误 hash/低收益/NaN mismatch 均退回；运行 trace 显示实际 provider；无全局 `preferred_isa=avx512`。  
commit：`feat(cpu): CPU-005 固化逐内核后端选择`。

## CPU-006（SA-CPU-09，commit）benchmark cpu 命令

实现 `astrocs benchmark cpu --suite quick|release --output profile.json`；记录 CPU 指纹、逻辑/物理核、cache/NUMA/affinity、内存带宽、kernel sizes、warmup、重复轮次、median/MAD、workers、provider、输入 hash、编译器。  
验收：不会改变生产 profile 直到全部 self_test+阈值通过；没有 benchmark 时 baseline；异常值剔除规则预先固定；命令有 timeout。  
commit：`feat(benchmark): CPU-006 提供可审计硬件基准`。

## CPU-007（SA-CPU-09，commit）profile 存储/失效/原子更新

Windows 默认 `%LOCALAPPDATA%/AstroCS/cpu_profile.json`，Linux XDG data；写临时→校验→原子 rename；绑定 schema/product build/CPU/OS/provider hash。  
验收：损坏、旧版本、机器变化、半写文件不被使用；无 profile 运行清晰 warning；profile 不进入源码/审核包原始数据。  
commit：`feat(benchmark): CPU-007 管理硬件配置生命周期`。

## CPU-008（SA-CPU-09，commit）线程建议自适应

根据探测核数、进程/job/NUMA/内存预算和 profile 选择 worker 上限与 block size；不能写死 2/16/32 或无视用户上限。将选择写入 plan，实际 granted 写 trace。  
验收：cgroup/Windows job 限制模拟；低资源 Linux 不超配；2 核合成 heavy 1→2 worker 有可测扩展；worker=1 仅 tiny/I/O 允许。  
commit：`feat(scheduler): CPU-008 自适应线程建议`。

## MON-001（SA-LOG-08，commit）资源阈值判定

按 kernel/workload 将区间标为 cpu-bound、memory-bound、io-bound 或 lock/queue-bound；
数值 CPU-heavy 工作不能切成多个短于 5 秒的片段规避门禁。5 秒仅是建议统计窗口，
一个 run 的同类 heavy span 要按单段和累计 wall 时间汇总。计算以
`process_cpu_core_seconds/(wall_seconds×effective_available_workers)` 和同定义的
system CPU 归一化利用率、active/granted、RSS 峰值、吞吐、队列/等待；不得以硬编码
核心数、配置 worker 数作分母。  
验收：平均 U≥0.80、70%样本≥0.75、队列有工作时不得连续10秒<0.50；异常分类需证据；监控缺失直接 FAIL。  
commit：`test(resource): MON-001 固化重计算资源门禁`。

## MON-002（SA-LOG-08，commit）内存泄露/增长检测

长 run 定期采样 RSS/private/commit/allocator outstanding；区分 cache/高水位/工作集；run 结束验证可解释回落，保存原始曲线。  
验收：注入 leak 失败；重复小 run 无单调增长；cache 上限生效；禁止只看峰值截图。  
commit：`test(resource): MON-002 增加内存增长检测`。

## ACR-001（SA-ACR-13，commit）ACR dormant build guard

保留 ACR 源码、接口和独立测试；默认/Release/Win install/product manifest 不构建、不链接、不加载 ACR/CUDA；添加机器 guard 和文档。  
验收：`grep`/CMake graph/PE imports/registry 均无生产依赖；显式 `ASTROCS_ENABLE_ACR=ON` 只能生成隔离实验 target，不得被 release preset 接收。  
commit：`build(acr): ACR-001 固化首发休眠边界`。
