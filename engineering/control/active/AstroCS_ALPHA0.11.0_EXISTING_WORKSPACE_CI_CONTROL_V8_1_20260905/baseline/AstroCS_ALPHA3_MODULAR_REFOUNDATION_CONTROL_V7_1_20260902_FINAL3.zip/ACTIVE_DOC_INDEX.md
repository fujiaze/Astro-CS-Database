# Active 文档索引

本控制包中的 `00`–`22`、`tasks/`、`checklists/`、`schemas/`、`templates/` 是本轮 active contract；历史审核包、旧版本报告和旧源码只能放项目 `control/archive/` 或 `audit/archive/`，不得作为当前证据。

| 层 | 文件 | 读者 | 机器入口 |
|---|---|---|---|
| L0 | `templates/L0_OWNER_REVIEW.md` | 项目负责人 | `evidence/SUMMARY.json` |
| L1 | `03_TARGET_PRODUCT_AND_ARCHITECTURE.md`、`04_FOREGROUND_AGENT_RUNBOOK.md` | 前台 Agent | `TASK_LEDGER.csv` |
| L2 | `16_SCIENCE_DOCUMENT_AND_TRACEABILITY_STANDARD.md`、`21_PRIMARY_REFERENCES.md`、模块 SCI/ALG | 科学/模块 owner | `validate_traceability.py` |
| L2 | `science/PHASE3_PROJECTION_ALGORITHM_CONTRACT.md`、`science/PHASE2_SEAM_AND_INTEGRATION_CONTRACT.md`、`science/CPU_PROVIDER_QUALIFICATION_CONTRACT.md` | 对应算法 owner/独立审计 | `validate_traceability.py` |
| L3 | `schemas/`、`19_MACHINE_CHECKS.md`、模块 README/module.yaml | SubAgent/CI | `run_control_checks.py` |
