# SCI/ALG-P2：Phase2 接缝、UPM 与积分合同

## 1. 固定范围

Phase2 接收已发布的 Phase1 或外部 HiPS 产品，独立执行 coverage、sampling、UPM fit、UPM apply、rejection、integration、HiPS publish。它不调用 Phase1/Phase3，不隐式重跑任何阶段。

## 2. 数据语义

SCI 是信号；variance 是信号方差；ivar 仅在 variance 为正且有限时定义为其倒数；weight 必须有独立定义；support/coverage 是几何覆盖；rejection mask 是排异原因。单位、dtype、shape、坐标、NaN/zero/invalid 规则必须出现在当前数据合同。

## 3. UPM 合同状态

本轮不把历史包或未核实的 UPM 公式宣称为冻结科学事实。实现前必须从仓库当前 active SCI 文档确定：观测量 y 的定义、控制点选择、基函数 B、参数 gauge/零点约束、正则项、权重/ivar 作用位置、退化处理、variance 传播及 apply 的符号约定，并为每一项分配 SCI/ALG ID。缺一项时任务只能返回 CONTRACT_MISSING，不得自行补公式。

验证系统必须包含：

1. 常数场、线性场和已知 additive offset 的解析 oracle；
2. 控制点缺失、共线、重复、全 invalid 和极端动态范围；
3. fit/apply/persist/reload 的 schema、hash、参数确定性；
4. 不改变 signal 单位、variance 非负性和 support/mask 分离；
5. UPM 参数仅在 fit 节点产生，apply 不得隐式重拟合。

## 4. 排异与积分

排异策略由配置和 ALG ID 选择，必须保留 frame identity。独立 oracle 覆盖 sigma、winsor、linear-fit、ESD、小样本、NaN、全拒绝。积分 oracle 独立实现加权信号、variance 传播、零权和归约顺序；不可用生产函数生成 golden expected。

## 5. 接缝实验

固定 fixture 包含恒定场、方向余弦线性场、梯度、点源、已知 additive offset、跨 tile/order 边界、缺 tile、异常帧和全拒绝。报告边界 residual、斜率差、flux discontinuity、coverage histogram、mask/support/variance 变化；P2-REJ-ACCEPT、P2-INT-ACCEPT、P2-ASSEMBLY-ACCEPT 分别判定排异、积分和装配，不合并责任。

## 6. 资源

sampling、UPM、排异、integration 均按 CPU-heavy 候选处理，必须经过共享 executor/lease 和伴随监控。报告 effective_available_workers、granted、active、process/system CPU、grant_coverage、active_coverage 和 system_normalized_utilization。低利用率必须 FAIL 或用可复现的 memory/IO/lock 分类证据解释。
