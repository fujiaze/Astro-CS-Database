# SCI/ALG-P3：球面 HiPS 到平面 FITS 合同（Alpha 0.11.0）

## 1. 科学对象与坐标链

输入是带 frame、epoch、order、NESTED、tile_width 的球面采样；输出为二维像素中心上的 SCI、SUPPORT、MASK 和标准 FITS WCS。Phase3 只做坐标映射、采样和写出，不做校准、测光、UPM、排异或积分。

FITS celestial frame 的经纬度不能直接代入投影原生公式。WCS Paper II 的
`CRVAL/LONPOLE/LATPOLE` 决定 celestial 与 native spherical coordinates 之间的
Euler 旋转；它不是把 `CRVAL` 直接塞进某个简化投影公式。所有旋转参数、frame、
epoch、wrap 和极点处理必须记录在 plan、trace 和 output header/provenance 中。

双向坐标链必须严格区分如下两条方向，不能交换步骤：

* `pixel → sky`（输出像素到天空）：对 FITS 像素中心 `(u+1,v+1)` 先做
  `p = CD · ([u+1,v+1] − CRPIX)` 得到 intermediate projection-plane 坐标；
  再使用选定投影的**逆原生公式**得到 `(λ_native, φ_native)`；最后应用由
  `CRVAL/LONPOLE/LATPOLE` 及 celestial frame 定义的**逆 Euler 旋转**，得到输出
  celestial `(λ_cel, φ_cel)`。
* `sky → pixel`（输入球面样本到输出像素）：先将输入 celestial 坐标用同一 WCS
  参数执行 **Euler 正向旋转**得到 `(λ_native, φ_native)`；仅此 native 坐标可进入
  TAN/SIN/ZEA/CAR/AIT 的正向原生公式得到 `(ξ,η)`；再做 `CD⁻¹` 和 `CRPIX`，得到
  FITS 像素坐标。数组索引转换为 `(u,v)=(x_fits−1,y_fits−1)` 只在边界处进行。

生产实现和独立 oracle 都必须明确记录使用的是哪一个方向。不得用生产函数的
正向结果反推自己的逆向 golden 值。

坐标 frame 至少支持并显式标注 `ICRS`、`FK5`、`GALACTIC`；内部角度统一为
弧度，FITS `CUNIT` 为度时只在 I/O 边界转换。`RADESYS/EQUINOX`（以及 Galactic
时的 frame 标识）必须与 frame 一致；缺失或矛盾元数据直接 `CONTRACT_MISSING`，
不得静默假定 ICRS。

## 2. 投影原生公式与定义域

内部角度为弧度，Δλ = wrap(λ_native − λ0_native) ∈ [-π,π)。q = sinφ0 sinφ + cosφ0 cosφ cosΔλ。

- TAN/gnomonic：D=q；ξ=cosφ sinΔλ/D；η=(cosφ0 sinφ−sinφ0 cosφ cosΔλ)/D；D≤0 或非有限为域外。
- SIN/orthographic：ξ=cosφ sinΔλ；η=cosφ0 sinφ−sinφ0 cosφ cosΔλ；q<0 为不可见半球域外。
- ZEA/Lambert azimuthal equal-area：k=sqrt(2/(1+q))；ξ=k cosφ sinΔλ；η=k(cosφ0 sinφ−sinφ0 cosφ cosΔλ)；1+q≤0 为域外。
- CAR/plate carrée：ξ=Δλ；η=φ−φ0；仅在 native longitude/latitude 上使用，不能把任意 celestial CRVAL 直接代入简化公式。
- AIT/Hammer–Aitoff：z=sqrt(1+cosφ cos(Δλ/2))；ξ=2sqrt(2) cosφ sin(Δλ/2)/z；η=sqrt(2) sinφ/z；z=0 为域外；原生中心和尺度由 WCS 旋转及 CD 决定，不能用任意 CRVAL 替代 native reference。

投影枚举是显式配置，不能用域外自动换投影。逆变换必须由隔离实现或 WCSLIB oracle 验证，生产代码不得调用自身生成 golden expected。

## 3. WCS、像素中心和 wrap

数组索引为 0-based (u,v)，FITS 像素中心为 1-based (u+1,v+1)。`pixel → sky`
必须先由 CD 得到投影平面坐标，再执行投影逆公式，最后执行 native→celestial
的逆 Euler 旋转；`sky → pixel` 则按上一节的相反顺序执行。Alpha 固定使用 CD
表达，并写 CTYPE1/2、CUNIT1/2、CRVAL1/2、CRPIX1/2、RADESYS、frame/epoch；不得
同时写互相矛盾的 CROTA。

经度在计算前后都按明确 wrap 规则处理；极点和投影奇点必须分类，不得夹到边界后继续采样。域外写 SCI=NaN、SUPPORT=0 并置 MASK bit。角度 residual 用弧度，round-trip 用 pixel。

### 3.1 MASK、SUPPORT 和 variance 固定语义

输出 MASK 为无符号位掩码，位定义冻结为：`bit0=DOMAIN_OUTSIDE`、
`bit1=MISSING_TILE`、`bit2=INVALID_SAMPLE`、`bit3=NAN_SAMPLE`、
`bit4=INTERPOLATION_INCOMPLETE`、`bit5=INPUT_MASKED`。多个原因按位 OR，禁止
用一个新状态覆盖已有原因。域外必须 `SUPPORT=0`；缺邻点或无效邻点必须
`SUPPORT<1` 且置相应位，不能删除坏邻点后重新归一化权重伪造完整支持。有效
nearest 的 SUPPORT 为 1；所有定义外的 SCI 为 NaN。无相关输入假设时
`Var_out=Σ wi² Var_i`，mask/NaN 的样本不进入该和；相关性未知时必须标记
`variance_status=UNAVAILABLE`，不得假定独立并输出伪精度方差。

## 4. HiPS 采样与缺失

nearest 在实际选择的 source_order 上执行 ang2pix_nest，读取唯一 cell；不得偷偷改读更深或父 order。healpix_interp4 取目标点所在上下 iso-latitude ring 的左右邻点，周期经度正确处理，四权重非负且和为 1。任一邻点缺 tile、NaN 或 invalid 时，严格输出 SCI=NaN、partial SUPPORT 和 MASK bit4，禁止剔除坏点后重新归一化。

source_order 为显式配置；auto 按源 cell 角尺度与目标 pixel scale 选择，并把实际 order 和 tie 规则写入 provenance。若输入方差互不相关，Var_out=Σ wi² Var_i；不得虚构不存在的空间协方差。

## 5. 独立验收与依据

固定 golden 点包含中心、四角、四边中点、wrap 两侧、极区、奇点/域外及 100 个固定 seed 点。独立 oracle 必须使用 WCS Paper I/II 定义或隔离 WCSLIB；不得由生产投影函数反向产生期望值。建议内部角误差≤1e-10 rad、边界分类一致且角误差≤1e-8 rad、round-trip≤1e-7 pixel，最终阈值由对应 ALG ID 冻结。

本合同依据 Greisen & Calabretta 2002（WCS Paper I）、Calabretta & Greisen 2002（WCS Paper II）、FITS Standard 4.0、Górski et al. 2005（HEALPix）和 IVOA HiPS Recommendation；正式链接见 21_PRIMARY_REFERENCES.md。
