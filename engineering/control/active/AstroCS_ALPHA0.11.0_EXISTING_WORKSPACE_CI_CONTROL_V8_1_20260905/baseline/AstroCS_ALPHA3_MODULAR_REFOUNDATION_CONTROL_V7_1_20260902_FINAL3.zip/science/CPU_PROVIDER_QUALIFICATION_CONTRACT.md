# SCI/ALG/ARCH-CPU：CPU provider 资格合同

科学模块只依赖稳定 kernel interface；baseline、AVX2/FMA、AVX-512 是实现 provider，不得复制 Phase 算法或在业务代码中散布 `#ifdef AVX`。

资格顺序固定为：CPUID + OSXSAVE/XGETBV 安全检查 → DLL ABI/hash → provider self-test → 合成数值 oracle → benchmark → profile select。AVX-512 必须按实际 kernel 检查所需 F/CD/BW/DQ/VL 子集及 ZMM 状态；硬件支持不等于 OS 可执行。未运行 benchmark、profile 损坏/过期、CPU/OS/build/provider hash 不匹配或收益低于噪声门限时走 baseline。

benchmark 记录 kernel、输入 size/hash、provider、workers、warmup、重复轮次、median/MAD/p95、CPU/wall、带宽、结果 hash/ULP/abs/rel diff；不能以一次最快值选择，也不能以性能替代数值正确性。线程上限由有效资源/profile/config 计算，不写死核心数；没有 profile 使用最保守 baseline。

provider target 分别隔离编译：baseline 不带 `/arch`，AVX2 仅 `/arch:AVX2`，AVX-512 仅 `/arch:AVX512`；生产 `/fp:precise`，oracle `/fp:strict`；禁止全局 `/fp:fast`、`/GL`、LTCG、PGO。所有选择和实际 provider 必须进入 plan/trace/provenance。

