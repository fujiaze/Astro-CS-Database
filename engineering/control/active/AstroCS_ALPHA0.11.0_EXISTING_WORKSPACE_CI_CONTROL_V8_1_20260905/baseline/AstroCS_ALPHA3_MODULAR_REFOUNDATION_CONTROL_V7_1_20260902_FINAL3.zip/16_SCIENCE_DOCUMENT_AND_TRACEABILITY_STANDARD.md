# 科学定义、算法文档与代码追溯标准

## 1. 权威顺序

```text
SCI 科学定义
  ↓ 推导
ALG 离散算法/近似/误差/复杂度
  ↓ 软件承载
DATA + API + ARCH + MOD
  ↓ 实现
source symbols + module.yaml
  ↓ 验证
TEST + evidence
  ↓ 汇总
Owner L0
```

SCI/ALG 的数学意义不能由代码或关键词检查自动推导；API 签名必须以 AST/DLL query 为事实；Pipeline 拓扑必须以机器可读 DSL/trace 为事实；L0 只汇总，不维护第二套公式。

## 2. 标识

- `SCI-P1-*`：科学对象、物理意义、公式、单位、假设、有效域；
- `ALG-P1-*`：离散步骤、数值精度、边界、误差、复杂度、确定性/并行归约；
- `DATA-*`：schema、单位、坐标、dtype/shape、mask/invalid/provenance；
- `API-*`：真实 public C ABI、调用时序、所有权、错误、线程/取消；
- `ARCH-*`：组件/依赖/部署/运行图；
- `MOD-*`：模块 manifest、DLL、操作、owner；
- `TEST-*`：test ID、fixture/oracle/属性/容差；
- `EVID-*`：当前提交现场命令/日志/hash；
- `GATE-*`：机器计算门禁。

## 3. 每个科学量必写

名称、符号、定义、物理意义、单位、坐标系/frame/epoch、dtype/精度、有效域、NaN/Inf、边界、随机性、并行归约、误差阈值、mask/coverage/weight/variance/ivar 区分。禁止单独出现没有语义的 `value/scale/weight/snr/sigma/index`。

## 4. 函数注释模板

每个 public function 或复杂 kernel：作用；输入/输出和单位；前置/后置；无效/错误；内存所有权；线程安全/并行轴/lease；取消/checkpoint；数值误差/确定性；SCI/ALG/API/DATA/TEST ID。注释解释为什么和约束，不能逐句复述代码，也不能写不存在的共享 cache/异步预取/面积守恒。

## 5. 机器闭环

`validate_traceability.py` 必须全量检查 ID 唯一、引用文件、source symbol、test registry、evidence current SHA、module README/YAML/CMake/DLL query、Gate。缺链为 `BROKEN_TRACE`；脚本不允许崩溃、旧绝对路径或只检查五个模块。输出 CSV/JSON 为真相，Markdown 为视图。

## 6. 文档状态

Active 文档只能有一个当前产品版本；module/ABI/data schema/doc revision 分开；历史轮次只在 `docs/archive`/`engineering/control/archive`。任何 active 旧版本号、旧 commit、旧入口、旧平台、旧线程数、旧 phase 连续语义都必须清除或标 `AMBIGUOUS`/FAIL。标准 `FITS 4.0`、`HiPS 1.0`、`ABI v1` 不视作产品版本。

## 7. 人工抽查

机器闭环通过后，项目负责人/独立 reviewer 抽查至少：校准公式、Noise/SNR/variance/ivar、Drizzle守恒、Phase2接缝/UPM/rejection/integration、Phase3五投影/WCS/采样、ThreadBudget、DLL ABI 和顶层文档。抽查要返回具体源文件/符号/公式/测试/证据，不接受“整体一致”。
