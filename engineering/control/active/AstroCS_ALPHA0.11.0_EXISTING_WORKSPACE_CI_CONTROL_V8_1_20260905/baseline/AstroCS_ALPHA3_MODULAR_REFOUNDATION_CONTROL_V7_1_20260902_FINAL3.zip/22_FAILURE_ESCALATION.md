# 失败分类、重试与升级

## 分类

| 类别 | 例子 | 处理 |
|---|---|---|
| `CODE_FAIL` | 编译/测试/科学 oracle 失败 | owner 修复；保留原始证据；新 commit 后重跑受影响任务 |
| `DOC_FAIL` | 版本、公式、接口、注释、路径陈旧 | DOC owner 修复并更新 traceability；不能只改报告 |
| `TOOLING_FAILURE` | validator crash、依赖缺失、脚本异常 | P0；SA-GOV-01 修工具；禁止人工“视为通过” |
| `RESOURCE_FAIL` | OOM、低利用率、队列/锁、磁盘满 | 先归因；缩 fixture 不放宽门限；Windows heavy 重新计划 |
| `PLATFORM_FAIL` | MSVC/SDK/Win10/DLL load 不符 | 标 `WAITING_PLATFORM` 或修复；不能拿 Linux 代替 |
| `EXTERNAL_BLOCKER` | Fatduck 离线、授权数据未到 | 继续无关任务，保存命令/input hash；最终可 `BLOCKED_EXTERNAL` |
| `PACKAGE_FAIL` | 白名单、hash、容量、泄露历史/大文件 | 重新打包；旧包归档；不修改源码解决 |
| `SCIENCE_DISPUTE` | 文档推导与实现/参考不一致 | P0/P1；暂停该算法接入，提交 owner review 所需说明 |

## 重试规则

1. 只允许重试一次相同命令；重试前记录原因和是否改变环境。
2. 修改代码/文档/配置、工具链或输入后必须生成新 evidence ID；旧证据自动 `SUPERSEDED`。
3. flaky 测试必须先隔离随机种子、线程、IO 和环境；不能重复跑直到碰巧 PASS。
4. OOM 时只减少合成 fixture 的尺寸/并发，不改变算法维度、容差或测试类型；真实 heavy 改到 Fatduck。
5. Windows 离线不构造虚假日志；任务状态为 `WAITING_RESOURCE`，同时完成 Linux 可做部分。

## 升级格式

```text
BLOCKER_ID:
CATEGORY:
TASK_ID / OWNER:
MAIN_SHA:
FIRST_FAILURE_UTC:
COMMAND / EXIT_CODE:
EVIDENCE_PATHS + SHA256:
MINIMAL_REPRODUCTION:
IMPACT_ON_GATE:
RETRY_ALREADY_DONE:
REQUIRED_DECISION_OR_INPUT:
NEXT_AUTOMATIC_ACTION:
```

只有以下情况可以发给项目负责人：科学定义冲突、正式平台/数据不可用、需要改变冻结合同、需要 P2/P3 waiver。普通编译错误、文档缺项、脚本 bug、低利用率必须由绑定 SubAgent 继续处理，不能把工作推回负责人。

