# main-only 原子 Git 规范

## 1. 分支

正式历史只有 `main`。SubAgent 使用 detached worktree，不能创建 feature/review/release 分支，不能直接 commit/push。前台在主工作树逐 task 串行应用和提交。

## 2. 一个 task 一个目的

允许一个 task 产生一个 commit；如因可构建性确需多个 commit，必须拆成新的 task ID。严禁将科学公式、架构、性能、文档清理、格式化混入一 commit。提交标题：

```text
type(scope): TASK-ID 中文目的
```

body 必须列 requirement IDs、修改路径、科学变更 `NO/YES`、测试、资源影响和限制。

## 3. 集成前检查

前台必须确认：patch/spec/base SHA；允许 globs；无二进制/数据/缓存/凭据；CHANGED_FILES 与实际 diff 双向一致；`git apply --check`；当前 main 未被外部推进。base 落后则退回原 owner 重放，不在前台手工合并。

## 4. 提交和 push

```bash
git status --porcelain=v2 --untracked-files=all
git diff --check
git diff --stat
git add -- <task-allowed-paths>
git commit -m "type(scope): TASK-ID 中文目的"
git push origin main
git fetch origin --prune
git rev-parse HEAD
git rev-parse main
git rev-parse origin/main
```

三 SHA 必须一致。记录 `COMMIT_LEDGER.jsonl`：commit/parent/task/subject/author/changed paths/push remote verified/atomicity/evidence SHA。任何 push 失败不得伪造 PUSHED；继续本地无依赖任务并在日志中记录。

## 5. 禁止动作

禁止 force push、reset --hard、clean -fd、删除用户 dirty 文件、merge commit、rebase 已推送 main、跳过 hooks、改写独立报告/控制包原件。若需要删除旧路径，先核对 realpath、Git 状态、无调用者和 task scope，再由明确删除 task 执行。

## 6. 版本和源码包

最终审核包只能来自最后一次 push 后的 clean main。源码快照不含 `.git`，但 `GIT_TREE_MANIFEST`/`COMMIT_LEDGER` 记录完整可追溯信息；任何 Windows 二进制证据必须对应同一 final SHA。
