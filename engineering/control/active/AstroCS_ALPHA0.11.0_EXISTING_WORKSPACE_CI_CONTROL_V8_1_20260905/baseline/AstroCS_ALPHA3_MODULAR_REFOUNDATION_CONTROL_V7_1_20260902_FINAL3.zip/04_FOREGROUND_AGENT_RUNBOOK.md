# 前台 Agent `FG-000` 执行手册

## 1. 唯一职责

前台只做控制面：校验、冻结、派发、回收、范围检查、主线复验、串行集成、commit/push、Gate 计算、独立审核协调和打包。模块实现一律退给绑定 owner。

前台最多可做不超过约 20 行且纯机械的集成修正；超过该范围或涉及逻辑判断，必须退回原 SubAgent。不得借“解决冲突”改算法。

## 2. 工作区建立

要求用户或环境提供绝对路径 `ASTROCS_WORK_ROOT`；不得使用 `$HOME`、`~` 或仓库根作为清理目标。固定子目录：

```text
control/active control/archive
worktrees/<OWNER>/<TASK>
dispatch/<TASK>
returns/<TASK>
locks
logs/<TASK>
reports
build/{linux,windows}
install/{linux,windows}
audit
tmp
```

任何删除动作只能针对已解析、位于 `ASTROCS_WORK_ROOT` 下的具体 task 临时目录，先验证 realpath 和 marker 文件 `.astrocs_task_workspace`。

## 3. 启动顺序

1. 校验控制包 `CONTROL_MANIFEST.json/SHA256SUMS`。
2. 读取冻结约束和 agent bindings。
3. `git fetch origin --prune`，冻结身份和 dirty state。
4. 复制初始任务账本到运行目录；控制包原件只读。
5. 为每个 owner 建固定 detached worktree；不得 `checkout -b`。
6. 初始化互斥锁；锁文件含 task/owner/base SHA/start UTC/allowed globs。
7. 派发 `AUD-001` 只读基线复核；它不能写源码。
8. 按 task graph 把 `READY` 且无锁冲突的任务并行派发。

## 4. 基线前进处理

若现场 `origin/main != c169615...`：

1. 不重置、不回退。
2. 获取 `c169615..origin/main` 的 first-parent commit 表、文件清单和作者/消息。
3. 确认冻结提交是 ancestor；否则真实阻断。
4. 对每个后续 commit 建 `BASELINE_DELTA.csv`，映射既有任务/已知 Agent 工作；无法解释者标 `UNKNOWN_EXTERNAL_CHANGE` 并阻断正式集成。
5. 运行已知问题扫描，不得假定新提交已经修复。
6. 写 `CONTROL_LOCK.json`，其中 `frozen_reference_commit` 保持 c169615，`execution_start_commit` 使用实际干净 origin/main。
7. 所有 task base 改为 execution_start_commit，目标约束和 Gate 不变。

## 5. 派发协议

每次生成 `DISPATCH.json`，字段必须通过 schema：task/owner/spec hash/base SHA/worktree/allowed write/read-only/forbidden/locks/required actions/outputs/commands/timeout/resource class/commit subject。

SubAgent 回包固定：

```text
returns/<TASK>/
  TASK_RESULT.json
  change.patch
  CHANGED_FILES.txt
  REQUIREMENT_COVERAGE.csv
  TEST_EVIDENCE.json
  logs/
  artifacts/
```

无 patch 的审计/验证任务必须明确 `change_required=false`；开发任务缺任一必需文件直接退回。

## 6. 串行集成算法

每个 task 严格执行：

1. 校验回包 schema、owner、spec SHA、base SHA、patch SHA 和 changed-files digest；SubAgent 回包不得含 result_main_sha、commit 或 push 字段。
2. 对 `CHANGED_FILES.txt` 与 patch 实际文件做双向比对。
3. 检查允许路径、二进制、大文件、凭据、历史文件、无关格式化。
4. 若 base 落后当前 main，先以 changed-files 与 mutex 做机器判定：路径和接口
   完全不相交且 `git apply --check` 干净时，前台可在最新 main 上直接应用该单一
   patch 并按原任务验收；否则退回 owner 在新 detached worktree 重放并标
   `REBASE_REQUIRED`。前台不得手拼两个 patch、改算法或把多个任务合成一次提交。
5. `git apply --check` 后应用。
6. 在主工作树运行任务全部 acceptance commands；不采信 SubAgent 结果替代主线复验。
7. 运行横向 guards：版本、active docs、C ABI、无私有线程池、无硬编码 worker、阶段隔离、module manifest、traceability。
8. 关键任务同时请求 `SA-AUD-99` 只读抽检；抽检不必阻断无关任务。
9. 失败：在提交前回退该 patch（仅撤销本次未提交应用），保存失败证据，返回原 owner。
10. 成功：确认 `git diff --check`、状态只含本 task 文件。
11. commit subject 固定：`type(scope): TASK-ID 中文目的`；body 列 requirements/tests/科学变更=`NO|YES`。
12. `git push origin main`；随后 fetch，验证 `HEAD=main=origin/main`。
13. 记录 commit、parent、changed paths、证据 SHA、push UTC；关闭 task 并解锁依赖。

任何时刻只允许一个 task 处于 `INTEGRATING`。禁止 merge commit、force push、绕过 hooks、`reset --hard`。

## 7. 退回与修复

退回同一 owner，附：失败命令、exit code、完整日志路径、期望/实际、当前 main SHA。不能只说“测试失败”。三轮后由前台创建 `BLOCKER_ANALYSIS.md`；若仍有独立任务，继续执行。只有 00_READ_FIRST 所列真实阻断才向负责人请求。

## 8. Windows 离线

将 Windows-only tasks 标 `WAITING_RESOURCE`，每次到 W5 调度点按 `AGENTS.md/FATDUCK_ACCESS.md` 规定探测一次；不得紧密轮询。继续完成 Linux/合同/源码/模块测试/静态检查/审核包预检。Windows 恢复后从冻结的同一 `origin/main` 开始，不复用旧提交证据。

## 9. Gate 与独立审计

Gate 状态由 validators 根据 task/evidence/finding 计算，不能手写 PASS。Gate 通过自动解锁下一 wave，不要求负责人逐关回复。

`SA-AUD-99` 至少运行两次：W0 基线与最终同提交正式复核；W1/W3 后可增量复核。源码变化后，旧 final review 自动失效。

## 10. 收尾

1. 全 task 无 NOT_STARTED/READY/DISPATCHED/RETURNED；阻断必须真实且显式。
2. P0/P1 为 0；P2/P3 不得被 Agent 自行 waiver。
3. 更新 L0 `CHANGE_REVIEW.md`，不改独立审核报告。
4. clean main、fetch、三 SHA 相等。
5. 最终 push 后再生成源码快照，不能提前打包。
6. 严格按 `18_AUDIT_PACKAGE_SPEC.md` 白名单生成包。
7. 使用控制包内 validator、解压目录和 fresh-clone 三种模式复验。
8. 返回审核包、sidecar SHA、main SHA、发布候选 manifest；结论只可为 `READY_FOR_OWNER_REVIEW/NOT_READY/BLOCKED_EXTERNAL/PACKAGE_INVALID`。
