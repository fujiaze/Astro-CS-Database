# 固定 SubAgent 派发计划

前台只按此映射派发；`05_FIXED_SUBAGENT_BINDINGS.yaml` 是路径权限事实源，`TASK_LEDGER.csv` 是任务/依赖事实源。任何任务只能由下表 owner 执行，不能临时换人或让一个 Agent 跨域改写。

| owner | 固定职责 | 主要波次 | 典型 task |
|---|---|---|---|
| SA-GOV-01 | 约束、版本、active/archive、L0 | W0/W1/W7 | GOV-001..005 |
| SA-AUD-99 | 只读独立审计 | 全波次 | AUD-001..005、ABI-006 |
| SA-BLD-02 | CMake/MSVC/依赖/安装树 | W1/W2/W5 | BLD-001..004、LNX-002 |
| SA-ABI-03 | C ABI、loader、registry、noop | W1/W2 | ABI-001..005、ARC-001 |
| SA-CLI-04 | 单 CLI、进程隔离、JSON 协议 | W2 | CLI-001..004 |
| SA-RT-05 | DAG、Runtime、executor、ThreadBudget、trace | W1/W2/W3 | RT-001..007 |
| SA-DATA-06 | typed Artifact、产品、provenance | W1/W2 | DATA-001..004 |
| SA-IO-07 | FITS/HiPS/原子流式 I/O | W2 | IO-001..003 |
| SA-LOG-08 | 日志、监控、运行图、资源门 | W1/W2/W5 | LOG-001..003、MON-001/002 |
| SA-CPU-09 | 探测、路由、benchmark、profile、线程建议 | W2/W3 | CPU-001、005..008 |
| SA-CPU-B10/A11/X12 | baseline/AVX2/AVX-512 provider | W2/W3 | CPU-002..004 |
| SA-ACR-13 | ACR dormant/off 守卫 | W1 | ACR-001 |
| SA-P1-C14/S15/W16/N17/D18 | Phase1 具体模块 | W3/W4 | CAT/P1 模块 DOC/TEST/IMPL/INT |
| SA-P1-R19 | Phase1 assembly | W3/W4 | P1-SESSION-*、P1-LEGACY-RETIRE |
| SA-P2-S20/U21/R22/I23 | Phase2 具体模块 | W3/W4 | P2 模块 DOC/TEST/IMPL/INT、P2-REJ-ACCEPT/P2-INT-ACCEPT/P2-ASSEMBLY-ACCEPT |
| SA-P2-X24 | Phase2 assembly | W3/W4 | P2-SESSION-*、P2-NODE-CALL-001、P2-IMPL-COMPLETE-001 |
| SA-P3-P25/S26/F27 | Phase3 projection/resample/FITS | W3/W4 | P3 模块 DOC/TEST/IMPL/INT |
| SA-P3-X28 | Phase3 assembly | W3/W4 | P3-SESSION |
| SA-QA-29 | 机器检查、AST/追溯/质量 | W0/W5/W7 | QA-001..008、LNX-003/004 |
| SA-WIN-30 | Fatduck 只读编译/重验证 | W6 | WIN-001..014、P1/P2/P3 real |
| SA-PKG-31 | 白名单/审计包/封签 | W5/W8 | LNX-006、PKG-001..003 |

## 并行与集成

- 不同 owner、不同 mutex、无依赖的任务可同时派发；这是任务级并行，不是允许同时写 `main`。
- 同一 owner 只能有一个写任务；同一 mutex 只能有一个任务；Windows heavy 只能在 Fatduck 在线执行。
- 所有 patch 返回前台；前台在 `main` 一次只应用一个 patch，复跑 acceptance，原子 commit 和 push。
- 旧 base 的返回包先由控制面按 changed-files/mutex 判定：完全不相交且补丁可干净
  应用时可在最新 main 上验收；有冲突、接口/科学合同变化或路径相交则标
  `REBASE_REQUIRED` 退回原 owner。不得手工把两个 patch 拼成一个 commit。
- SA-AUD-99 可在任何波次并行读审，但不改代码/账本，也不阻断不相关任务。
