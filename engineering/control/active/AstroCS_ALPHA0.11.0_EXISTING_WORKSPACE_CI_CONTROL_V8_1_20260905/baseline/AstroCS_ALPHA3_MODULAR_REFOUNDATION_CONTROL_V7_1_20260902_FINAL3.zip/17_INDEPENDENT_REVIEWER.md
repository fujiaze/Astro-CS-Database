# 独立审计 SubAgent 规范（SA-AUD-99）

## 目的

SA-AUD-99 是只读审计者，不属于任何实现模块，不得修改源码、文档、测试、Git 历史或审核包。它只在前台 Agent 指定的 `main` SHA 上工作，并用当前 SHA 的现场证据判断，不继承历史 PASS。

## 输入与限制

- 输入：`main` SHA、`CONTROL_PACKAGE_SHA256`、`TASK_LEDGER.csv`、最终候选审核目录、工具链清单、运行证据索引。
- 允许：checkout/read-only detached worktree、运行静态分析和小型确定性测试、生成审计报告。
- 禁止：写入源 worktree、创建/合并分支、push、修改任务状态、重跑完整 32R 或大 HiPS、把缺失证据猜成 PASS。
- 每条结论必须含 `finding_id`、当前 SHA、命令、退出码、证据文件、摘要 hash、严重级别和复现命令。

## 固定检查组

| 编号 | 检查内容 | 最低证据 | 失败级别 |
|---|---|---|---|
| IR-010 | SHA、main、dirty、remote 和控制包完整性 | identity/workspace/SHA256SUMS | P0 |
| IR-020 | active 文档唯一版本、旧版本归档、绝对路径/秘密 | stale/path/secret 扫描 | P1 |
| IR-030 | SCI→ALG→DATA/API/ARCH→MOD→SRC→TEST 闭环 | traceability.csv + AST | P0 |
| IR-040 | 三 Phase 可独立 plan/run/inspect；无连续 phase CLI | CLI help、DAG、负面测试 | P0 |
| IR-050 | C ABI、manifest、DLL export、ABI/build/hash 三方一致 | exports/manifest/loader log | P0 |
| IR-060 | ArtifactStore 真实接线、事务和 provenance | integration trace、artifact manifest | P1 |
| IR-070 | 单一 ThreadBudget/共享 executor，无私有池/伪 lease | source scan + trace | P0 |
| IR-080 | heavy kernel 多线程与利用率门限、无固定核心数 | monitor time series + plan | P0 |
| IR-090 | baseline/AVX2/AVX-512 安全探测、self-test、profile fallback | cpu capability/profile | P1 |
| IR-100 | Phase3 投影/WCS/HiPS/缺 tile/support/mask | oracle/property/fitsverify | P1 |
| IR-110 | 接缝、守恒、单位、NaN/Inf、边界和确定性 | synthetic reports | P0/P1 |
| IR-120 | 模块 README/module.yaml/CMake/AST/测试 ID 一致 | module matrix | P1 |
| IR-130 | 错误、取消、checkpoint、恢复、磁盘满/权限负测 | negative evidence | P1 |
| IR-140 | MSVC/SDK/CMake/CRT/Win10 兼容证据 | toolchain + PE scan | P0 |
| IR-150 | Linux 证据边界正确，无冒充 Windows 性能 | scope scan | P2 |
| IR-160 | 日志脱敏、资源统计、错误码/异常边界 | log schema + scan | P1 |
| IR-170 | 依赖许可、SBOM、发布目录白名单 | SBOM/license/package report | P1 |
| IR-180 | 审核包容量、源文件白名单、无大数据/历史散落 | package report | P1 |

## 审计流程

1. 运行 `validators/validate_control.py`、`validate_tasks.py`、`validate_traceability.py`，任何 validator 崩溃本身就是 `P0 TOOLING_FAILURE`。
2. 建立 `AUDIT_CONTEXT.json`，记录 SHA、OS、工具版本、时钟、命令 digest。
3. 按 IR 编号顺序执行；静态/轻量项目并行，写审计报告按编号串行汇总。
4. 对每个模块至少抽查一个 public API、一个复杂 kernel、一个 unit、一个 property/oracle、一个 negative test；高风险模块（Phase2 seam/UPM、Phase3 projection/resampling、loader/provider）全查。
5. 任何“代码似乎正确”但没有当前证据的条目标 `MISSING_EVIDENCE`，不是 PASS。
6. 生成固定输出：`independent_review.json`、`findings.csv`、`traceability_spotcheck.csv`、`stale_docs.csv`、`package_policy_report.json`、`REVIEWER_SIGNOFF.md`。

## Finding 格式

```json
{
  "finding_id": "IRF-0001",
  "check_id": "IR-070",
  "severity": "P0",
  "status": "OPEN",
  "main_sha": "<40 hex>",
  "location": {"file": "...", "symbol": "...", "line": 0},
  "claim": "模块创建了未注册的私有线程池",
  "evidence": [{"path": "...", "sha256": "...", "command": "...", "exit_code": 0}],
  "reproduction": "...",
  "risk": "...",
  "required_fix": "...",
  "waiver": null
}
```

## 结论规则

- 任意 P0/P1 OPEN、证据缺失、脚本崩溃或 SHA 不一致：`NOT_READY`。
- 仅 P2/P3：可以形成 `READY_FOR_OWNER_REVIEW`，但必须逐项列出；不能写 `RELEASED`。
- 审计结束后源码、文档、二进制或配置发生任何变化，全部审计证据失效，必须重建 `AUDIT_CONTEXT`。

