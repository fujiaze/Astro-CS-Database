# 审核包与源码快照规范（Alpha 0.11.0）

## 1. 唯一交付物

最终交付是一个精简、可验证、可复现的 ZIP：

```text
AstroCS_ALPHA0.11.0_REVIEW_<UTC>_<MAIN_SHA12>.zip
```

不得把整个工作目录、历史控制包或原始数据直接压缩。包内根目录固定为 `AstroCS_REVIEW/`，压缩前后都必须运行三层校验：包内 validator、解包后 `SHA256SUMS`、独立 auditor。

## 2. 固定目录

```text
AstroCS_REVIEW/
  00_READ_FIRST.md
  REVIEW_MANIFEST.json
  SHA256SUMS
  evidence/
    SUMMARY.json
    identity.json
    host_toolchain.json
    task_ledger_snapshot.csv
    gate_results.json
    evidence_index.csv
    findings.csv
    traceability.csv
    resource_summary.json
    package_policy_report.json
    independent_review.json
    logs/                 # 只允许摘要/首尾片段，原始长日志另存引用
  source/
    SOURCE_MANIFEST.json
    source_tree.tar.gz   # 唯一允许的源码快照归档；禁止使用第二种格式
  docs/
    L0_OWNER_REVIEW.md
    L1_ENGINEERING_STATUS.md
    L2_SCIENCE_ALGORITHM_INDEX.md
    L3_MACHINE_TRACEABILITY.md
    module_index.csv
  configs/
    product_manifest.json
    module_manifests/
    cmake_presets.json
  tests/
    test_index.csv
    synthetic_fixture_generators/
  references/
    references.lock.json
  provenance/
    build_commands.json
    environment_summary.json
```

## 3. 源码快照白名单

必须包含当前 `main` SHA 的：`CMakeLists.txt`、`CMakePresets.json`、`cmake/`、`include/`、`modules/`、`lib/`（仅仍在 active source manifest 中的迁移文件）、`cli/`、`tests/`、`tools/quality/`、`docs/science/`、`docs/algorithm/`、`docs/architecture/`、各模块 README/module.yaml 和许可证。

打包前由 `SOURCE_ALLOWLIST.txt` 精确列举；每个文件有 size/hash。源码快照必须可从 `source_commit` 和 allowlist 复原。

## 4. 明确排除

以下永不进入审核包（只在 `LARGE_ARTIFACT_MANIFEST.csv` 记录逻辑名、大小、SHA、来源、获取方式）：

- 原始 FITS/testdata、32R 全量数据、HiPS tile、像素级 CSV、数据库和索引；
- `build/`、`out/`、`install/`、`.vs/`、`.git/`、缓存、对象文件、PDB、临时目录、core dump；
- 单个普通文件 >5 MiB；源码快照归档是唯一例外，必须由 SOURCE_MANIFEST 逐项约束且解压后每个成员≤5 MiB；模块 fixture 单文件 >256 KiB 或模块总量 >2 MiB；
- 历史审核包、旧 control/review/release 包、重复源码副本、聊天导出、路径含凭据的日志；
- `node_modules/`、Python 虚拟环境、系统 SDK、第三方安装器和完整工具链。

禁止以“方便 Agent”为理由突破白名单。若证据需要大文件，上传到外部受控位置并只登记哈希和最小获取命令。

## 5. 证据要求

每条 evidence 记录：`evidence_id, task_id, gate_id, main_sha, command, start/end UTC, exit_code, stdout/stderr hash, input/output hashes, toolchain_id, platform_scope, status`。终端最后一行不算证据；日志必须可复现且脱敏。

`SUMMARY.json` 的 task/gate/finding 计数只能由 CSV/JSON 单源重新计算，禁止手填。`verdict` 只能是 `READY_FOR_OWNER_REVIEW`、`NOT_READY`、`BLOCKED_EXTERNAL`、`PACKAGE_INVALID`。

## 6. 容量与完整性门禁（v2）

- 包总大小目标 ≤20 MiB；超过必须由 package-policy task 说明每个大文件的必要性。
- ZIP 内无嵌套审核包、无绝对本机路径、无未登记文件、无符号链接逃逸、无重复历史目录。
- `REVIEW_MANIFEST.json` 记录 package format version、product version、source/main SHA、文件列表/大小/hash、生成脚本版本、排除统计。
- `SHA256SUMS` 仅对包内文件，使用 POSIX 相对路径；解包后验证退出码必须为 0。

## 7. 发布与归档

控制包、审核包、源码快照和历史包只能放在项目控制目录：

```text
<work_root>/control/active/
<work_root>/control/archive/<date>/<package_name>/
<work_root>/audit/incoming/
<work_root>/audit/archive/<date>/
<work_root>/artifacts/large-manifest/
```

根源码目录不得散落 ZIP、长日志或旧报告。每次新包生成前移动旧包到 archive，并写 `ARCHIVE_INDEX.csv`；不得删除用户已有的其他项目文件。

