# CPU provider、benchmark 与资源利用标准

## 1. Provider 层级

```text
kernel interface → provider table → baseline/avx2/avx512 implementation
                  → runtime profile selector
```

科学算法只调用 kernel interface，不包含 `#ifdef AVX` 的业务分支。高级 provider 只实现已证明热点，其余 kernel 返回 unsupported 并由 host 使用 baseline。

## 2. 能力安全

启动时：CPUID feature → OSXSAVE → XGETBV XMM/YMM/ZMM state → DLL ABI/hash → provider self-test。硬件支持但 OS 不保存寄存器时拒绝。AVX-512 至少检查所需 F/CD/BW/DQ/VL 子集；不能只看一个 `AVX512=true`。

## 3. Benchmark 实验

`astrocs benchmark cpu` 先生成确定性输入，再 warmup，后按 kernel×size×provider×workers 重复测量；输出 median/MAD/p95/wall/cpu/memory bandwidth/bytes、结果 hash/ULP/abs/rel diff。不得以单次最快值选择。短测试允许 quick，发布 profile 用 release suite；两套均保存原始数据和命令。

Profile 的选择规则：self-test 通过；结果容差通过；在同一 kernel/size 上相对 baseline 收益超过冻结噪声门限；不触发明显频率/内存回退；CPU/OS/build/hash 匹配。否则 baseline。没有 profile、损坏或版本不匹配也 baseline。

## 4. 资源门禁

heavy workload/span：由 workload contract 按 kernel 类型标为 `cpu-bound`、
`memory-bound`、`io-bound` 或 `lock/queue-bound`；数值 kernel 占主导的区间不得
被拆分成短片段规避门禁。5 秒只是建议的统计窗口，不是 heavy 的资格条件：一个
run 内所有同类 CPU-heavy span 的累计 wall 时间和每段时间都必须进入统计；任何
单段或累计 CPU-heavy 工作都不能以串行执行通过。资源门禁不能只看配置里的
workers。每个采样点和汇总必须同时记录：effective_available_workers（CPU
affinity、cgroup/Job、用户上限和运行时可用资源取最小后的有效数）、granted、
active、process CPU、system CPU。

定义：`grant_coverage=granted/effective_available_workers`；
`active_coverage=active/effective_available_workers`；
`system_normalized_utilization=system_cpu_core_seconds/(wall_seconds×effective_available_workers)`；
`process_normalized_utilization=process_cpu_core_seconds/(wall_seconds×effective_available_workers)`。
报告中的 CPU 百分比必须说明是进程 CPU 时间还是系统 CPU 时间；若操作系统给出
百分比，先换算为同一 wall 区间的 core-seconds 再归一化。分母不得使用硬编码
核心数、逻辑核总数或配置请求数替代 effective_available_workers。

CPU-bound 且有足够 work units 时，平均 process_normalized_utilization 必须≥0.80，
至少 70% 采样窗口≥0.75；grant_coverage 和 active_coverage 必须能解释该结果；
队列有可运行工作时任一采样窗口不得低于 0.50；2 worker/1 worker speedup≥1.60。
若属于 memory/IO/lock-bound，必须提交可复现实验的带宽、I/O、队列、锁等待和
active 证据，不能用一句分类说明放行。任何 CPU-heavy 单段或累计 run 若实际串行
或 granted=1 且非明确 `tiny_work`，立即 FAIL。

## 5. 资源监控

每秒记录 timestamp/process/system CPU/active/granted/peak workers/RSS/private/commit/read/write/queue/lock/io wait/provider/module/phase。监控器与业务同 run ID；报告原始时间序列和不可修改 hash。内存测试必须重复小 run 检查 outstanding allocations 和 RSS 单调增长；cache 必须有上限。

## 6. 编译隔离

baseline 不带 `/arch:AVX*`；AVX2 target 仅 `/arch:AVX2`；AVX512 target 仅 `/arch:AVX512`。禁止全局 `/fp:fast`/LTCG/PGO；/fp:precise 生产，/fp:strict oracle。FMA/SIMD/并行归约若改变结果顺序，容差必须来自 ALG 且在代码前冻结。
