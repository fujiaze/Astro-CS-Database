# Linux 常在线控制节点规范

## 1. 定位

Linux amd64 腾讯云服务器约 2 logical cores、约 2–4 GiB 可用内存，常在线但算力低。它是控制/static/light validation 节点，不是 Windows 产品架构驱动节点，不用来反复跑 32R 或大 HiPS。

## 2. 必做

- 读取/验证工程约束、active 文档、module manifests、schema；
- CMake configure、轻量编译、syntax/AST、clang-tidy/format；
- ABI/registry/DAG/phase isolation/Artifact/ThreadBudget 结构测试；
- 每模块确定性小合成 unit/property/oracle/negative；
- 小型 sanitizer/leak/取消/失败测试；
- plan/trace/运行图/追溯和审核包预检；
- Windows 离线时准备所有可交付脚本和外部任务清单。

## 3. 资源纪律

1. 一次最多一个编译或 CPU-heavy 测试；静态读取可并行。
2. configure/build 默认 `-j1`；实际证明不 OOM 后才允许 `-j2`，不得固定更大。
3. 每个可能超过 60 秒的命令必须 timeout、日志文件、资源监控；建议 timeout 由 task spec 给出，默认 1800 秒。
4. fixture 必须先估算内存；遇 OOM 只缩小数据，不删测试维度/放宽科学门限。
5. 监控 `/proc`：CPU、RSS、IO bytes、threads、load、queue；报告 Linux 资源事实，不冒充 Windows 性能。
6. 不下载/缓存原始 testdata、完整 HiPS、大索引；真实辅助数据由 Fatduck 按哈希小量提供。

## 4. Linux 命令模板

```bash
timeout 30m python3 tools/quality/run_all_static.py --preset linux-control \
  > "$ASTROCS_WORK_ROOT/logs/qa-static.stdout.log" \
  2> "$ASTROCS_WORK_ROOT/logs/qa-static.stderr.log"
```

复杂 JSON/正则/循环先写脚本再运行；禁止把命令替换、敏感变量或用户路径写入证据。每个命令另存 JSON record，不能只贴终端最后一行。

## 5. Linux PASS 的边界

Linux PASS 只证明该条静态/轻量/小合成检查在当前提交通过。以下结论不能从 Linux 推出：Windows ABI/加载、Win10兼容、AVX-512性能、Fatduck资源利用、32R、HiPS浏览器显示。报告必须明确 `PLATFORM_SCOPE=LINUX_CONTROL_ONLY`。

## 6. Windows 离线时

前台 Agent 继续 W7 文档/质量/打包；Windows task 标 `WAITING_RESOURCE`，保存待运行命令和输入 hash。不得使用旧 Windows 证据代替当前 SHA，也不得停工等待用户回复。
