# 模块 `<prefix>` DOC/TEST/IMPL/INT 验收

## DOC

- [ ] `README.md`、`module.yaml`、SCI/ALG/API/DATA/ARCH/TEST ID 齐全且当前版本为 `0.11.0-alpha.1`。
- [ ] 明确负责/不负责；无 Phase Session 或全局调度算法藏在模块内。
- [ ] 输入输出 port 有单位、frame/epoch、dtype、shape、mask/invalid/NaN/Inf、所有权。
- [ ] 数学定义→离散算法→误差/复杂度→并行归约→验证 oracle 链接完整。
- [ ] source symbols 从 AST 生成并与 README/module.yaml 一致；不存在手写漂移。

## TEST

- [ ] unit、property、不变量、独立 oracle、negative、performance、integration target 均存在。
- [ ] fixture generator 固定 seed；无大二进制；测试可单独 CTest label 运行。
- [ ] 空/单元素/边界/NaN/Inf/坏 schema/取消/磁盘满/重复 publish 有负测。
- [ ] 容差来自 ALG 文档；没有“跑生产函数生成 expected”。
- [ ] 记录 1 worker/N worker、baseline/AVX2/AVX-512（不支持时显式 skip）和确定性。

## IMPL

- [ ] 只有批准 C ABI export；C ABI 不传 STL/exception/裸所有权。
- [ ] `plan` 输出 work units、parallel axis、workers 范围、memory/I/O 估计、kernel ID。
- [ ] `execute` 使用 typed ArtifactHandle、host logger/metrics/cancel/store/executor；不拼任意路径。
- [ ] exception→status；跨 DLL 内存 ownership 清楚；事务 output 失败不发布半成品。
- [ ] 生产源码和独立 oracle 差分报告完成；科学变更有明确 reviewer。

## INT

- [ ] module.yaml、DLL query、product manifest 三方一致（ID/ABI/version/ports/hash/build ID）。
- [ ] Phase DAG 中节点只注册一次且真实执行一次；call count 与 trace 一致。
- [ ] 缺 DLL/坏 ABI/坏 hash/重复节点/错误 artifact 会失败；不静态偷偷 fallback。
- [ ] `validate/plan/run/inspect` 均可独立运行；跨 Phase 输入只经已发布 Artifact。

