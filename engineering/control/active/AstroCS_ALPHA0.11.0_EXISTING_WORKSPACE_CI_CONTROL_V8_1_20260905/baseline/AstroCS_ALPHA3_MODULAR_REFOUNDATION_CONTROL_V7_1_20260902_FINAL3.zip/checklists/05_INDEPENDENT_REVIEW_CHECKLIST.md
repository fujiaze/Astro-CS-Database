# SA-AUD-99 终审清单

- [ ] 只读 detached worktree；当前 main SHA 与所有证据一致。
- [ ] validator 没有崩溃、导入错误、未处理异常；任何工具失败均为 P0。
- [ ] IR-010..IR-180 每项都有 PASS/FAIL/MISSING_EVIDENCE 和命令/hash。
- [ ] 至少抽查每模块 public API、复杂 kernel、unit、property/oracle、negative；高风险模块全查。
- [ ] 旧文档只在 archive；active 文档无陈年版本号、绝对路径、连续 Phase、虚假异步/并行描述。
- [ ] SCI/ALG/DATA/API/ARCH/MOD/SRC/TEST/EVID 链每个抽样闭环；科学公式不以关键词扫描替代。
- [ ] trace 中 worker/provider/module/调用次数是观测值；配置/预计值未冒充事实。
- [ ] P0/P1 OPEN 为 0；否则结论 NOT_READY；不能 waiver 或写 RELEASED。
- [ ] 生成 `independent_review.json`、`findings.csv`、`traceability_spotcheck.csv`、`stale_docs.csv`、`REVIEWER_SIGNOFF.md`。

