# FG-000 每轮执行清单

## 启动

- [ ] 读取 `00_READ_FIRST.md`、`01_OWNER_FROZEN_CONSTRAINTS.md`、当前波次和对应 task spec。
- [ ] `git fetch origin --prune`；确认当前分支仅 `main`，`HEAD == origin/main`，记录 40 位 SHA。
- [ ] 校验控制包 `SHA256SUMS`；记录控制包 hash、版本、生成时间。
- [ ] 读取根/模块 memory、active docs index；将陈旧文档/外部改动登记，不猜来源。
- [ ] 创建 detached worktree、任务锁、`TASK_LEDGER_SNAPSHOT.csv`；不创建功能分支。
- [ ] 计算依赖闭包；只把依赖 CLOSED 的任务置 READY。

## 派发

- [ ] owner ID 与 `05_FIXED_SUBAGENT_BINDINGS.yaml` 一致。
- [ ] 输出路径完全落在 owner allowlist；无跨 owner 文件。
- [ ] `base_main_sha` 是当前 main，不是 agent 上次 SHA。
- [ ] 明确 mode、resource class、mutex、timeout、输入 hash、输出清单、验收条件。
- [ ] 写任务在 detached worktree；只读审计和证据任务不得改源码。
- [ ] heavy 任务只派 Fatduck；Linux 只派 static/light/synthetic。

## 回收

- [ ] 结果文件符合 `schemas/task_result.schema.json`；脚本/测试非零退出必须 FAIL。
- [ ] 对照 changed_files 与 owner allowlist；发现越界立即拒收。
- [ ] 每个测试有独立 expected source、seed、输入/输出 hash、容差来源。
- [ ] 证据记录含命令、开始/结束、退出码、stdout/stderr hash、平台范围。
- [ ] 核对没有新增大二进制、原始数据、绝对路径、秘密或历史包。
- [ ] 科学合同变更默认 `scientific_change=true`；没有 reviewer 说明不得改成 false。

## 集成

- [ ] 只把一个已验收 patch 应用到 main；先跑冲突/编译/受影响测试，再提交。
- [ ] commit subject 对应唯一 task ID；不混合无关格式化或其他 owner 文件。
- [ ] `git diff --check`、静态检查、最小模块测试通过后 commit。
- [ ] 立即 push main，重新 fetch，验证远端 SHA；更新 ledger 和 evidence。
- [ ] 旧 base 上尚未完成的 agent 任务全部标 `REBASE_REQUIRED`，不得直接合并。

## 推进

- [ ] 重新计算任务依赖、Gate 和 P0/P1 计数；不手填汇总。
- [ ] Gate 失败只退回相关 owner；无关任务继续，不等待逐关批准。
- [ ] Windows 离线时标 `WAITING_RESOURCE`，保存命令与输入 hash，继续 Linux/文档/打包任务。
- [ ] 源码/文档/配置/工具链变化后使旧 evidence/审计签名失效并登记。
- [ ] 最终只输出 `READY_FOR_OWNER_REVIEW` 等四种 verdict，不替负责人发布。

