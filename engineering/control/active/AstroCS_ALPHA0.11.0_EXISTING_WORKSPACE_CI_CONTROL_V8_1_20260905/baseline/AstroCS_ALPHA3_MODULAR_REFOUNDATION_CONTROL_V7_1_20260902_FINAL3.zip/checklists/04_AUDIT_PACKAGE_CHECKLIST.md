# 审核包封签清单

- [ ] 包名符合 `AstroCS_ALPHA0.11.0_REVIEW_<UTC>_<SHA12>.zip`，根目录唯一 `AstroCS_REVIEW/`。
- [ ] `REVIEW_MANIFEST.json`、`SHA256SUMS`、summary、task/gate/finding/evidence、source/docs/configs/tests/references/provenance 齐全。
- [ ] 源码快照来自最终 main SHA；`SOURCE_MANIFEST` hash 可重建；没有工作树未提交内容。
- [ ] 原始 FITS、32R、HiPS tile、大索引、大日志、build/install/.git、旧包均排除，仅进大型物 manifest。
- [ ] 单文件 ≤5 MiB；fixture 单文件 ≤256 KiB、模块总量 ≤2 MiB；包目标 ≤20 MiB。
- [ ] 无绝对路径、凭据、秘密、符号链接逃逸、嵌套 ZIP/TAR、重复历史目录。
- [ ] `validate_control.py`、`validate_audit_package.py`、解包 `sha256sum -c` 三层 exit 0。
- [ ] summary 计数由 CSV/JSON 重算；verdict 是允许枚举；P0/P1 计数为 0 才可 READY。
- [ ] 归档旧包到控制目录 archive，更新 `ARCHIVE_INDEX.csv`，根源码目录不散落包和日志。

