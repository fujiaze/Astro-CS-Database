# Fatduck Windows 验收清单

- [ ] Windows 10 22H2 x64 或 Win11 x64 现场身份与网络可用性已记录。
- [ ] VS Build Tools `17.14.39` / VCTools `14.44.35207` / SDK `10.0.26100.0` / CMake `3.31.12` 精确匹配；安装器和版本 hash 已记录。
- [ ] 使用固定 Visual Studio 17 2022 x64、host=x64、v143；全新 build tree；无旧缓存。
- [ ] Debug `/MDd`、Release/RelWithDebInfo `/MD`；生产 `/fp:precise`；oracle `/fp:strict`；无全局 `/arch`、/GL、LTCG、PGO、/fp:fast。
- [ ] `astrocs.exe` 是唯一 CLI；模块 DLL 在 manifest 白名单，HiPS browser 不加载进 CLI。
- [ ] `dumpbin` PE x64、exports、dependents、Win10 API、CRT、DLL search path 检查通过。
- [ ] 缺 DLL/坏 SHA/错 ABI/错误架构/恶意当前目录 DLL 负测失败并有诊断。
- [ ] CPU benchmark 先 self-test，再 profile；无 profile 走 baseline；worker 数由 profile/resource 产生。
- [ ] heavy span ≥5s 运行监控；U、可运行队列、speedup、RSS/IO/lock/queue 原始序列齐全。
- [ ] Phase1/2/3 分别 `validate/plan/run/inspect`；禁止一次连续 phase。
- [ ] 合成全模块 CTest、接缝/守恒/投影/缺 tile/support/mask 通过。
- [ ] 32R 真实数据只做一次候选全量；记录每帧 hash、输出 hash、运行图和资源证据。
- [ ] Win10 smoke、Win11 full、HiPS/FITS `fitsverify`、原子 publish/rollback 证据齐全。
- [ ] Windows 离线时不伪造 PASS；任务状态 WAITING_RESOURCE，Linux 继续非重任务。

