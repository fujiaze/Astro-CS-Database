# SubAgent 交付前自检

- [ ] 我只修改了绑定目录；`git diff --name-only` 已保存。
- [ ] 我基于 dispatch 的 `base_main_sha`，没有拉入未声明提交。
- [ ] 我没有创建分支、push、改容差、删失败测试、下载大数据或复制历史包。
- [ ] 我先写/运行测试（模块迁移必须 TEST 先于 IMPL）；oracle 不调用生产 symbol。
- [ ] 我更新了 README/module.yaml/SCI/ALG/API/ARCH/TEST 链接（如适用）。
- [ ] 所有函数/公共接口注释含单位、所有权、线程、取消、误差和 ID。
- [ ] heavy 代码通过 host executor/lease；没有私有线程池、固定 worker 或裸 `std::async`。
- [ ] provider 代码不在全局业务分支；能力探测、self-test、fallback 有测试。
- [ ] 每个命令有 timeout 和日志；结果有 exit code、hash、seed、平台范围。
- [ ] 我填写了已验证、未验证、已知限制、遗留问题，没有把历史 PASS 当当前证据。
- [ ] `TASK_RESULT.json`、`EVIDENCE_RECORD.json`、patch/diff 和测试报告都在输出清单内。

