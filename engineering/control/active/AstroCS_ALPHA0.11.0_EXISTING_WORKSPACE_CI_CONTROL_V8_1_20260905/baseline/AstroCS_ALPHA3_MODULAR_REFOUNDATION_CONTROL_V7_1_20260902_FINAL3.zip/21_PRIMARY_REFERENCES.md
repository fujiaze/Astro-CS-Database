# 主要科学与工程参考

这些参考用于 SCI/ALG 文档的推导和审计。Agent 必须在具体合同中写明引用章节/公式用途，不得只堆链接；若实现与参考不同，必须说明近似、误差和验证方法。

## WCS/FITS/投影

- Greisen & Calabretta, 2002, *Representations of world coordinates in FITS*, A&A 395, 1061（WCS 语义、坐标轴和 CD/PC 矩阵）：<https://doi.org/10.1051/0004-6361:20021326>
- Calabretta & Greisen, 2002, *Representations of celestial coordinates in FITS*, A&A 395, 1077（TAN、SIN、ZEA 等投影）：<https://doi.org/10.1051/0004-6361:20021327>
- FITS Standard 4.0（header、HDU、checksum、数据类型）：<https://fits.gsfc.nasa.gov/fits_standard.html>
- WCSLIB 文档/参考实现（仅 test-only oracle 或 I/O 适配，不跨 ABI）：<https://www.atnf.csiro.au/computing/software/wcslib/>

## HEALPix/HiPS

- Górski et al., 2005, *HEALPix: A Framework for High-Resolution Discretization...*, ApJ 622, 759（NESTED/RING、等面积球面像素）：<https://doi.org/10.1086/427976>
- HiPS IVOA Recommendation（properties、tile/order、坐标和服务约定）：<https://ivoa.net/documents/HiPS/>
- HiPS 1.0 specification（镜像/版本时以 IVOA 当前正式文档为准）：<https://www.ivoa.net/documents/HiPS/20170525/>

## 验证工具

- NASA/HEASARC `fitsverify`：<https://heasarc.gsfc.nasa.gov/docs/software/ftools/fitsverify.html>
- IVOA Standards Registry：<https://www.ivoa.net/standards/>

## Windows/构建依据

- VS 2022 release history：<https://learn.microsoft.com/en-us/visualstudio/releases/2022/release-history>
- VS servicing：<https://learn.microsoft.com/en-us/visualstudio/releases/2022/servicing-vs2022>
- Build Tools component IDs：<https://learn.microsoft.com/en-us/visualstudio/install/workload-component-id-vs-build-tools?view=visualstudio>
- CMake VS 17 2022 generator：<https://cmake.org/cmake/help/v3.31/generator/Visual%20Studio%2017%202022.html>
- CMake presets：<https://cmake.org/cmake/help/v3.31/manual/cmake-presets.7.html>
- MSVC `/arch`：<https://learn.microsoft.com/en-us/cpp/build/reference/arch-x64?view=msvc-170>
- MSVC CRT：<https://learn.microsoft.com/en-us/cpp/build/reference/md-mt-ld-use-run-time-library?view=msvc-170>
- VC++ Redistributable：<https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170>
- Secure DLL loading：<https://learn.microsoft.com/en-us/windows/win32/api/libloaderapi/nf-libloaderapi-loadlibraryexa>

