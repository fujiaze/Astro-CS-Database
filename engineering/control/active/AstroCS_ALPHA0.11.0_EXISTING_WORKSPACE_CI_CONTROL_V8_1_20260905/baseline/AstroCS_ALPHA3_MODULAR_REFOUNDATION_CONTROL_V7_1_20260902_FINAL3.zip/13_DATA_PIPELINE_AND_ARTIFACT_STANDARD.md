# 数据管道、I/O 与 ArtifactStore 标准

## 1. 数据对象而不是路径字符串

Pipeline edge 传递 `ArtifactHandle`，不是 `"artifact:hips_in"` 或模块自己拼接的文件名。handle 必须可向 Store 查询：type/schema/units/coordinate/dtype/shape/planes/validity/storage/hash/producer/run/config。

## 2. 三阶段产品类型

| type_id | 最小内容 | 生产者/消费者 |
|---|---|---|
| `astrocs.phase1.frame_hips.v1` | properties、FITS tiles、SCI/variance/support/mask、frame metadata、manifest/hash | Phase1输出；Phase2可消费 |
| `astrocs.phase2.mosaic_hips.v1` | mosaic HiPS、UPM/rejection/integration provenance、planes、manifest/hash | Phase2输出；Phase3可消费 |
| `astrocs.phase3.planar_fits.v1` | SCI/SUPPORT/MASK、WCS、provenance、checksum | Phase3输出；外部消费 |
| `astrocs.calibrated_frame.v1` | 标定数据、units、variance、mask、frame identity | Phase1内部 |

任一 product 必须声明 frame/epoch/coordinate、单位、dtype、invalid/NaN、mask bit、shape/order/tile width；缺失不得根据文件名猜。

## 3. Store 事务

```text
begin_write → write_chunk* → flush/close → validate → digest
→ atomic_publish → complete_manifest
```

临时对象只能在 run 临时目录；publish 后只读。失败/cancel/异常/进程中断清理或标 `INCOMPLETE`，不得被 inspect/run 当成功输入。不同 run 输出不得固定覆盖；overwrite 仅显式配置。

## 4. FITS/HiPS

CFITSIO/zlib 等只能在 I/O DLL 内；C ABI 不暴露第三方类型。FITS reader 支持 header/plane/chunk，writer 支持 block/extension/checksum/verify。HiPS reader 校验 properties、NESTED order、tile width、FITS tile、partial tree；缺 tile 产生 `TILE_ABSENT`，不得父 order fallback。

## 5. Provenance

最终 manifest 必须记录 product/module/ABI/schema version、source commit、host/toolchain、config/input/provider/workers、science/algorithm IDs、input/output digests、开始结束时间、资源摘要、异常/cancel 状态。绝对路径需脱敏；外部数据只记录逻辑位置、大小、SHA、manifest SHA，不把原始数据放审核包。

## 6. 数据一致性测试

必须对坏 schema、单位/坐标/dtype/shape mismatch、header truncation、checksum、NaN/Inf、partial/missing、磁盘满、权限、路径穿越、并发 publish、resume 和 manifest 篡改注入测试。测试期望由独立 fixture/oracle 提供。
