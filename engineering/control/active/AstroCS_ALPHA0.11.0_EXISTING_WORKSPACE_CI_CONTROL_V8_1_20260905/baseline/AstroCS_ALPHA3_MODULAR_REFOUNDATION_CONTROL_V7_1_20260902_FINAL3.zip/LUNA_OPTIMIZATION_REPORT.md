# Luna V7.1 控制包修订报告

## 结论

本目录是 V7 的非破坏性修订版，只修改控制包、任务合同、科学合同和控制面校验器，
没有修改 AstroCS 源码、没有运行历史版本差分或真实科学重计算。V7 独立审计报告中
列出的 P0 硬阻断均已转化为机器门禁或明确的前台流程；P1 的任务图、科学合同、
审核包格式和工具链约束已补齐。最终是否可发布仍由前台在真实 main 和审核证据上
重新计算 Gate，不能由本报告单独宣称通过。

## P0 处置矩阵

| ID | 原问题 | V7.1 处置 | 验证 |
|---|---|---|---|
| P0-01 | 校验过程会产生 `__pycache__`，包会自污染 | 控制包拒绝生成目录；suite 设置 `PYTHONDONTWRITEBYTECODE=1`；selftest 禁止写字节码；打包前清理并 fresh-unzip 复验 | `validate_control`、selftest、fresh-unzip |
| P0-02 | manifest/SHA 只是声明未逐字节重算 | `validate_control.py` 对实际文件集合、size、SHA256SUMS 和 CONTROL_MANIFEST 双重重算，拒绝额外/缺失文件 | `CONTROL_PASS`；篡改/额外文件负测 |
| P0-03 | later-wave 依赖和 DAG 死锁 | `validate_tasks.py` 检查未知依赖、逆波依赖、DFS 环、模块 DOC 的传递依赖；Gate 任务集合单独声明 | `TASK_LEDGER_PASS`；逆波/环负测 |
| P0-04 | 状态机、模板和 schema 不一致 | 统一为 `NOT_STARTED/READY/DISPATCHED/RETURNED/INTEGRATED/CLOSED` 加异常态；TASK_RESULT v2 去除前台字段 | `TEMPLATES_PASS`；模板错配负测 |
| P0-05 | 检查器可被注释/示例/关键字绕过 | 模块、追溯、Phase、线程、CPU provider 检查器区分生产路径、测试路径和注释；要求真实 source symbol/CMake/CTest/入口 | 全 suite |
| P0-06 | 审计 owner 可修改实现 | 固定 `SA-AUD-99` 为只读；audit/evidence 必须 `no-commit/evidence-only`；前台独占 main 集成 | ledger/schema/control-plane |
| P0-07 | Gate 由手写 CLOSED/固定清单决定 | `GATE_REQUIREMENTS.csv` 是任务集合事实源；control plane 按当前 state、evidence、findings、main SHA 重算 verdict | `control_plane.py gates` |
| P0-08 | 利用率分母只按租用 worker | 资源合同固定 effective_available_workers，并报告 granted/active/process/system 及 coverage；CPU-heavy 有效资源利用率不足直接失败 | 资源合同/资源任务门禁 |

## P1 处置矩阵

| ID | 原问题 | V7.1 处置 |
|---|---|---|
| P1-01 | owner/path 权限边界不清 | `05_FIXED_SUBAGENT_BINDINGS.yaml`、scope validator、模块单 owner 和 RT assembly 委托固定边界 |
| P1-02 | 所有旧 base 一律重放导致无谓 O(n²) | 前台按 changed-files/mutex 和 `git apply --check` 判断；不相交补丁可在最新 main 验收，有冲突才 `REBASE_REQUIRED`，禁止手工拼 patch |
| P1-03 | 真实数据任务重复运行 | `WIN-009/010/011` 为唯一真实证据；P1/P2/P3 real 与性能任务使用 alias/reuse，禁止重复 32R |
| P1-04 | Phase2 seam 多 owner | 拆为 rejection、integration、assembly 三个单 owner 验收任务；性能设计和 Windows evidence 分离 |
| P1-05 | SCI→ALG→API 链不完整 | 模块 DOC 必须先于 TEST/IMPL/INT；合同缺失统一 `CONTRACT_MISSING`，不能由实现反推科学定义 |
| P1-06 | UPM/Phase2 数学未经核实 | Phase2 合同把公式定义为待 SCI 冻结槽位，明确变量、权重、方差、正则化和独立 oracle 要求，禁止 Agent 自创公式 |
| P1-07 | Phase3 celestial/native 混用 | Phase3 明确 WCS Paper II Euler 旋转；`sky→pixel` 和 `pixel→sky` 双向顺序分别冻结 |
| P1-08 | frame、单位、像素中心不统一 | 明确 ICRS/FK5/GALACTIC、内部弧度、FITS 度、0/1-based 中心、CD/CRPIX/RADESYS/EQUINOX 规则 |
| P1-09 | mask/support/variance 语义缺失 | 固定 MASK bit0..5、SUPPORT、NaN、缺 tile、插值不完整和 `Σw² Var` 语义 |
| P1-10 | Phase3 实现错误声明无科学变更 | P3 projection/resample/FITS IMPL 要求 `scientific_change=true`、SCI reviewer 签核及 WCS/HEALPix 独立 oracle |
| P1-11 | module manifest 仅 DLL 名称、合同可空 | manifest v2 要求 Windows DLL/Linux SO、输入输出、SCI/ALG/DATA/API/source/test 全部非空并交叉校验 |
| P1-12 | 审核包可混入历史/大文件/路径 | audit validator 固定根目录 allowlist、容量、源快照唯一 tar.gz、成员、路径、链接、秘密和双重 SHA 门禁 |
| P1-13 | Windows 工具链 hash 口径不可靠 | 官方来源的 VS/SDK 可标 `OFFICIAL_VERIFIED`；CMake/LLVM/Python 未现场核验只能 `RECORDED_AT_INSTALL`，不得伪造冻结 hash |

## 新增/重点修改文件

- `validators/control_plane.py`：初始化状态、READY、DISPATCH、回包真实 schema、scope、
  rebase 标记和 Gate 计算；每个 required task 必须有当前 SHA 的 PASS evidence，
  alias 只能显式复用 canonical evidence，空 evidence 不得假 PASS。
- `validators/validate_control.py`、`validate_tasks.py`、`validate_audit_package.py`、
  `validate_templates.py`：控制包、任务图、审核包和模板的严格机器门禁。
- `validators/selftest.py`：篡改、额外文件、manifest/schema 错配、重复任务、未知依赖、
  DAG 环、逆波依赖、模板未知字段/嵌套类型/枚举、非法 TASK_RESULT 和空 evidence
  Gate 负测。
- `validators/common.py`：标准库递归 JSON-Schema 实例检查，避免只比较顶层字段。
  同时执行 `minimum/maximum` 数值边界检查，避免负 attempt、timeout 或 finding
  计数通过。
- `science/PHASE2_SEAM_AND_INTEGRATION_CONTRACT.md`、
  `science/PHASE3_PROJECTION_ALGORITHM_CONTRACT.md`：科学合同和独立 oracle 要求。
- `TASK_LEDGER.csv`、`GATE_REQUIREMENTS.csv`、`04_FOREGROUND_AGENT_RUNBOOK.md`：依赖、
  owner、主线集成和 Gate 事实源。
- `23_GRAPH_AND_DOC_TOOL_POLICY.md`、`toolchain.lock.json`：运行图和 Windows 工具链记录策略。

## 已执行验证

最终封签前必须按以下顺序执行，命令和退出码写入交付记录：

```bash
PYTHONDONTWRITEBYTECODE=1 timeout 60s python3 validators/build_control_manifest.py --root .
PYTHONDONTWRITEBYTECODE=1 timeout 60s python3 validators/run_control_checks.py --root .
PYTHONDONTWRITEBYTECODE=1 timeout 60s python3 validators/selftest.py
PYTHONDONTWRITEBYTECODE=1 timeout 30s python3 validators/control_plane.py init-state --root . --state /tmp/astrocs_state.json --main-sha <40位SHA>
PYTHONDONTWRITEBYTECODE=1 timeout 30s python3 validators/control_plane.py ready --root . --state /tmp/astrocs_state.json
```

V7.1 中已完成的 suite 结果为：`CONTROL_SUITE_PASS checks=12`、
`VALIDATOR_SELFTEST_PASS cases=16`。重新生成报告后必须再次执行；若任何 fresh-unzip
目录出现新增文件、SHA 不一致、单线程 heavy、旧版本活动文档或 Gate 循环，结论必须为
`NOT_READY`，不得人工放宽阈值。

## 不属于本包且不得伪称已完成

本包没有替代真实 main 的源码实现、SCI reviewer 签核、Linux/Windows 编译证据、
WCSLIB/HEALPix 独立数值结果或 Fatduck 真实数据证据。它只冻结了执行顺序、接口、
验证方法和失败门禁；这些证据由前台按 ledger 派发后收回，并在当前 main SHA 上重新
验证。ACR 保持 dormant/off，不得为了通过本轮 Alpha 验证接入 ACR。
