# Runtime、调度、异步混合与运行图标准

## 1. 职责边界

```text
CLI → phase-specific config compiler → typed DAG
    → Scheduler → shared CPU executor / bounded I/O executor
    → module C ABI → CPU provider
```

CLI 不实现科学算法；module 不调度全局 Phase；I/O 不决定科学顺序；provider 不拥有 pipeline。Runtime 是唯一取消、错误、checkpoint、Artifact、线程预算、日志和 trace 服务入口。

## 2. 线程模型

- coordinator 一个控制线程；
- shared CPU executor 由运行时有效资源/用户上限/profile 决定；
- bounded I/O queue 允许短 I/O 与计算重叠，但有界并可观测；
- module 通过 lease/parallel_for 领取工作；
- 禁止 module 自建永久 pool、直接 `hardware_concurrency()` 决策、绕过 budget 的 `std::async`/OpenMP；
- OpenMP 若保留，host 在每次 lease 内设置线程，禁止 nested，不能给模块独立固定环境变量；
- writer 可串行，但必须处于 `io_write` 类，不能把整个 heavy kernel 放进串行 writer。

## 3. Scheduler 语义

1. compiler 校验 graph；
2. scheduler 只在前置 artifact complete 后提交 node；
3. node acquire lease；
4. module execute 只访问 typed handles；
5. output 经过 Store validate/publish；
6. release lease；
7. trace 记录完成/失败/cancel；
8. 下游只接收已发布 hash/schema 匹配 artifact。

重节点计划并行度为 1 时，只有 `tiny_work` 或明确 `serial_reason` 才可继续；否则 plan FAIL，不等运行后才发现单线程。

## 4. Plan/Trace 字段

计划必须记录 work units、parallel axes、min/max workers、memory read/write estimates、kernel IDs、serial sections、provider candidates。实际 trace 必须记录 granted/peak/active workers、CPU time、wall time、provider/kernel、queue/lock/io wait、RSS、bytes、input/output hash、调用次数。配置值和预计值另字段，不能覆盖观测值。

## 5. 运行图

计划图来自 DSL；真实图来自 trace。每次生成 DOT/SVG/JSON，使用颜色区分 `cpu_heavy/io/metadata/blocked/failed`；节点标签含 module ID、entry、DLL hash、workers、provider、耗时、artifact。图必须可从当前提交重新生成，不得手改作证。

## 6. 取消、失败和恢复

cancel token 可被 CLI/GUI 进程协议触发；模块在 chunk/block 边界和长 kernel 内检查；所有 lease RAII 回收；Store 临时对象不完成；resume 只认同 product/schema/config/input hash 的已发布 artifact；不同 Phase 的 run/checkpoint 不互认。
