# AstroCS Alpha 模块化重构控制包：先读我

控制包 ID：`ASTROCS-ALPHA3-MODULAR-REFOUNDATION-V7`  
发布日期：`2026-09-02`  
冻结起始提交：`c1696156583c68c9a3a65287639c726937e9f6e7`  
冻结起始版本：`0.10.0-alpha.2`  
目标版本：`0.11.0-alpha.1`  
正式分支：`main`  
正式平台：Windows x64；Linux x64 为控制/轻验证平台  
状态：可执行控制包；任何历史 V4/V5/V6/V18/V19 控制文件均不得覆盖本包。

## 1. 本轮唯一目标

把当前能够工作的但架构、文档和执行真实性仍不可靠的 AstroCS，收敛为可预发布的纯 CPU 模块化产品，同时保持既有科学定义不因架构迁移而漂移。

必须同时实现：

1. Phase1、Phase2、Phase3 分别运行、分别配置、分别验收；不得在同一进程自动串联。
2. Windows 发布物只有一个用户入口 `astrocs.exe`，科学模块、Runtime、I/O、CPU provider 以 DLL 交付。
3. 每个 DAG 节点绑定一个真实模块操作，不得以多个节点重复包装同一个 Session。
4. 一个共享执行器和一个真实 ThreadBudget 管理所有重计算；重计算不得单线程或长期低利用率。
5. ACR 保留但不进入当前生产构建、加载、benchmark 或发布包。
6. baseline/AVX2/FMA/AVX-512 仅在热点 kernel 上提供，按硬件安全检查、正确性自测和逐 kernel benchmark 选择；无 profile 一律 baseline。
7. SCI → ALG → DATA/API/ARCH → 源码符号/module manifest → TEST → 当前提交证据全链闭合。
8. 每个模块有独立源码、README、manifest 和可复用 unit/property/oracle/negative/performance 测试。
9. Phase3 独立完成 TAN、SIN、ZEA、CAR、AIT，以及 `nearest`、`healpix_interp4`，使用流式 FITS 输出。
10. 最终在 Windows 进行一次候选提交的真实数据/32R/接缝/资源验证，不反复跑历史全版本。

## 2. 执行者第一小时必须完成

前台 Agent `FG-000` 依次执行，任何一步失败均不得把控制包称为有效：

1. 在仓库外建立本轮工作根：`ASTROCS_WORK_ROOT/{control,worktrees,returns,logs,reports,build,install,audit,tmp}`。
2. 复制本控制包到 `ASTROCS_WORK_ROOT/control/active/`，运行 `python validators/validate_control.py --root <控制包目录>`。
3. 保存输出；必须出现 `CONTROL_PASS`，否则仅允许修复传输损坏，不得开始开发。
4. 读取本文件、`01_OWNER_FROZEN_CONSTRAINTS.md`、`04_FOREGROUND_AGENT_RUNBOOK.md`、`05_FIXED_SUBAGENT_BINDINGS.yaml`、`SUBAGENT_DISPATCH_PLAN.md`、`06_TASK_GRAPH_AND_WAVES.md`、`07_CHECKPOINTS_AND_GATES.md`、`08_GIT_MAIN_ONLY_INTEGRATION.md`。
5. `git fetch origin --prune`，记录 `HEAD/main/origin/main`、remote、status、submodule；remote 输出必须脱敏。
6. 若三 SHA 均为冻结提交，继续；若 `origin/main` 仅含已知上一轮 Agent 的后续提交，执行 `BASELINE_ADVANCE` 流程并生成差异审计；任何未知/非快进/来源不明变化才是真阻断。
7. 不得清理用户工作树；dirty/untracked 全量登记。正式开发在 detached worktree 中进行，正式集成只在主工作树 `main`。
8. 初始化 `TASK_LEDGER.csv` 的运行副本，派发 `AUD-001` 只读初审，同时派发互不冲突的 W0 任务。
9. W0 通过后自动进入下一 Gate，不等待项目负责人回复。

## 3. 权限模型

### 前台 Agent 可以

- 建任务、锁、detached worktree 和派发包；
- 把无冲突任务并行交给固定 SubAgent；
- 验证返回补丁；
- 在 `main` 串行应用、复跑验收、原子 commit、push；
- 退回失败任务；
- 汇总证据、构建源码基线和审核包。

### 前台 Agent 不可以

- 自己实现大段模块代码；
- 让 SubAgent 直接 commit/push；
- 为通过测试而放宽科学容差、资源阈值或范围；
- 用一个大 commit 合并多个任务；
- 创建常规功能分支；
- 用历史 PASS、旧 Windows 二进制或文档陈述替代当前提交证据；
- 每过一个 Gate 就停下来向负责人索要批准。

### SubAgent 可以

- 只在派发的 detached worktree 和允许路径内修改；
- 运行任务规定的局部检查；
- 返回 patch、结构化结果和原始日志。

### SubAgent 不可以

- commit、push、merge、rebase；
- 修改控制包、任务总账、其他 owner 路径；
- 扩展需求、重写科学公式或自行改变容差；
- 将失败/缺证据/未运行标记为 PASS。

## 4. 状态与不停工规则

任务状态唯一固定为：

`NOT_STARTED → READY → DISPATCHED → RETURNED → INTEGRATED → CLOSED`

异常状态为 `FAIL`、`BLOCKED`、`WAITING_RESOURCE`、`REBASE_REQUIRED`、`SUPERSEDED`。失败任务回到 `RETURNED` 后重新派发；不得创建 `IMPLEMENTED`、`VERIFYING`、`ACCEPTED`、`PUSHED`、`REWORK_*` 或 `BLOCKED_CANDIDATE` 等第二套状态。SubAgent 不能写主线提交，`INTEGRATED/CLOSED` 只能由前台在 main 验收后写入。

以下不是停工理由：普通编译失败、测试失败、缺 Ninja、Windows 暂时离线、Linux 资源不足、旧文档很多、一个 SubAgent 失败。只有仓库身份不明、权限/凭据/必需数据缺失、科学定义互相冲突、破坏性操作、不可安全快进、或最终 Windows 必需证据客观无法取得，才可请求负责人决定。

## 5. 验收结论词义

- `PASS`：规定动作在当前提交现场执行，证据完整且阈值通过。
- `FAIL`：已执行但不符合要求。
- `NOT_RUN`：未执行；永远不能计入 PASS。
- `WAITING_RESOURCE`：依赖暂时离线，其他任务继续。
- `INCONCLUSIVE`：证据不足或工具崩溃；不得通过 Gate。
- `NOT_APPLICABLE`：必须给出冻结约束和源码事实证明，不能自行宣称。

## 6. 交付

完成后返回：

1. 白名单审核包；
2. 审核包 SHA-256；
3. `origin/main` 最终 SHA；
4. 独立审计报告原件；
5. Windows 发布候选路径和独立哈希清单；
6. 顶层 `CHANGE_REVIEW.md`；
7. 未通过项，不得隐藏。

最终发布裁定只由项目负责人和下一轮外部审核作出。执行 Agent 最多写 `READY_FOR_OWNER_REVIEW`。
