# Windows x64 工具链冻结（Alpha 0.11.0）

本文件是 Fatduck 的唯一编译依据。Agent 不得用“已安装最新版”代替冻结版本，也不得在构建失败时自行切换 VS、SDK、generator、CRT 或 CMake。

## 1. 支持范围

| 用途 | 冻结值 |
|---|---|
| 目标架构 | AMD64/x86-64；不构建 Win32/ARM/ARM64 |
| 技术兼容下限 | Windows 10 22H2 x64，OS build 19045 |
| 完整主验证 | Windows 11 x64 |
| Windows 10 生命周期 | 微软免费支持已于 2025-10-14 结束；这是 AstroCS 技术兼容承诺，不是 OS 安全支持承诺 |
| Visual Studio | VS 2022 Build Tools `17.14.39` |
| VS installationVersion/build | `17.14.37614.0` |
| platform toolset | `v143` |
| VCToolsVersion | `14.44.35207`；compiler family `19.44` |
| Windows SDK headers/libs | `10.0.26100.0` |
| SDK servicing bundle | `10.0.26100.9169`（安装包版本；CMake target 仍为 10.0.26100.0） |
| CMake | `3.31.12` x64；本轮不使用 CMake 4.x |
| 正式 CMake generator | `Visual Studio 17 2022`, architecture `x64`, host tool `x64` |
| C++ 标准 | C++17；本轮不顺手升级到 C++20 |
| CRT | Debug `/MDd`；Release/RelWithDebInfo `/MD`；全 EXE/DLL/第三方一致 |
| 项目浮点 | `/fp:precise`；science oracle `/fp:strict` |
| 优化 | `/O2`；Alpha 禁 `/GL`、LTCG、PGO、`/fp:fast` |
| 静态检查 | LLVM/clang-tidy `19.1.5`，仅辅助检查，不生成发布二进制 |
| 验证脚本 | Python `3.12.10` x64，仅测试/打包，不是产品运行依赖 |

## 2. 固定获取源与哈希

### 2.1 VS Build Tools 17.14.39

固定 bootstrapper：

```text
https://download.visualstudio.microsoft.com/download/pr/fa619120-9c0e-47e6-bfe0-3ee96fb671b2/236367b68ba9a51708263ab10a1c85546cc4a8eca78b365168811d19c4fb2f29/vs_BuildTools.exe
SHA-256: 236367b68ba9a51708263ab10a1c85546cc4a8eca78b365168811d19c4fb2f29
size: 4473936 bytes
```

安装位置建议短路径：`C:\AstroCS\toolchains\vs2022-17.14.39`。安装返回码 `0` 或 `3010` 才算成功；`3010` 必须重启后再编译。若固定 URL 在现场被替换，先核对 SHA，不能下载 evergreen `aka.ms/vs/...` 作为本轮证据。

### 2.2 Windows SDK

安装引导器：

```text
https://download.microsoft.com/download/4c09a46e-b908-42d9-bf27-26cb1779c670/KIT_BUNDLE_WINDOWSSDK_MEDIACREATION/winsdksetup.exe
SHA-256: 680aa29dcfa806d35b4e93ea05a3fa2bdcf2935b65295f996c8e944584dd2836
```

CMake 必须显式写 `CMAKE_SYSTEM_VERSION=10.0.26100.0`；SDK servicing 更新不能偷偷改目标版本。`WindowsSDKVersion`、`WindowsSdkDir` 和 `cl /Bv` 必须进入 `toolchain_manifest.json`。

### 2.3 CMake/LLVM/Python

```text
CMake: https://github.com/Kitware/CMake/releases/download/v3.31.12/cmake-3.31.12-windows-x86_64.zip
LLVM: 19.1.5，来源为官方 LLVM release
Python: 3.12.10 x64，来源为官方 python.org release
```

本包不把未由官方主源现场核验的 CMake/LLVM/Python 安装器 hash 写成冻结事实。安装时必须从官方 release checksum/signature 页面下载，保存 URL、文件大小、SHA-256、签名结果和验证命令到 toolchain_manifest.json；任一字段缺失为 FAIL。不得调用 VS 内置 CMake 代替固定 CMake，除非 cmake --version 精确匹配。

## 3. 安装锁记录

现场使用根目录 toolchain.lock.json 记录版本、官方 URL、checksum 来源、下载 hash、签名/证书结果和安装返回码。字段 hash_status=OFFICIAL_VERIFIED 或 RECORDED_AT_INSTALL；后者不得在包内冒充预冻结 hash。

## 4. 固定组件

`.vsconfig` 只允许下列组件（组件 ID 来源于微软 Build Tools component list）：

```json
{
  "version": "1.0",
  "components": [
    "Microsoft.VisualStudio.Workload.VCTools",
    "Microsoft.VisualStudio.Component.VC.14.44.17.14.x86.x64",
    "Microsoft.VisualStudio.Component.Windows11SDK.26100",
    "Microsoft.VisualStudio.Component.VC.ASAN",
    "Microsoft.VisualStudio.Component.TestTools.BuildTools",
    "Microsoft.VisualStudio.Component.VC.Llvm.Clang",
    "Microsoft.VisualStudio.Component.VC.Llvm.ClangToolset"
  ]
}
```

不得添加 MFC/ATL/C++CLI/UWP/WinUI/Windows App SDK/ARM/ARM64/VS2026/v144/v145。`--includeRecommended` 禁止，因为它会把未审查组件带入环境。可安装 Windows Universal CRT SDK，但需记录并保持 target SDK 不变。

安装命令由固定脚本执行，Agent 不临时拼接组件：

```powershell
Start-Process .\vs_BuildTools_17.14.39.exe -ArgumentList @(
  '--quiet','--wait','--norestart','--nocache',
  '--installPath','C:\AstroCS\toolchains\vs2022-17.14.39',
  '--add','Microsoft.VisualStudio.Workload.VCTools',
  '--add','Microsoft.VisualStudio.Component.VC.14.44.17.14.x86.x64',
  '--add','Microsoft.VisualStudio.Component.Windows11SDK.26100',
  '--add','Microsoft.VisualStudio.Component.VC.ASAN',
  '--add','Microsoft.VisualStudio.Component.TestTools.BuildTools',
  '--add','Microsoft.VisualStudio.Component.VC.Llvm.Clang',
  '--add','Microsoft.VisualStudio.Component.VC.Llvm.ClangToolset',
  '--addProductLang','en-US'
) -Wait -PassThru
```

若已有 VS 2022，只有同时满足 installationVersion、VCToolsVersion、SDK 和 CMake 版本才可复用；否则安装隔离实例或记 WAITING，不在旧环境上“先试试”。

## 5. 唯一配置/构建命令

使用 `vcvarsall.bat` 或 `VsDevCmd.bat` 先设置环境，再执行固定 CMake：

```powershell
cmake.exe -S C:\ws\astrocs -B C:\ws\astrocs-build\win-msvc-17.14.39-x64 `
  -G "Visual Studio 17 2022" -A x64 `
  -T "v143,host=x64,version=14.44.35207" `
  -D CMAKE_GENERATOR_INSTANCE="C:/AstroCS/toolchains/vs2022-17.14.39" `
  -D CMAKE_SYSTEM_VERSION="10.0.26100.0" `
  -D CMAKE_BUILD_TYPE= `
  -D ASTROCS_ENABLE_ACR=OFF

cmake.exe --build C:\ws\astrocs-build\win-msvc-17.14.39-x64 `
  --config RelWithDebInfo --parallel
cmake.exe --install C:\ws\astrocs-build\win-msvc-17.14.39-x64 `
  --config RelWithDebInfo --prefix C:\ws\astrocs-install\win-x64
```

`--parallel` 不写固定数字；MSBuild/CMake 由 executor/job/resource profile 管理。修改 generator/toolset/SDK/CRT/ABI 时必须删除（或移出）旧 build tree 并新建隔离目录，不能复用缓存。

## 6. 编译开关

自有 C/C++：

```text
/std:c++17 /W4 /WX /permissive- /Zc:__cplusplus /Zc:preprocessor
/utf-8 /EHsc /fp:precise /O2 /INCREMENTAL:NO
```

Debug：`/MDd /Zi`；RelWithDebInfo：`/MD /Zi`；Release：`/MD`。science oracle target 使用 `/fp:strict`，且不能把 oracle 代码链接进生产 DLL。第三方依赖不强制 `/WX`，但不得掩盖自有代码警告。

禁止全局：`/arch:AVX2`、`/arch:AVX512`、`/fp:fast`、`/GL`、`/LTCG`、PGO、无预算 `/openmp`。只有 CPU provider target 可以分别使用 `/arch:AVX2` 或 `/arch:AVX512`。

## 7. Windows 10 兼容

所有目标统一定义：

```text
WINVER=0x0A00
_WIN32_WINNT=0x0A00
UNICODE _UNICODE NOMINMAX WIN32_LEAN_AND_MEAN
```

这只定义 API 编译下限，不自动证明 Win10 22H2。必须：

1. `dumpbin /imports` 和 `/dependents` 扫描 EXE/DLL；
2. 禁止静态导入仅 Win11 API；若必须使用，用 `GetProcAddress` + Win10 fallback；
3. 在真实 Win10 22H2 x64 或授权 VM 运行 version/doctor/selftest/三 Phase 最小合成/安全 DLL load；无现场证据记 `WAITING_PLATFORM`；
4. Windows 11 做完整 heavy/32R/HiPS 验收。

## 8. CRT/DLL/加载器陷阱

```cmake
cmake_policy(SET CMP0091 NEW)
set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>DLL")
```

所有 EXE/DLL/第三方必须同 `/MD`/`/MDd`；禁止 `/MT` 混用和跨 DLL 释放。发布目录不得含 `VCRUNTIME140D.dll`、`ucrtbased.dll`。VC Redistributable 至少不低于构建工具版本，并在外部发布清单记录。C ABI 不传 STL/异常/RTTI，导出入口捕获 C++ exception 并返回 status。

使用 `SetDefaultDllDirectories`、`AddDllDirectory`、`LoadLibraryExW` 的安全 flags；绝对路径来自 manifest，不能从当前目录/PATH/SearchPath 自动发现 DLL。provider 检测 CPUID/XGETBV 后才加载，DLL 静态初始化不能执行 SIMD。

## 9. 机器验收命令

```powershell
vswhere.exe -all -products * -format json
cl /Bv
link /? | Select-Object -First 2
rc /?
cmake --version
clang --version
clang-tidy --version
python --version
dumpbin /headers astrocs.exe
dumpbin /exports modules\*.dll
dumpbin /dependents astrocs.exe
dumpbin /dependents modules\*.dll
```

`toolchain_manifest.json` 必须包含 OS build、x64、installationPath/version/channel、VCToolsVersion、`cl /Bv`、link/rc、SDK、CMake/LLVM/Python、各安装器 SHA、CMake preset 和环境变量摘要。任何字段缺失均不算工具链 PASS。

## 10. 官方依据

- Visual Studio Release History：<https://learn.microsoft.com/en-us/visualstudio/releases/2022/release-history>
- VS 2022 servicing：<https://learn.microsoft.com/en-us/visualstudio/releases/2022/servicing-vs2022>
- Build Tools component IDs：<https://learn.microsoft.com/en-us/visualstudio/install/workload-component-id-vs-build-tools?view=visualstudio>
- CMake VS17 generator：<https://cmake.org/cmake/help/v3.31/generator/Visual%20Studio%2017%202022.html>
- CMake presets：<https://cmake.org/cmake/help/v3.31/manual/cmake-presets.7.html>
- MSVC `/arch`：<https://learn.microsoft.com/en-us/cpp/build/reference/arch-x64?view=msvc-170>
- MSVC CRT：<https://learn.microsoft.com/en-us/cpp/build/reference/md-mt-ld-use-run-time-library?view=msvc-170>
- VC Redistributable：<https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist?view=msvc-170>
- Secure DLL loading：<https://learn.microsoft.com/en-us/windows/win32/api/libloaderapi/nf-libloaderapi-loadlibraryexa>
- Windows 10 lifecycle：<https://learn.microsoft.com/en-us/lifecycle/announcements/windows-10-22h2-end-of-support-update>

## 11. 不允许的替换

以下任何替换必须新开工具链变更 task，不能在本轮自行改：VS 2026/v144/v145、17.14 evergreen latest、CMake 4.x、Ninja 作为 Windows 正式 generator、MinGW/MSYS2、`/MT`、`/fp:fast`、全局 `/arch:AVX*`、固定 `-j16`/`/m:16`、Windows 11-only API、开发机 PATH 中未知 DLL。
