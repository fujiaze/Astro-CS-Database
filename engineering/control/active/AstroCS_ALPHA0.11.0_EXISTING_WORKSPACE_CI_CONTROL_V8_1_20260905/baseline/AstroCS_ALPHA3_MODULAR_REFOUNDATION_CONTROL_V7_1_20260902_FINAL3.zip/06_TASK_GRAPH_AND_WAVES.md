# 任务图、并行波次与自动推进

## 1. 权威文件

- `TASK_LEDGER.csv`：全部 task、owner、依赖、资源级别、commit 与 spec 索引；运行时只能在仓库外复制后更新状态。
- `05_FIXED_SUBAGENT_BINDINGS.yaml`：固定 owner 与允许路径。
- `tasks/00_TASK_EXECUTION_CONTRACT.md`：每个任务共同执行协议。
- `tasks/MODULE_MIGRATION_MATRIX.csv`：每个 DLL 的旧路径、目标、固定 owner 与科学专项验收。
- `tasks/*.md`：任务级动作、输出和判据。
- `07_CHECKPOINTS_AND_GATES.md`：机器 Gate；不是人工停工点。

## 2. 调度规则

1. 仅当所有依赖 `CLOSED`、互斥锁可得、owner 空闲时，task 才可由 `NOT_STARTED` 变 `READY`。
2. 同一 owner 一次只执行一个写任务；`SA-AUD-99` 可以与开发并行但始终只读。
3. 同一 lock 一次只授予一个 task。
4. `WINDOWS_HEAVY` 只在 Fatduck 在线且源码 SHA 冻结时执行；离线为 `WAITING_RESOURCE`，不阻塞无关任务。
5. `LINUX_LIGHT` 在 2c2g 控制节点一次只运行一个编译/计算任务；文档静态读取任务可并行。
6. SubAgent 不直接依赖另一 SubAgent 工作树；只依赖前台已集成并 push 的 main commit。
7. 一个 wave 内的并行表示“可同时派发”，不表示可同时写 main；main 集成永远串行。
8. Gate 失败只退回相关 owner；无依赖关系的 task 继续。

## 3. 波次

### W0 事实冻结

校验控制包、仓库和主机；建立 detached worktree/锁；独立审计当前已知问题；把冻结约束、版本源和文档归档规则正式纳入 main。自动 Gate `G0`。

### W1 合同冻结

冻结 C ABI、Artifact/Phase 产品、DAG/线程/日志/CPU profile 合同；每个科学模块先完成 `*-DOC`，但不改公式。并行 owner 可同时起草，前台按依赖和锁串行集成。自动 Gate `G1`。

### W2 宿主基础设施

建立唯一根 CMake、固定 MSVC preset、安装树、安全 loader/registry、typed ArtifactStore、共享 executor、真实 ThreadBudget、日志/监控/运行图、baseline provider、ISA 探测/benchmark、独立 CLI 命令。此时先以 `noop/echo` 测试模块证明骨架；不迁移科学算法。自动 Gate `G2`。

### W3 科学模块迁移

对 `MODULE_MIGRATION_MATRIX.csv` 每个模块依次执行：

`DOC（已在 W1） → TEST → IMPL → INT`

每模块 TEST 必须先于 IMPL；IMPL 只做适配和迁移，不改科学；INT 才注册并接入对应 Phase DAG。Phase1/2/3 各 owner 可并行开发，但按数据依赖逐个接入。自动 Gate `G3`。

### W4 删除伪/旧路由

只有替代项已通过才删除：重复 Session adapter、静态 factory、第二套 CLI CMake、进程内多 Phase、假 Artifact 字符串、伪 worker/provider trace、旧 standalone phase2。每个删除单独 commit，并证明无调用者。自动 Gate `G4`。

### W5 Linux 控制节点验证

完成全量结构/文档/符号/ABI/schema/轻量构建、模块合成测试、sanitizer 小样本、静态图/实际 trace 和资源监控冒烟。禁止在 2c2g 反复跑 32R。自动 Gate `G5`。

### W6 Windows 正式平台验证

在 Fatduck 对同一 `origin/main` 执行固定 MSVC clean build、DLL 负面加载、全模块合成 oracle、benchmark/provider、heavy 资源门禁、Win10 兼容烟测、Win11 完整验证、少量真实帧、一次 32R、接缝和 HiPS 预览。自动 Gate `G6`。

### W7 文档与质量收敛

重建 L0/L1/L2/L3、AST API、Doxygen/Graphviz/CMake target 图、Phase 静态/运行图、注释审查、依赖/SBOM、旧版本扫描、全追溯矩阵。自动 Gate `G7`。

### W8 独立终审与打包

独立 auditor 在最终同一 SHA 全面复审；P0/P1 清零后才生成 release candidate manifest 和最终白名单审核包。源码或二进制变化后旧终审失效。Gate `G8` 只产生 `READY_FOR_OWNER_REVIEW`，不替负责人发布。

## 4. 关键依赖链

```text
G0 → C ABI/Data/Runtime/CPU contracts → G1
G1 → host skeleton + noop DLL + shared executor → G2
G2 → per-module TEST → IMPL → INT → G3
G3 → legacy removal → G4
G4 → Linux validation → G5
G5 + Windows online → Windows qualification → G6
G6 → final docs/traceability → G7
G7 → independent final review → package → G8
```

Phase3 的科学合同和 oracle 可与宿主基础设施并行准备，但 Phase3 DLL 接入必须等待 G2。Windows 离线期间 W7 中不依赖 Windows 原始证据的工作可提前执行；其最终状态在 G6 后重算。

## 5. 主 Agent 不得自行改变的排序

1. ABI 合同先于 loader 实现。
2. Artifact/Data 合同先于生产 ArtifactStore 接线。
3. ThreadBudget/共享 executor 合同先于任何模块并行迁移。
4. 模块 TEST 先于 IMPL，IMPL 先于 INT。
5. 新节点接管并验证先于旧 Session/factory 删除。
6. baseline provider 先于 AVX2/AVX-512。
7. provider 正确性 self-test 先于 benchmark，benchmark 先于生产选择。
8. Phase3 projection/WCS 先于 resampling 集成，resampling 先于 FITS writer 集成。
9. 最终 push 先于源码快照，源码快照先于独立终审/审核包签封。

## 6. 并发示例（不是核心数硬编码）

当前系统最多能同时运行多少 SubAgent 由 Agent 平台决定；任务图不硬编码并发数。一个合法派发批次示例：

- `SA-GOV-01`：活动文档清点；
- `SA-ABI-03`：C ABI 合同；
- `SA-DATA-06`：Artifact 合同；
- `SA-RT-05`：DAG/资源合同；
- `SA-P3-P25`：Phase3 投影合同；
- `SA-AUD-99`：只读基线复核。

它们在不同 detached worktree 工作；前台按照 lock 和 base SHA 一个个集成到 main。集成一个任务后，仍在旧 base 上工作的任务必须由原 owner 重放，不能由前台手工合并。
