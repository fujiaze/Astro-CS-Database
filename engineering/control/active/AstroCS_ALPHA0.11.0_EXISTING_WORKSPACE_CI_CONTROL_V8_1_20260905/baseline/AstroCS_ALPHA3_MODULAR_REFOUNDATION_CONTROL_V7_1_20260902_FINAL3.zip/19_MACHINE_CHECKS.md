# 机器化一致性检查清单

所有脚本使用 Python 3.10+ 标准库即可运行；脚本必须在异常时给出非零退出码，禁止吞异常后输出 PASS。入口位于 `validators/`，不要依赖当前目录、网络或用户本机路径。

## 必须实现的检查

| 脚本 | 检查 | 通过条件 |
|---|---|---|
| `validate_control.py` | 控制包文件、命名、hash、路径、禁带物 | `CONTROL_PASS` |
| `validate_tasks.py` | ledger 唯一 ID、owner、依赖、spec 引用、状态机 | `TASK_LEDGER_PASS` |
| `validate_docs.py` | active 文档版本/路径、必备章节、旧版本/绝对路径 | `DOCS_PASS` |
| `validate_module_contracts.py` | module.yaml/README/CMake/源/测试 ID | `MODULE_CONTRACT_PASS` |
| `validate_traceability.py` | SCI→ALG→DATA/API/ARCH→MOD→SRC→TEST→EVID | `TRACEABILITY_PASS` |
| `validate_abi_manifest.py` | C ABI schema、导出名、三方 manifest | `ABI_MANIFEST_PASS` |
| `validate_dag_phase.py` | phase 独立命令、无顺序依赖、节点唯一 | `PHASE_DAG_PASS` |
| `validate_thread_budget.py` | 无私有池/固定 workers/伪 trace，heavy 有并行计划 | `THREAD_BUDGET_PASS` |
| `validate_cpu_providers.py` | provider 能力/self-test/profile/fallback | `CPU_PROVIDER_PASS` |
| `validate_source_scope.py` | source allowlist/排除大文件/秘密/二进制 | `SOURCE_SCOPE_PASS` |
| `validate_audit_package.py` | 审核包结构、白名单、容量、嵌套包、SHA | `AUDIT_PACKAGE_PASS` |
| `validate_results.py` | evidence/finding/gate schema、主 SHA 和计数 | `RESULTS_PASS` |
| `selftest.py` | validator 缺文件/坏输入负测 | `VALIDATOR_SELFTEST_PASS` |

## 静态扫描最低规则

1. C/C++：扫描 `std::thread`、`std::async`、`hardware_concurrency`、`omp_set_num_threads`、线程池构造、`ThreadLease::make`、`p2_session_run`/`p3_session_run` 旧适配器；每一命中都要有 allowlist 说明，否则 P0/P1。
2. 构建：扫描第二个顶层 `project()`/CLI CMake、STATIC 生产 target、全局 `/arch`、`/fp:fast`、`/GL`、LTCG、固定 `-jN`。
3. 文档：扫描 `V[0-9]`、`R[0-9]`、`alpha` 旧版本、Windows 盘符、`/home/`、`F:/`、`HISS`、`--phases`、`Phase1.*Phase2.*Phase3` 连续执行措辞；命中必须是 archive 或历史索引。
4. ABI：扫描公共头中的 STL、异常、裸跨边界所有权、未标注 `struct_size`/`abi_version`。
5. 资源：读取 trace/monitor 原始序列；不能用配置中的 `workers` 代替 observed workers；不能只报告平均 CPU。

## 脚本质量要求

- 每个脚本提供 `--root`、`--json-out`、`--strict`、`--help`；输出稳定排序的 JSON。
- 运行前写 command/config digest，运行后写 exit code、输入 hash、版本。
- validator 自身必须有 unit/negative tests：缺文件、坏 JSON、重复 ID、循环依赖、伪 PASS、绝对路径和篡改 hash。
- 任何检查器 crash、导入失败或未处理异常都判 `TOOLING_FAILURE/P0`。
- 不允许用 grep 一个关键词作为科学等价证明；科学公式/单位/误差需要人工抽查 + 独立 oracle 证据。
