# DLL C ABI、注册、所有权与加载标准

## 1. 唯一导出入口

每个模块和 provider 只导出批准的查询入口（名称可在 ABI v1 中固定）：

```c
ASTROCS_EXPORT acs_status ASTROCS_CALL
astrocs_module_query_v1(uint32_t host_abi,
                        const acs_host_api_v1* host,
                        const acs_module_api_v1** out_api);
```

结构体第一字段是 `struct_size`，第二字段是 `abi_version`；后续只能追加尾字段。所有跨边界类型为固定宽度整数、POD、长度明确的 UTF-8 span、opaque handle、callback；禁止 STL、模板、引用、RTTI、C++ exception、裸所有权指针。

## 2. API 生命周期

```text
query → describe → validate_config → plan → create
      → execute* → inspect → request_cancel(optional)
      → destroy
```

`execute` 可重复调用的条件、线程安全、返回状态、错误诊断、output sink 提交和 cancel 行为必须在 API 文档和测试中固定。Host 调用 destroy 后 module 不得访问 host 对象。

## 3. Host services

Host 提供 allocator/free、日志、metrics、cancel、progress、Artifact reader/writer、checkpoint、shared executor/ThreadLease、config query。模块不能自行打开任意路径、创建无界线程池、写 stdout、吞异常或释放 host 内存。

## 4. ABI/CRT/文本

- host allocator 分配的内存由 host allocator 释放；module 私有对象用 opaque handle 和 module destroy；
- 全部 EXE/DLL/第三方使用 `/MD` 或 `/MDd` 一致；不跨 CRT heap 释放；
- DLL 边界捕获全部异常并返回稳定 `acs_status`；
- 文本公共格式 UTF-8；Windows 内部路径 UTF-16；
- module version、ABI version、data schema version、product version 分开；
- `describe_json` 只能描述，不替代结构化 query 字段。

## 5. Manifest 三方校验

构建期 `module.yaml`、DLL 内 query descriptor、发布 `astrocs.product.json` 必须在 module ID、DLL name、ABI、version、phase、ports、source/test IDs、hash 上一致。任何不一致构建/安装验证失败。

## 6. 安全加载

Windows 先调用 `SetDefaultDllDirectories`；插件目录由 product manifest 显式授权，通过 `AddDllDirectory`；`LoadLibraryExW` 使用 `LOAD_LIBRARY_SEARCH_DLL_LOAD_DIR | LOAD_LIBRARY_SEARCH_APPLICATION_DIR | LOAD_LIBRARY_SEARCH_SYSTEM32`，参数是 canonical absolute path。禁止当前目录/PATH/SearchPath/用户数据目录发现 DLL。加载前后检查 PE x64、SHA、module/ABI/build；失败写诊断但不执行 fallback 静态算法。

Linux `.so` 仅技术预览，同样只认 manifest absolute path 和 SHA；禁止用 `LD_LIBRARY_PATH` 作为正式发现语义。

## 7. Provider 特殊规则

provider DLL 不执行昂贵全局初始化，不在 `DllMain` 使用 SIMD；先 CPUID/XGETBV 再 LoadLibrary；加载后 self-test，通过后才可加入路由；不适配的 kernel 返回 unsupported 让 host 退 baseline，不复制整套科学 Session。
