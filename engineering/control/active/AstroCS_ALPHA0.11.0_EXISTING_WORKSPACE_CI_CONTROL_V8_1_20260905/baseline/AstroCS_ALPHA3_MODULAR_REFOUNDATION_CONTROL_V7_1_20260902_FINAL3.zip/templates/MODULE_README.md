# `<module_id>`

| 字段 | 当前值 |
|---|---|
| MOD ID / DLL | `MOD-*` / `astrocs_*.dll` |
| module / ABI / doc revision | `0.11.0-alpha.1` / `1` / `<rev>` |
| owner / phase | `SA-*` / `phase1|phase2|phase3|service` |
| 文档状态 | `DRAFT|CONTRACT_READY|BLOCKED` |

## 负责范围

负责：<单一模块操作>。不负责：<明确列出上下游和不得拥有的 Session/调度行为>。

## 输入与输出

列出每个 port 的 DATA ID、单位、坐标/frame/epoch、dtype、shape、mask/invalid/NaN/Inf 和所有权。

## 合同链接

- SCI：`SCI-*`
- ALG：`ALG-*`
- DATA：`DATA-*`
- API：`API-*`
- ARCH：`ARCH-*`
- TEST：`TEST-*`

## 实现事实

public entry：`astrocs_module_query_v1`；主要 source symbols：<从 AST 生成，禁止手抄>。配置 schema、错误码、plan/execute/inspect/cancel 语义：<链接>。

## 并发与资源

threading model、parallel axis、ThreadBudget lease、min/max workers、memory read/write estimate、I/O queue、provider/fallback、determinism、checkpoint/cancel。

## 验证

unit、property、独立 oracle、negative、performance、integration 的 TEST ID、fixture seed、expected source、tolerance source、当前 evidence ID。没有 evidence 不得写 PASS。

## 构建与限制

固定 preset/CMake/CTest 命令；已知限制、未实现项、平台范围和最后验证 SHA。
