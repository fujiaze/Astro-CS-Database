# AstroCS Agent 入口

先读根 memory.md、相关模块 memory.md、AstroCS_ENGINEERING_CONSTRAINTS.md 和本轮控制包 00_READ_FIRST.md。

只在授权路径工作；任务、状态、证据、提交和打包均服从控制包及 schema。科学定义、算法、接口、代码、测试必须可追溯一致。长任务必须有超时和资源监控；禁止单线程重计算、放宽阈值、绕过共享调度器、提交大文件或修改无关路径。
