# Phase2 Sampler

关联：SCI-UPM-*；模块：lib/phase2/src/sampler.cpp。

## 输入

coverage union MOC + 帧 SNR catalogue。

## 输出

control cell 观测（value/uncertainty/snr/control_variance/
control_ivar/support/quality；ivar 仅诊断）。

## Preconditions

target_order 已定；cell 网格 8×8。

## Postconditions

- patch estimator：support>0 + finite 过滤，median 位置 + MAD 尺度；
- SNR 来自 catalogue 邻近星点（不重新检测）；snr_available=0 时不伪装 1.0。

## V19R3 control estimator 方差（ALG-UPM-CONTROL-IVAR-001 /
DATA-UPM-CONTROL-UNC-001）

```text
control_variance = control_k_corr × (π/2) × sigma_bg² / N_retained
control_ivar     = 1 / control_variance
uncertainty      = sqrt(control_variance)   # SE(patch median)
```

- N_retained = clipping 后保留样本（不是 n_total）；
- sigma_bg = MAD 尺度（clipping 收敛集）；
- control_k_corr 默认 1.4（UPMW-005 MC 校准：pixfrac=0.8 下实证
  1.3883，N_eff≈181<251）；显式配置覆盖，<=0 回退冻结默认；
  per-frame 覆盖 frames[frame_id].kcorr>0 ? per-frame : cfg.control_k_corr（sampler.cpp:672），缺省回退 1.4；
- obs.ivar 保留为单 leaf Phase1 ivar 诊断（V19R3 弃用，不进科学权重）。

## Invariants

保留负值；cell 无 obs 时标记几何节点（不进数据分量）。

## 复杂度

O(cells + catalogue log n)（dec 排序索引 + 帧 median 预计算）。

## 并行模型（V5 重验 2026-08-28）

默认串行为**确定性 reference**（Windows hotfix `0xC0000005` 回退历史, CMake 禁链接 OpenMP 为已知限制, 非 V5 硬编码）；`P2_ENABLE_OPENMP=ON` 实验并行保留——任何并行开启均按运行时 affinity 调度, **无硬编码线程数**；tile 级缓存与 progress 日志保留。串行→并行等价由 control 索引固定顺序保证（`critical(aio_read)` 串行化 IO）。

## 数值风险

MAD=0；patch 样本不足 → min_samples 拒绝。

## ID

ALG-P2SAMPLE-001..N；TEST-P2SAMPLE-*；UPMW-004/005/007（median SE /
Drizzle 相关 MC / patch estimator vs truth）。
