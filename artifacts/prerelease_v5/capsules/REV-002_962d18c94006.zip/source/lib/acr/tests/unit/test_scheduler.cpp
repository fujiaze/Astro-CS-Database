// lib/acr/tests/unit/test_scheduler.cpp — Phase F scheduler 单元测试
// 覆盖：
// - CoverageBitmap：mark_done / all_done / pending_indices
// - partition_range：不重叠 + 完整覆盖
// - partition_range_into：均分
// - partition_tiles：tile 覆盖完整
// - partition_tiles_into：max_chunks 限制
// - QueueAwareEstimator：finish 估算 + pick_best_device + should_prefer_cpu
// - ReductionMerger：局部合并 + finalize
// - FallbackPolicy：ToCpu / ToNextDevice / None
// - MixedRunner：coverage 完整不重复
// - Dispatcher：dispatch_range + pick_backend + handle_failure
#include <gtest/gtest.h>

#include "dispatcher.hpp"
#include "fallback.hpp"
#include "mixed_runner.hpp"
#include "partitioner.hpp"
#include "queue_aware.hpp"
#include "reduction_merger.hpp"
#include "shared_work_pool.hpp"

#include "../core/task_descriptor.hpp"
#include "../cost/cost_estimator.hpp"

#include <algorithm>
#include <atomic>
#include <mutex>
#include <numeric>
#include <set>
#include <stdexcept>
#include <string>
#include <thread>
#include <utility>
#include <vector>

#include "astro/compute/acr.hpp"

using namespace astro::compute::scheduler;
using astro::compute::DeviceId;
using astro::compute::kHwCpuDeviceId;

// ============================================================================
// CoverageBitmap
// ============================================================================

TEST(SchedulerCoverage, InitialAllPending) {
    CoverageBitmap bm(10);
    EXPECT_EQ(bm.chunk_count(), 10u);
    EXPECT_EQ(bm.done_count(), 0u);
    EXPECT_FALSE(bm.all_done());
    EXPECT_EQ(bm.pending_indices().size(), 10u);
}

TEST(SchedulerCoverage, MarkDoneIncrementsCount) {
    CoverageBitmap bm(10);
    bm.mark_done(2);
    EXPECT_EQ(bm.done_count(), 1u);
    EXPECT_TRUE(bm.is_done(2));
    EXPECT_FALSE(bm.is_done(3));
    bm.mark_done(2);  // 重复标记不增加
    EXPECT_EQ(bm.done_count(), 1u);
    bm.mark_done(5);
    EXPECT_EQ(bm.done_count(), 2u);
}

TEST(SchedulerCoverage, AllDoneAfterAllMarked) {
    CoverageBitmap bm(5);
    for (std::size_t i = 0; i < 5; ++i) bm.mark_done(i);
    EXPECT_TRUE(bm.all_done());
    EXPECT_TRUE(bm.pending_indices().empty());
}

TEST(SchedulerCoverage, PendingIndicesCorrect) {
    CoverageBitmap bm(8);
    bm.mark_done(1);
    bm.mark_done(4);
    auto pending = bm.pending_indices();
    std::vector<std::size_t> expected = {0, 2, 3, 5, 6, 7};
    EXPECT_EQ(pending, expected);
}

TEST(SchedulerCoverage, OutOfRangeSafe) {
    CoverageBitmap bm(4);
    EXPECT_FALSE(bm.is_done(100));
    bm.mark_done(100);  // 不崩溃
    EXPECT_EQ(bm.done_count(), 0u);
}

// ============================================================================
// partition_range
// ============================================================================

TEST(SchedulerPartition, RangeNoOverlapComplete) {
    auto chunks = partition_range(0, 100, 30);
    EXPECT_EQ(chunks.size(), 4u);
    // 不重叠
    for (std::size_t i = 1; i < chunks.size(); ++i) {
        EXPECT_EQ(chunks[i].begin, chunks[i-1].end);
    }
    // 完整覆盖
    EXPECT_EQ(chunks.front().begin, 0u);
    EXPECT_EQ(chunks.back().end, 100u);
    // 索引顺序
    for (std::size_t i = 0; i < chunks.size(); ++i) {
        EXPECT_EQ(chunks[i].index, i);
    }
}

TEST(SchedulerPartition, RangeLastChunkClamped) {
    auto chunks = partition_range(0, 100, 30);
    EXPECT_EQ(chunks.back().begin, 90u);
    EXPECT_EQ(chunks.back().end, 100u);  // 10 个元素，不是 30
}

TEST(SchedulerPartition, RangeIntoEvenSplit) {
    auto chunks = partition_range_into(0, 100, 4);
    EXPECT_EQ(chunks.size(), 4u);
    for (std::size_t i = 1; i < chunks.size(); ++i) {
        EXPECT_EQ(chunks[i].begin, chunks[i-1].end);
    }
    EXPECT_EQ(chunks.front().begin, 0u);
    EXPECT_EQ(chunks.back().end, 100u);
    // 每个 25
    for (const auto& c : chunks) {
        EXPECT_EQ(c.end - c.begin, 25u);
    }
}

TEST(SchedulerPartition, RangeIntoUnevenSplit) {
    auto chunks = partition_range_into(0, 100, 3);
    EXPECT_EQ(chunks.size(), 3u);
    EXPECT_EQ(chunks.front().begin, 0u);
    EXPECT_EQ(chunks.back().end, 100u);
    // 100 / 3 = 33 rem 1，前 1 个 34，后 2 个 33
    EXPECT_EQ(chunks[0].end - chunks[0].begin, 34u);
    EXPECT_EQ(chunks[1].end - chunks[1].begin, 33u);
    EXPECT_EQ(chunks[2].end - chunks[2].begin, 33u);
}

// ============================================================================
// partition_tiles
// ============================================================================

TEST(SchedulerPartition, TilesCoverAll) {
    auto tiles = partition_tiles(10, 10, 4, 4);
    // 3x3 = 9 tiles
    EXPECT_EQ(tiles.size(), 9u);
    std::vector<int> covered(100, 0);
    for (const auto& t : tiles) {
        for (std::size_t y = t.tile_y * 4; y < t.tile_y * 4 + t.tile_h; ++y) {
            for (std::size_t x = t.tile_x * 4; x < t.tile_x * 4 + t.tile_w; ++x) {
                ASSERT_LT(y * 10 + x, 100u);
                covered[y * 10 + x] = 1;
            }
        }
    }
    int total = std::accumulate(covered.begin(), covered.end(), 0);
    EXPECT_EQ(total, 100);
}

TEST(SchedulerPartition, TilesIntoMaxChunks) {
    auto tiles = partition_tiles_into(100, 100, 9);
    EXPECT_LE(tiles.size(), 9u);
    EXPECT_GE(tiles.size(), 1u);
}

TEST(SchedulerPartition, RangeEmpty) {
    auto chunks = partition_range(0, 0, 10);
    EXPECT_TRUE(chunks.empty());
    auto chunks2 = partition_range(10, 5, 10);
    EXPECT_TRUE(chunks2.empty());
}

TEST(SchedulerPartition, RangeZeroChunkSize) {
    auto chunks = partition_range(0, 100, 0);
    EXPECT_TRUE(chunks.empty());
}

// ============================================================================
// QueueAwareEstimator
// ============================================================================

TEST(SchedulerQueueAware, EstimateFinishCpuNoTransfer) {
    QueueAwareEstimator est;
    DeviceState cpu{"cpu", 0, 0, 50.0, true};
    TaskEstimate task{1024, 10, 1000.0, 100.0};
    std::uint64_t f = est.estimate_finish(cpu, task);
    // CPU 无传输：finish = 0 + 0 + 10000 + 1000 = 11000
    EXPECT_EQ(f, 11000u);
}

TEST(SchedulerQueueAware, EstimateFinishGpuWithTransfer) {
    QueueAwareEstimator est;
    DeviceState gpu{"cuda:0", 1000, 0, 10.0, true};  // 10 GB/s PCIe
    TaskEstimate task{1024 * 1024, 10, 1000.0, 100.0};  // 1MB per chunk
    std::uint64_t f = est.estimate_finish(gpu, task);
    // 传输 = 10MB / 10GB/s = 1ms = 1e6 ns
    // 计算 = 10000 ns，合并 = 1000 ns
    // 总 = 1000 + 1e6 + 10000 + 1000
    EXPECT_GT(f, 1000u);
    EXPECT_GE(f, 1000000u);
}

TEST(SchedulerQueueAware, PickBestDeviceSelectsLowerFinish) {
    QueueAwareEstimator est;
    std::vector<DeviceState> devs = {
        {"cpu", 0, 0, 50.0, true},
        {"cuda:0", 100000, 0, 10.0, true},  // 高 queue_load
    };
    TaskEstimate task{1024, 10, 1000.0, 100.0};
    std::string best = est.pick_best_device(devs, task);
    // CPU finish = 11000，GPU finish = 100000+传输+计算
    // CPU 应该更短
    EXPECT_EQ(best, "cpu");
}

TEST(SchedulerQueueAware, PickBestDeviceSkipsUnavailable) {
    QueueAwareEstimator est;
    std::vector<DeviceState> devs = {
        {"cpu", 0, 0, 50.0, false},  // 不可用
        {"cuda:0", 1000, 0, 10.0, true},
    };
    TaskEstimate task{1024, 10, 1000.0, 100.0};
    std::string best = est.pick_best_device(devs, task);
    EXPECT_EQ(best, "cuda:0");
}

TEST(SchedulerQueueAware, ShouldPreferCpuForSmallData) {
    QueueAwareEstimator est;
    DeviceState cpu{"cpu", 0, 0, 50.0, true};
    DeviceState gpu{"cuda:0", 0, 0, 1.0, true};  // 慢 PCIe
    // 小数据：bytes=1024, compute=1000000ns → 传输 < 计算*0.5
    TaskEstimate small{1024, 1, 1000000.0, 0.0};
    // 大数据：bytes=1e9, compute=1000ns → 传输 > 计算*0.5
    TaskEstimate large{1000000000ULL, 1, 1000.0, 0.0};
    EXPECT_FALSE(est.should_prefer_cpu(cpu, gpu, small));  // 小数据传输不主导
    EXPECT_TRUE(est.should_prefer_cpu(cpu, gpu, large));   // 大数据传输主导
}

// ============================================================================
// ReductionMerger
// ============================================================================

TEST(SchedulerMerger, InitAndFinalize) {
    ReductionMerger m;
    int identity = 0;
    auto merge = +[](void* dst, const void* src) {
        *static_cast<int*>(dst) += *static_cast<const int*>(src);
    };
    m.init(&identity, sizeof(int), merge);
    int a = 10, b = 20, c = 30;
    m.add_local(&a);
    m.add_local(&b);
    m.add_local(&c);
    EXPECT_EQ(m.local_count(), 3u);
    int result = 0;
    m.finalize(&result);
    EXPECT_EQ(result, 60);
}

TEST(SchedulerMerger, FinalizeWithNoLocalsReturnsIdentity) {
    ReductionMerger m;
    int identity = 42;
    auto merge = +[](void* dst, const void* src) {
        *static_cast<int*>(dst) += *static_cast<const int*>(src);
    };
    m.init(&identity, sizeof(int), merge);
    int result = -1;
    m.finalize(&result);
    EXPECT_EQ(result, 42);
}

TEST(SchedulerMerger, MultipleFinalizeStable) {
    ReductionMerger m;
    int identity = 0;
    auto merge = +[](void* dst, const void* src) {
        *static_cast<int*>(dst) += *static_cast<const int*>(src);
    };
    m.init(&identity, sizeof(int), merge);
    int a = 5, b = 7;
    m.add_local(&a);
    m.add_local(&b);
    int r1 = 0, r2 = 0;
    m.finalize(&r1);
    m.finalize(&r2);
    EXPECT_EQ(r1, 12);
    EXPECT_EQ(r2, 12);
}

// ============================================================================
// FallbackPolicy
// ============================================================================

TEST(SchedulerFallback, ToCpuStrategy) {
    FallbackPolicy p;
    p.set_strategy(FallbackStrategy::ToCpu);
    CoverageBitmap bm(10);
    bm.mark_done(0);
    bm.mark_done(1);
    auto d = p.decide("cuda:0", bm, {"cpu", "cuda:1"});
    EXPECT_EQ(d.strategy, FallbackStrategy::ToCpu);
    EXPECT_EQ(d.target_backend, "cpu");
    EXPECT_TRUE(d.skip_already_done);
    // 未完成 chunk 8 个（2,3,...,9）
    EXPECT_EQ(d.pending_chunks.size(), 8u);
}

TEST(SchedulerFallback, ToNextDeviceStrategy) {
    FallbackPolicy p;
    p.set_strategy(FallbackStrategy::ToNextDevice);
    CoverageBitmap bm(5);
    auto d = p.decide("cuda:0", bm, {"cpu", "cuda:1"});
    EXPECT_EQ(d.strategy, FallbackStrategy::ToNextDevice);
    EXPECT_EQ(d.target_backend, "cuda:1");
}

TEST(SchedulerFallback, NoneStrategyNoTarget) {
    FallbackPolicy p;
    p.set_strategy(FallbackStrategy::None);
    CoverageBitmap bm(5);
    auto d = p.decide("cuda:0", bm, {"cpu"});
    EXPECT_EQ(d.strategy, FallbackStrategy::None);
    EXPECT_TRUE(d.target_backend.empty());
}

TEST(SchedulerFallback, ToNextDeviceFallbackToCpuWhenNoOtherGpu) {
    FallbackPolicy p;
    p.set_strategy(FallbackStrategy::ToNextDevice);
    CoverageBitmap bm(5);
    auto d = p.decide("cuda:0", bm, {"cpu"});
    // 只有 cpu 可用，ToNextDevice 退化为 ToCpu
    EXPECT_EQ(d.strategy, FallbackStrategy::ToCpu);
    EXPECT_EQ(d.target_backend, "cpu");
}

// ============================================================================
// MixedRunner
// ============================================================================

TEST(SchedulerMixedRunner, CoverageCompleteNoRepeat) {
    astro::compute::runtime_init();
    MixedRunner runner;
    MixedRunnerConfig cfg;
    runner.configure(cfg);

    struct UD { std::vector<int>* data; std::atomic<int>* count; };
    std::vector<int> data(1000, 0);
    std::atomic<int> call_count{0};
    UD ud{&data, &call_count};
    auto real_fn = +[](std::size_t, std::size_t b, std::size_t e, void* p) {
        UD* u = static_cast<UD*>(p);
        for (std::size_t i = b; i < e; ++i) (*u->data)[i] = 1;
        u->count->fetch_add(1, std::memory_order_relaxed);
    };
    auto r = runner.run_range(0, 1000, 100, real_fn, &ud);
    EXPECT_TRUE(r.all_done);
    EXPECT_EQ(r.total_chunks, 10u);
    EXPECT_EQ(r.executed_on_cpu, 10u);
    EXPECT_EQ(r.failed_chunks, 0u);
    EXPECT_EQ(call_count.load(), 10);

    // coverage 完整不重复
    int total = std::accumulate(data.begin(), data.end(), 0);
    EXPECT_EQ(total, 1000);
    const auto& bm = runner.last_coverage();
    EXPECT_EQ(bm.done_count(), 10u);
    EXPECT_TRUE(bm.all_done());

    astro::compute::runtime_shutdown();
}

TEST(SchedulerMixedRunner, EmptyRangeReturnsSuccess) {
    astro::compute::runtime_init();
    MixedRunner runner;
    auto r = runner.run_range(0, 0, 100,
        +[](std::size_t, std::size_t, std::size_t, void*) {}, nullptr);
    EXPECT_TRUE(r.all_done);
    EXPECT_EQ(r.total_chunks, 0u);
    astro::compute::runtime_shutdown();
}

TEST(SchedulerMixedRunner, ExceptionInChunkCountsAsFailed) {
    astro::compute::runtime_init();
    MixedRunner runner;
    MixedRunnerConfig cfg;
    runner.configure(cfg);
    std::vector<int> data(100, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        std::vector<int>* d = static_cast<std::vector<int>*>(ud);
        if (b == 0) throw std::runtime_error("chunk 0 failed");
        for (std::size_t i = b; i < e; ++i) (*d)[i] = 1;
    };
    auto r = runner.run_range(0, 100, 50, fn, &data);
    EXPECT_FALSE(r.all_done);
    EXPECT_EQ(r.failed_chunks, 1u);
    EXPECT_EQ(r.executed_on_cpu, 1u);  // 第二个 chunk 成功
    astro::compute::runtime_shutdown();
}

// ============================================================================
// Dispatcher
// ============================================================================

TEST(SchedulerDispatcher, DispatchRangeExecutesAll) {
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    d.configure(cfg);

    std::vector<int> data(100, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        std::vector<int>* d = static_cast<std::vector<int>*>(ud);
        for (std::size_t i = b; i < e; ++i) (*d)[i] = 1;
    };
    auto r = d.dispatch_range(0, 100, 25, fn, &data);
    EXPECT_TRUE(r.all_done);
    EXPECT_EQ(r.total_chunks, 4u);
    int total = std::accumulate(data.begin(), data.end(), 0);
    EXPECT_EQ(total, 100);
    astro::compute::runtime_shutdown();
}

TEST(SchedulerDispatcher, PickBackendSmallDataPrefersCpu) {
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.small_data_threshold_bytes = 1u << 20;  // 1MB
    cfg.devices = {
        {"cpu", 0, 0, 50.0, true},
        {"cuda:0", 0, 0, 100.0, true},  // 高带宽
    };
    d.configure(cfg);
    TaskEstimate small{1024, 1, 1000.0, 0.0};  // 1KB < 1MB → CPU
    EXPECT_EQ(d.pick_backend(small), "cpu");
}

TEST(SchedulerDispatcher, HandleFailureReturnsFallbackDecision) {
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.fallback_strategy = FallbackStrategy::ToCpu;
    cfg.devices = {
        {"cpu", 0, 0, 50.0, true},
        {"cuda:0", 0, 0, 100.0, true},
    };
    d.configure(cfg);
    CoverageBitmap bm(5);
    bm.mark_done(0);
    auto dec = d.handle_failure("cuda:0", bm);
    EXPECT_EQ(dec.strategy, FallbackStrategy::ToCpu);
    EXPECT_EQ(dec.target_backend, "cpu");
    EXPECT_EQ(dec.pending_chunks.size(), 4u);
}

// ============================================================================
// Dispatcher::dispatch_range_cost_aware (Commit F)
// ============================================================================

// 辅助：构造 CPU-only CostEstimate（profile_available=false → 纯 CPU 路径）
static astro::compute::cost::CostEstimate make_cpu_only_estimate(std::size_t recommended_chunk) {
    astro::compute::cost::CostEstimate est;
    est.profile_available = false;
    astro::compute::cost::DeviceCost cpu_cost;
    cpu_cost.device_id = astro::compute::kCpuDeviceId;
    cpu_cost.backend = "cpu";
    cpu_cost.feasible = true;
    cpu_cost.recommended_chunk = recommended_chunk;
    cpu_cost.profile_available = false;
    est.per_device.push_back(cpu_cost);
    est.preferred_device = astro::compute::kCpuDeviceId;
    return est;
}

TEST(SchedulerDispatcherCostAware, CpuOnlyExecutesAll) {
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    cfg.enable_memory_budget = false;  // 禁用 utilization 以走简单路径
    cfg.enable_fixed_tail_chunking = false;
    d.configure(cfg);

    astro::compute::TaskDescriptor task;
    task.range = astro::compute::Range1D{0, 100};

    auto est = make_cpu_only_estimate(25);
    std::vector<int> data(100, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        auto* d = static_cast<std::vector<int>*>(ud);
        for (std::size_t i = b; i < e; ++i) (*d)[i] = 1;
    };
    auto r = d.dispatch_range_cost_aware(task, est, fn, &data);
    EXPECT_TRUE(r.run_result.all_done);
    EXPECT_EQ(r.actual_primary_backend, "cpu");
    EXPECT_GT(r.total_chunks, 0u);
    int total = std::accumulate(data.begin(), data.end(), 0);
    EXPECT_EQ(total, 100);
    astro::compute::runtime_shutdown();
}

TEST(SchedulerDispatcherCostAware, FixedTailChunkingSplitsRange) {
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    cfg.enable_memory_budget = true;
    cfg.enable_fixed_tail_chunking = true;
    cfg.fixed_tail_threshold = 0.7;
    cfg.min_effective_chunk = 256;
    d.configure(cfg);

    // 范围需 > min_effective_chunk * 4 = 1024 才触发分段
    astro::compute::TaskDescriptor task;
    task.range = astro::compute::Range1D{0, 10000};

    auto est = make_cpu_only_estimate(500);
    std::vector<int> data(10000, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        auto* d = static_cast<std::vector<int>*>(ud);
        for (std::size_t i = b; i < e; ++i) (*d)[i] = 1;
    };
    auto r = d.dispatch_range_cost_aware(task, est, fn, &data);
    EXPECT_TRUE(r.run_result.all_done);
    EXPECT_TRUE(r.fixed_tail_chunking_used);
    EXPECT_GE(r.fixed_tail_min_chunk, cfg.min_effective_chunk);
    // 完整覆盖
    int total = std::accumulate(data.begin(), data.end(), 0);
    EXPECT_EQ(total, 10000);
    astro::compute::runtime_shutdown();
}

TEST(SchedulerDispatcherCostAware, FixedTailChunkingDisabledNoSplit) {
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    cfg.enable_memory_budget = false;  // 不验证资源控制，隔离系统状态
    cfg.enable_fixed_tail_chunking = false;  // 禁用
    cfg.min_effective_chunk = 256;
    d.configure(cfg);

    astro::compute::TaskDescriptor task;
    task.range = astro::compute::Range1D{0, 10000};

    auto est = make_cpu_only_estimate(500);
    std::vector<int> data(10000, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        auto* d = static_cast<std::vector<int>*>(ud);
        for (std::size_t i = b; i < e; ++i) (*d)[i] = 1;
    };
    auto r = d.dispatch_range_cost_aware(task, est, fn, &data);
    EXPECT_TRUE(r.run_result.all_done);
    EXPECT_FALSE(r.fixed_tail_chunking_used);
    int total = std::accumulate(data.begin(), data.end(), 0);
    EXPECT_EQ(total, 10000);
    astro::compute::runtime_shutdown();
}

TEST(SchedulerDispatcherCostAware, MemoryActionPopulated) {
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    cfg.enable_memory_budget = true;
    cfg.enable_fixed_tail_chunking = true;
    d.configure(cfg);

    astro::compute::TaskDescriptor task;
    task.range = astro::compute::Range1D{0, 1000};

    auto est = make_cpu_only_estimate(100);
    std::vector<int> data(1000, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        auto* d = static_cast<std::vector<int>*>(ud);
        for (std::size_t i = b; i < e; ++i) (*d)[i] = 1;
    };
    auto r = d.dispatch_range_cost_aware(task, est, fn, &data);
    // 不强制 all_done：系统内存使用可能导致 StopNewSubmit 触发（这是正确行为）
    // mem_action 应被填充（非空字符串）
    EXPECT_FALSE(r.mem_action.empty());
    // mem_action 值取决于系统内存状态（"none" 或 "stop" 等），不强制特定值
    astro::compute::runtime_shutdown();
}

TEST(SchedulerDispatcherCostAware, CurrentStateJsonPopulated) {
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    cfg.enable_memory_budget = false;
    cfg.enable_fixed_tail_chunking = false;
    d.configure(cfg);

    astro::compute::TaskDescriptor task;
    task.range = astro::compute::Range1D{0, 500};

    auto est = make_cpu_only_estimate(100);
    std::vector<int> data(500, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        auto* d = static_cast<std::vector<int>*>(ud);
        for (std::size_t i = b; i < e; ++i) (*d)[i] = 1;
    };
    auto r = d.dispatch_range_cost_aware(task, est, fn, &data);
    EXPECT_TRUE(r.run_result.all_done);
    EXPECT_FALSE(r.current_state_json.empty());
    // JSON 应包含 "cpu" 设备
    EXPECT_NE(r.current_state_json.find("cpu"), std::string::npos);
    astro::compute::runtime_shutdown();
}

// ============================================================================
// F-fix 1: actual vs predicted backend + coverage 真实导入
// ============================================================================

TEST(SchedulerDispatcherCostAware, PredictedVsActualBackend) {
    // 验证 predicted_primary_backend 与 actual_primary_backend 分别报告
    // profile_available=false → predicted 应为 cpu（fallback）, actual 也为 cpu
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    cfg.enable_memory_budget = false;
    cfg.enable_fixed_tail_chunking = false;
    d.configure(cfg);

    astro::compute::TaskDescriptor task;
    task.range = astro::compute::Range1D{0, 200};

    auto est = make_cpu_only_estimate(50);
    std::vector<int> data(200, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        auto* d = static_cast<std::vector<int>*>(ud);
        for (std::size_t i = b; i < e; ++i) (*d)[i] = 1;
    };
    auto r = d.dispatch_range_cost_aware(task, est, fn, &data);
    EXPECT_TRUE(r.run_result.all_done);
    // predicted 和 actual 都应为 cpu（无 GPU）
    EXPECT_FALSE(r.predicted_primary_backend.empty());
    EXPECT_FALSE(r.actual_primary_backend.empty());
    EXPECT_EQ(r.actual_primary_backend, "cpu");
    // 实际设备列表应包含 cpu
    bool has_cpu = false;
    for (const auto& dev : r.actual_devices_used) {
        if (dev == "cpu") has_cpu = true;
    }
    EXPECT_TRUE(has_cpu);
    astro::compute::runtime_shutdown();
}

TEST(SchedulerDispatcherCostAware, CoverageFromRealExecution) {
    // 验证 coverage 从真实执行导入，不是无条件 mark_done
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    cfg.enable_memory_budget = false;
    cfg.enable_fixed_tail_chunking = false;
    d.configure(cfg);

    astro::compute::TaskDescriptor task;
    task.range = astro::compute::Range1D{0, 100};

    auto est = make_cpu_only_estimate(25);
    std::vector<int> data(100, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        auto* d = static_cast<std::vector<int>*>(ud);
        for (std::size_t i = b; i < e; ++i) (*d)[i] = 1;
    };
    auto r = d.dispatch_range_cost_aware(task, est, fn, &data);
    EXPECT_TRUE(r.run_result.all_done);
    // coverage 统计应匹配
    EXPECT_EQ(r.coverage.total, r.total_chunks);
    EXPECT_EQ(r.coverage.done, r.total_chunks);
    EXPECT_EQ(r.coverage.failed, 0u);
    EXPECT_EQ(r.coverage.pending, 0u);
    astro::compute::runtime_shutdown();
}

TEST(SchedulerDispatcherCostAware, CoverageReflectsFailures) {
    // 验证失败的 chunk 不被标为 done
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    cfg.enable_memory_budget = false;
    cfg.enable_fixed_tail_chunking = false;
    d.configure(cfg);

    astro::compute::TaskDescriptor task;
    task.range = astro::compute::Range1D{0, 100};

    auto est = make_cpu_only_estimate(25);
    // kernel：前 50 个元素正常，后 50 个抛异常
    std::vector<int> data(100, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        auto* d = static_cast<std::vector<int>*>(ud);
        for (std::size_t i = b; i < e; ++i) {
            if (i >= 50) throw std::runtime_error("intentional failure");
            (*d)[i] = 1;
        }
    };
    auto r = d.dispatch_range_cost_aware(task, est, fn, &data);
    // 不应全部完成（有失败块）
    EXPECT_FALSE(r.run_result.all_done);
    // coverage 应反映失败
    EXPECT_GT(r.coverage.failed, 0u);
    EXPECT_LT(r.coverage.done, r.coverage.total);
    // actual_primary_backend 仍为 cpu（有成功的块在 cpu）
    EXPECT_EQ(r.actual_primary_backend, "cpu");
    astro::compute::runtime_shutdown();
}

TEST(SchedulerDispatcherCostAware, ActualBackendNoneWhenAllFail) {
    // 全部失败时 actual_primary_backend 应为 "none"
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    cfg.enable_memory_budget = false;
    cfg.enable_fixed_tail_chunking = false;
    d.configure(cfg);

    astro::compute::TaskDescriptor task;
    task.range = astro::compute::Range1D{0, 50};

    auto est = make_cpu_only_estimate(25);
    auto fn = +[](std::size_t, std::size_t, std::size_t, void*) -> void {
        throw std::runtime_error("all fail");
    };
    auto r = d.dispatch_range_cost_aware(task, est, fn, nullptr);
    EXPECT_FALSE(r.run_result.all_done);
    EXPECT_GT(r.coverage.failed, 0u);
    EXPECT_EQ(r.coverage.done, 0u);
    // 无成功块 → actual 为 none
    EXPECT_EQ(r.actual_primary_backend, "none");
    EXPECT_TRUE(r.actual_devices_used.empty());
    astro::compute::runtime_shutdown();
}

// ============================================================================
// F-fix 2: SharedWorkPool 单元测试
// ============================================================================

TEST(SharedWorkPool, InitCreatesCorrectBlocks) {
    SharedWorkPool pool;
    pool.init(0, 100, 25);
    EXPECT_EQ(pool.total_blocks(), 4u);
    EXPECT_EQ(pool.pending_count(), 4u);
    EXPECT_EQ(pool.done_count(), 0u);
    EXPECT_EQ(pool.failed_count(), 0u);
    EXPECT_EQ(pool.completed_items(), 0u);
    EXPECT_FALSE(pool.all_done());
    // 验证块范围（通过 slot 查询接口）
    EXPECT_EQ(pool.slot_begin(0), 0u);
    EXPECT_EQ(pool.slot_end(0), 25u);
    EXPECT_EQ(pool.slot_begin(3), 75u);
    EXPECT_EQ(pool.slot_end(3), 100u);
}

TEST(SharedWorkPool, ClaimNextReturnsUniqueBlocks) {
    SharedWorkPool pool;
    pool.init(0, 100, 25);
    auto b1 = pool.claim_next(kHwCpuDeviceId);
    auto b2 = pool.claim_next(kHwCpuDeviceId);
    ASSERT_TRUE(b1.valid());
    ASSERT_TRUE(b2.valid());
    EXPECT_NE(b1.id, b2.id);
    EXPECT_EQ(b1.claimant, kHwCpuDeviceId);
    EXPECT_EQ(b2.claimant, kHwCpuDeviceId);
    EXPECT_EQ(pool.pending_count(), 2u);
    EXPECT_EQ(pool.claimed_count(), 2u);
}

TEST(SharedWorkPool, MarkDoneUpdatesStatus) {
    SharedWorkPool pool;
    pool.init(0, 100, 25);
    auto b = pool.claim_next(kHwCpuDeviceId);
    ASSERT_TRUE(b.valid());
    pool.mark_done(b);
    EXPECT_EQ(pool.done_count(), 1u);
    EXPECT_EQ(pool.completed_items(), 25u);
    EXPECT_EQ(pool.pending_count(), 3u);
    EXPECT_FALSE(pool.all_done());
}

TEST(SharedWorkPool, MarkFailedAndReclaim) {
    SharedWorkPool pool;
    pool.init(0, 100, 25);
    auto b = pool.claim_next(kHwCpuDeviceId);
    ASSERT_TRUE(b.valid());
    pool.mark_failed(b);
    EXPECT_EQ(pool.failed_count(), 1u);
    EXPECT_EQ(pool.retry_pending_count(), 1u);
    EXPECT_EQ(pool.pending_count(), 3u);
    // 回收失败块
    std::size_t reclaimed = pool.reclaim_failed();
    EXPECT_EQ(reclaimed, 1u);
    EXPECT_EQ(pool.pending_count(), 4u);
    EXPECT_EQ(pool.failed_count(), 0u);
}

TEST(SharedWorkPool, AllDoneWhenAllComplete) {
    SharedWorkPool pool;
    pool.init(0, 100, 25);
    // 领取并完成所有块
    for (std::size_t i = 0; i < 4; ++i) {
        auto b = pool.claim_next(kHwCpuDeviceId);
        ASSERT_TRUE(b.valid());
        pool.mark_done(b);
    }
    EXPECT_TRUE(pool.all_done());
    EXPECT_EQ(pool.done_count(), 4u);
    EXPECT_EQ(pool.completed_items(), 100u);
}

TEST(SharedWorkPool, NoWorkLeftWhenNoPendingOrFailed) {
    SharedWorkPool pool;
    pool.init(0, 100, 25);
    for (std::size_t i = 0; i < 4; ++i) {
        auto b = pool.claim_next(kHwCpuDeviceId);
        ASSERT_TRUE(b.valid());
        pool.mark_done(b);
    }
    EXPECT_TRUE(pool.no_work_left());
}

TEST(SharedWorkPool, DoneBitmapCorrect) {
    SharedWorkPool pool;
    pool.init(0, 100, 25);
    // 顺序领取：第一个块和第二个块
    auto b1 = pool.claim_next(kHwCpuDeviceId);
    auto b2 = pool.claim_next(kHwCpuDeviceId);
    ASSERT_TRUE(b1.valid());
    ASSERT_TRUE(b2.valid());
    pool.mark_done(b1);
    pool.mark_done(b2);
    auto bm = pool.done_bitmap();
    ASSERT_EQ(bm.size(), 4u);
    EXPECT_TRUE(bm[b1.id]);
    EXPECT_TRUE(bm[b2.id]);
    EXPECT_NE(b1.id, b2.id);
}

TEST(SharedWorkPool, TerminalFailureBlocksAllDone) {
    SharedWorkPool pool;
    pool.init(0, 100, 25);
    auto b = pool.claim_next(kHwCpuDeviceId);
    ASSERT_TRUE(b.valid());
    pool.mark_failed(b, /*retryable=*/false);
    EXPECT_EQ(pool.failed_terminal_count(), 1u);
    EXPECT_FALSE(pool.all_done());
}

TEST(SharedWorkPool, EmptyRange) {
    SharedWorkPool pool;
    pool.init(0, 0, 25);
    EXPECT_EQ(pool.total_blocks(), 0u);
    EXPECT_TRUE(pool.all_done());
    EXPECT_FALSE(pool.claim_next(kHwCpuDeviceId).valid());
}

// ============================================================================
// F-fix 2: Dispatcher 通过 SharedWorkPool 执行
// ============================================================================

TEST(SchedulerDispatcherCostAware, SharedPoolExecutionCompletesAll) {
    // 验证 Dispatcher 通过 SharedWorkPool 执行时所有块完成
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    cfg.enable_memory_budget = false;
    cfg.enable_fixed_tail_chunking = false;
    d.configure(cfg);

    astro::compute::TaskDescriptor task;
    task.range = astro::compute::Range1D{0, 1000};

    auto est = make_cpu_only_estimate(100);
    std::vector<int> data(1000, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        auto* d = static_cast<std::vector<int>*>(ud);
        for (std::size_t i = b; i < e; ++i) (*d)[i] = 1;
    };
    auto r = d.dispatch_range_cost_aware(task, est, fn, &data);
    EXPECT_TRUE(r.run_result.all_done);
    EXPECT_EQ(r.actual_primary_backend, "cpu");
    EXPECT_EQ(r.coverage.done, r.coverage.total);
    EXPECT_EQ(r.coverage.failed, 0u);
    // 完整覆盖
    int total = std::accumulate(data.begin(), data.end(), 0);
    EXPECT_EQ(total, 1000);
    astro::compute::runtime_shutdown();
}

TEST(SchedulerDispatcherCostAware, SharedPoolFailedBlocksNotDone) {
    // 验证通过 SharedWorkPool 执行时失败块不标 DONE
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    cfg.enable_memory_budget = false;
    cfg.enable_fixed_tail_chunking = false;
    d.configure(cfg);

    astro::compute::TaskDescriptor task;
    task.range = astro::compute::Range1D{0, 100};

    auto est = make_cpu_only_estimate(25);
    std::vector<int> data(100, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        auto* d = static_cast<std::vector<int>*>(ud);
        for (std::size_t i = b; i < e; ++i) {
            if (i >= 50) throw std::runtime_error("intentional failure");
            (*d)[i] = 1;
        }
    };
    auto r = d.dispatch_range_cost_aware(task, est, fn, &data);
    EXPECT_FALSE(r.run_result.all_done);
    EXPECT_GT(r.coverage.failed, 0u);
    EXPECT_LT(r.coverage.done, r.coverage.total);
    astro::compute::runtime_shutdown();
}

// ============================================================================
// F-fix 3: SharedWorkPool 动态 guided 模式测试
// 验收：不同比例设备速度下，拖尾明显收敛；不重复、不遗漏
// ============================================================================

TEST(SharedWorkPoolDynamic, InitDynamicDoesNotPreCreateBlocks) {
    // init_dynamic 不应预创建块（与 init 固定模式不同）
    SharedWorkPool pool;
    pool.init_dynamic(0, 1000, 100, 500);
    EXPECT_TRUE(pool.is_dynamic());
    // 动态模式下，块在 claim 时才创建
    EXPECT_EQ(pool.total_blocks(), 0u);
    EXPECT_EQ(pool.pending_count(), 0u);
    // 剩余工作应为 1000
    EXPECT_EQ(pool.remaining_work(), 1000u);
}

TEST(SharedWorkPoolDynamic, ClaimNextDynamicReturnsBlocks) {
    SharedWorkPool pool;
    pool.init_dynamic(0, 1000, 100, 500);
    auto b1 = pool.claim_next_dynamic(kHwCpuDeviceId, 500);
    ASSERT_TRUE(b1.valid());
    EXPECT_GE(b1.end - b1.begin, 100u);  // 至少 min_chunk
    EXPECT_LE(b1.end - b1.begin, 500u);  // 至多 max_chunk
    EXPECT_EQ(b1.begin, 0u);
    EXPECT_EQ(b1.end, 500u);
    EXPECT_EQ(b1.claimant, kHwCpuDeviceId);
    EXPECT_EQ(b1.attempt, 1u);
    // 块已创建（动态模式 total_blocks 返回 active_slot_count）
    EXPECT_EQ(pool.total_blocks(), 1u);
    EXPECT_EQ(pool.claimed_count(), 1u);
}

TEST(SharedWorkPoolDynamic, ClaimNextDynamicShrinksTail) {
    // 验证尾部收缩：随着剩余工作减少，块大小应逐步收缩
    SharedWorkPool pool;
    pool.init_dynamic(0, 1000, 50, 700);
    std::vector<std::size_t> chunk_sizes;
    while (true) {
        auto b = pool.claim_next_dynamic(kHwCpuDeviceId, 700);
        if (!b.valid()) break;
        chunk_sizes.push_back(b.end - b.begin);
        pool.mark_done(b);
    }
    // 应该有多个块
    EXPECT_GT(chunk_sizes.size(), 1u);
    // 第一个块应较大（700）
    EXPECT_EQ(chunk_sizes.front(), 700u);
    // 最后一个块应较小（尾部收缩；最后一块可能因范围结束而更小）
    EXPECT_LE(chunk_sizes.back(), chunk_sizes.front());
    // 非最后块大小都应在 [min_chunk, max_chunk] 范围内
    // （最后一块可能因 range_end 截断而小于 min_chunk）
    for (std::size_t i = 0; i + 1 < chunk_sizes.size(); ++i) {
        EXPECT_GE(chunk_sizes[i], 50u);
        EXPECT_LE(chunk_sizes[i], 700u);
    }
    // 最后一块至少有 1 个元素
    EXPECT_GE(chunk_sizes.back(), 1u);
}

TEST(SharedWorkPoolDynamic, ClaimNextDynamicNoOverlapNoOmission) {
    // 验证无重复、无遗漏：所有块的并集应完整覆盖 [0, end)，且不重叠
    SharedWorkPool pool;
    pool.init_dynamic(0, 1000, 100, 300);
    std::vector<std::pair<std::size_t, std::size_t>> ranges;
    while (true) {
        auto b = pool.claim_next_dynamic(kHwCpuDeviceId, 300);
        if (!b.valid()) break;
        ranges.emplace_back(b.begin, b.end);
        pool.mark_done(b);
    }
    // 排序范围
    std::sort(ranges.begin(), ranges.end());
    // 验证起始为 0
    EXPECT_EQ(ranges.front().first, 0u);
    // 验证结束为 1000
    EXPECT_EQ(ranges.back().second, 1000u);
    // 验证不重叠且连续
    for (std::size_t i = 1; i < ranges.size(); ++i) {
        EXPECT_EQ(ranges[i].first, ranges[i-1].second)
            << "Gap or overlap at index " << i;
    }
    // 所有块应完成
    EXPECT_TRUE(pool.all_done());
    EXPECT_EQ(pool.done_count(), pool.total_blocks());
    EXPECT_EQ(pool.completed_items(), 1000u);
}

TEST(SharedWorkPoolDynamic, ClaimNextDynamicRequestedItemsControlsChunk) {
    // 23 §4：块大小由调用方 requested_items（每设备 CostEstimate）控制，
    // 与设备数量无关（GPU 数量不得再折算 CPU 块大小）。
    SharedWorkPool pool1;
    pool1.init_dynamic(0, 1000, 50, 500);
    auto b1 = pool1.claim_next_dynamic(kHwCpuDeviceId, 500);  // 大块请求

    SharedWorkPool pool2;
    pool2.init_dynamic(0, 1000, 50, 500);
    auto b2 = pool2.claim_next_dynamic(kHwCpuDeviceId, 100);  // 小块请求

    ASSERT_TRUE(b1.valid());
    ASSERT_TRUE(b2.valid());
    std::size_t sz1 = b1.end - b1.begin;
    std::size_t sz2 = b2.end - b2.begin;
    EXPECT_EQ(sz1, 500u);  // 请求 500 → 500
    EXPECT_EQ(sz2, 100u);  // 请求 100 → 100
    // 同一池内不同请求产生不同块大小（每设备独立 claim）
    SharedWorkPool pool3;
    pool3.init_dynamic(0, 2000, 50, 500);
    auto c1 = pool3.claim_next_dynamic(kHwCpuDeviceId, 500);
    auto c2 = pool3.claim_next_dynamic(static_cast<DeviceId>(1), 100);  // GPU 0
    ASSERT_TRUE(c1.valid());
    ASSERT_TRUE(c2.valid());
    EXPECT_EQ(c1.end - c1.begin, 500u);
    EXPECT_EQ(c2.end - c2.begin, 100u);
    EXPECT_EQ(c1.claimant, kHwCpuDeviceId);
    EXPECT_EQ(c2.claimant, static_cast<DeviceId>(1));
}

TEST(SharedWorkPoolDynamic, EmptyRangeReturnsSuccess) {
    SharedWorkPool pool;
    pool.init_dynamic(100, 100, 50, 100);  // 空范围
    EXPECT_EQ(pool.remaining_work(), 0u);
    EXPECT_FALSE(pool.claim_next_dynamic(kHwCpuDeviceId, 1).valid());
    EXPECT_TRUE(pool.all_done());
}

// ============================================================================
// F-fix 3: Dispatcher 动态 guided 模式测试
// ============================================================================

TEST(SchedulerDispatcherCostAware, DynamicModeCompletesAll) {
    // 验证动态 guided 模式完成所有工作
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    cfg.enable_memory_budget = false;
    cfg.enable_fixed_tail_chunking = false;
    cfg.min_effective_chunk = 64;
    d.configure(cfg);

    astro::compute::TaskDescriptor task;
    task.range = astro::compute::Range1D{0, 1000};

    auto est = make_cpu_only_estimate(256);
    std::vector<int> data(1000, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        auto* d = static_cast<std::vector<int>*>(ud);
        for (std::size_t i = b; i < e; ++i) (*d)[i] = 1;
    };
    auto r = d.dispatch_range_cost_aware(task, est, fn, &data);
    EXPECT_TRUE(r.run_result.all_done);
    EXPECT_EQ(r.actual_primary_backend, "cpu");
    EXPECT_EQ(r.coverage.done, r.coverage.total);
    EXPECT_EQ(r.coverage.failed, 0u);
    // 完整覆盖
    int total = std::accumulate(data.begin(), data.end(), 0);
    EXPECT_EQ(total, 1000);
    // 应使用动态模式
    EXPECT_TRUE(r.resource_control.dynamic_mode_used);
    astro::compute::runtime_shutdown();
}

TEST(SchedulerDispatcherCostAware, DynamicModeRecordsChunkSizes) {
    // 验证动态模式记录块大小序列（用于验证尾部收缩）
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    cfg.enable_memory_budget = false;
    cfg.enable_fixed_tail_chunking = false;
    cfg.min_effective_chunk = 32;
    d.configure(cfg);

    astro::compute::TaskDescriptor task;
    task.range = astro::compute::Range1D{0, 500};

    auto est = make_cpu_only_estimate(200);
    std::vector<int> data(500, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        auto* d = static_cast<std::vector<int>*>(ud);
        for (std::size_t i = b; i < e; ++i) (*d)[i] = 1;
    };
    auto r = d.dispatch_range_cost_aware(task, est, fn, &data);
    EXPECT_TRUE(r.run_result.all_done);
    // 应记录块大小序列
    EXPECT_FALSE(r.resource_control.dynamic_chunk_sizes.empty());
    // 并行执行顺序不确定，按值排序后验证
    // 非最小块（排除 range_end 截断的最后一块）都应在 [min_chunk, max_chunk] 范围内
    auto sizes = r.resource_control.dynamic_chunk_sizes;  // 复制以排序
    std::sort(sizes.begin(), sizes.end());
    // 最小块可能因 range_end 截断而小于 min_chunk
    EXPECT_GE(sizes.front(), 1u);
    // 除最小块外，其他块都应 >= min_effective_chunk
    for (std::size_t i = 1; i < sizes.size(); ++i) {
        EXPECT_GE(sizes[i], 32u);
        EXPECT_LE(sizes[i], 200u);
    }
    astro::compute::runtime_shutdown();
}

TEST(SchedulerDispatcherCostAware, DynamicModeTailConvergence) {
    // 验证尾部收缩：前面的块应较大，后面的块应较小
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    cfg.enable_memory_budget = false;
    cfg.enable_fixed_tail_chunking = false;
    cfg.min_effective_chunk = 16;
    d.configure(cfg);

    astro::compute::TaskDescriptor task;
    task.range = astro::compute::Range1D{0, 1000};

    auto est = make_cpu_only_estimate(500);
    std::vector<int> data(1000, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        auto* d = static_cast<std::vector<int>*>(ud);
        for (std::size_t i = b; i < e; ++i) (*d)[i] = 1;
    };
    auto r = d.dispatch_range_cost_aware(task, est, fn, &data);
    EXPECT_TRUE(r.run_result.all_done);
    // 块大小序列应非空
    EXPECT_FALSE(r.resource_control.dynamic_chunk_sizes.empty());
    // 并行执行顺序不确定，排序后验证尾部收缩
    auto sizes = r.resource_control.dynamic_chunk_sizes;  // 复制以排序
    std::sort(sizes.begin(), sizes.end());
    // 最大块应较大（接近 max_chunk=500）
    EXPECT_GE(sizes.back(), 100u);
    // 最小块应较小（尾部收缩；可能因 range_end 截断而更小）
    EXPECT_LE(sizes.front(), sizes.back());
    astro::compute::runtime_shutdown();
}

TEST(SchedulerDispatcherCostAware, DynamicModeNoOverlapNoOmission) {
    // 验证动态模式无重复、无遗漏
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    cfg.enable_memory_budget = false;
    cfg.enable_fixed_tail_chunking = false;
    cfg.min_effective_chunk = 25;
    d.configure(cfg);

    astro::compute::TaskDescriptor task;
    task.range = astro::compute::Range1D{0, 500};

    auto est = make_cpu_only_estimate(100);
    std::vector<int> data(500, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        auto* d = static_cast<std::vector<int>*>(ud);
        for (std::size_t i = b; i < e; ++i) (*d)[i] += 1;  // 累加，验证不重复
    };
    auto r = d.dispatch_range_cost_aware(task, est, fn, &data);
    EXPECT_TRUE(r.run_result.all_done);
    // 每个元素应恰好被处理一次
    for (std::size_t i = 0; i < 500; ++i) {
        EXPECT_EQ(data[i], 1) << "Element " << i << " processed " << data[i] << " times";
    }
    astro::compute::runtime_shutdown();
}

// ============================================================================
// 26 §2/§9：内存预算反压记录测试（CPU/GPU 利用率控制已移除）
// ============================================================================

TEST(SchedulerDispatcherCostAware, ResourceControlRecordsMemBudget) {
    // 验证资源控制记录内存预算采样序列与峰值估算
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    cfg.enable_memory_budget = true;
    cfg.enable_fixed_tail_chunking = false;
    cfg.min_effective_chunk = 32;
    d.configure(cfg);

    astro::compute::TaskDescriptor task;
    task.range = astro::compute::Range1D{0, 5000};

    auto est = make_cpu_only_estimate(256);
    std::vector<int> data(5000, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        auto* d = static_cast<std::vector<int>*>(ud);
        for (std::size_t i = b; i < e; ++i) (*d)[i] = 1;
    };
    auto r = d.dispatch_range_cost_aware(task, est, fn, &data);
    // 内存采样序列应非空（启用了 memory budget）
    EXPECT_FALSE(r.resource_control.mem_actions.empty());
    EXPECT_GT(r.resource_control.mem_limit_ram, 0u);
    astro::compute::runtime_shutdown();
}

TEST(SchedulerDispatcherCostAware, ResourceControlRecordsMemActions) {
    // 验证资源控制记录内存预算动作序列
    // 注意：CI 环境系统内存使用可能导致 StopNewSubmit 触发，因此不强制 all_done
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    cfg.enable_memory_budget = true;   // 启用内存采样
    cfg.enable_fixed_tail_chunking = false;
    cfg.min_effective_chunk = 32;
    d.configure(cfg);

    astro::compute::TaskDescriptor task;
    task.range = astro::compute::Range1D{0, 5000};

    auto est = make_cpu_only_estimate(256);
    std::vector<int> data(5000, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        auto* d = static_cast<std::vector<int>*>(ud);
        for (std::size_t i = b; i < e; ++i) (*d)[i] = 1;
    };
    auto r = d.dispatch_range_cost_aware(task, est, fn, &data);
    // 不强制 all_done：系统内存使用可能导致 StopNewSubmit 触发（这是正确行为）
    // 内存采样序列应非空
    EXPECT_FALSE(r.resource_control.mem_actions.empty());
    // 应记录 used_ram 序列
    EXPECT_FALSE(r.resource_control.mem_used_ram_samples.empty());
    // 应有 limit_ram
    EXPECT_GT(r.resource_control.mem_limit_ram, 0u);
    // 应有最终动作字符串
    EXPECT_FALSE(r.resource_control.final_mem_action.empty());
    astro::compute::runtime_shutdown();
}

TEST(SchedulerDispatcherCostAware, ResourceControlSubmitGateNotTriggeredNormalLoad) {
    // 验证正常负载下 submit gate 不触发
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    cfg.enable_memory_budget = true;
    cfg.enable_fixed_tail_chunking = false;
    cfg.min_effective_chunk = 32;
    d.configure(cfg);

    astro::compute::TaskDescriptor task;
    task.range = astro::compute::Range1D{0, 1000};

    auto est = make_cpu_only_estimate(128);
    std::vector<int> data(1000, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        auto* d = static_cast<std::vector<int>*>(ud);
        for (std::size_t i = b; i < e; ++i) (*d)[i] = 1;
    };
    auto r = d.dispatch_range_cost_aware(task, est, fn, &data);
    // 小任务 + 默认内存预算：全部完成且 gate 不触发
    EXPECT_TRUE(r.run_result.all_done);
    EXPECT_FALSE(r.resource_control.gate_aborted);
    astro::compute::runtime_shutdown();
}

TEST(SchedulerDispatcherCostAware, FixedTailExperimentStillAvailable) {
    // 验证 fixed_tail_chunking 实验仍可用（opt-in）
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    cfg.enable_memory_budget = false;
    cfg.enable_fixed_tail_chunking = true;   // 启用 fixed_tail 实验
    cfg.fixed_tail_threshold = 0.7;
    cfg.min_effective_chunk = 32;
    d.configure(cfg);

    astro::compute::TaskDescriptor task;
    task.range = astro::compute::Range1D{0, 1000};

    auto est = make_cpu_only_estimate(256);
    std::vector<int> data(1000, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        auto* d = static_cast<std::vector<int>*>(ud);
        for (std::size_t i = b; i < e; ++i) (*d)[i] = 1;
    };
    auto r = d.dispatch_range_cost_aware(task, est, fn, &data);
    EXPECT_TRUE(r.run_result.all_done);
    // 应使用 fixed_tail_chunking（不是动态 guided）
    EXPECT_TRUE(r.fixed_tail_chunking_used);
    EXPECT_FALSE(r.resource_control.dynamic_mode_used);  // fixed_tail 不使用动态模式
    // 完整覆盖
    int total = std::accumulate(data.begin(), data.end(), 0);
    EXPECT_EQ(total, 1000);
    astro::compute::runtime_shutdown();
}

// ============================================================================
// F-fix 9: 可恢复资源闭环测试
// 验收：set_dynamic_max_chunk 影响后续 claim；gate 统计字段初始化；
// 正常负载下 gate 不触发；gate 关闭后可恢复
// ============================================================================

TEST(SharedWorkPoolDynamic, SetDynamicMaxChunkAffectsSubsequentClaims) {
    // 验证 set_dynamic_max_chunk 运行时调整后续 claim 的最大块大小
    SharedWorkPool pool;
    pool.init_dynamic(0, 10000, 100, 1000);  // min=100, max=1000

    // 初始 max=1000：前几个 claim 应受 1000 限制
    auto t1 = pool.claim_next_dynamic(kHwCpuDeviceId, 1000);
    ASSERT_TRUE(t1.valid());
    EXPECT_LE(t1.size(), 1000u);

    // 运行时缩小 max_chunk 到 200
    pool.set_dynamic_max_chunk(200);

    // 后续 claim 应受 200 限制
    auto t2 = pool.claim_next_dynamic(kHwCpuDeviceId, 1000);
    ASSERT_TRUE(t2.valid());
    EXPECT_LE(t2.size(), 200u);

    // 再次缩小到 min（100）
    pool.set_dynamic_max_chunk(50);  // 会被 clamp 到 min=100
    auto t3 = pool.claim_next_dynamic(kHwCpuDeviceId, 1000);
    ASSERT_TRUE(t3.valid());
    EXPECT_LE(t3.size(), 100u);  // 不小于 min_chunk
}

TEST(SharedWorkPoolDynamic, SetDynamicMaxChunkOnlyInDynamicMode) {
    // 验证 set_dynamic_max_chunk 仅在动态模式生效
    SharedWorkPool pool;
    pool.init(0, 100, 25);  // 固定模式

    // 非动态模式下调用应无效果（不崩溃）
    pool.set_dynamic_max_chunk(10);
    // 固定模式下 claim 仍返回固定块
    auto t = pool.claim_next(kHwCpuDeviceId);
    ASSERT_TRUE(t.valid());
    EXPECT_EQ(t.size(), 25u);  // 固定 25
}

TEST(SchedulerDispatcherCostAware, RecoverableGateStatsInitialized) {
    // 验证 F-fix 9 新增的 gate 统计字段初始化为 0
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    cfg.enable_memory_budget = false;
    cfg.enable_fixed_tail_chunking = false;
    d.configure(cfg);

    astro::compute::TaskDescriptor task;
    task.range = astro::compute::Range1D{0, 100};

    auto est = make_cpu_only_estimate(25);
    std::vector<int> data(100, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        auto* d = static_cast<std::vector<int>*>(ud);
        for (std::size_t i = b; i < e; ++i) (*d)[i] = 1;
    };
    auto r = d.dispatch_range_cost_aware(task, est, fn, &data);

    // 正常负载下 gate 不应触发
    EXPECT_FALSE(r.resource_control.gate_aborted);
    // gate_close_count 和 gate_recover_count 应存在（可能为 0）
    // 不强制为 0：系统内存状态可能触发内存 StopNewSubmit
    EXPECT_GE(r.resource_control.gate_close_count, 0u);
    EXPECT_GE(r.resource_control.gate_recover_count, 0u);
    // 工作应完成
    EXPECT_TRUE(r.run_result.all_done);
    astro::compute::runtime_shutdown();
}

TEST(SchedulerDispatcherCostAware, GateNotTriggeredAtFullTarget) {
    // 26 §2：无 CPU 利用率 gate；验证小任务在默认内存预算下完成
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    cfg.enable_memory_budget = true;
    cfg.enable_fixed_tail_chunking = false;
    cfg.min_effective_chunk = 32;
    d.configure(cfg);

    astro::compute::TaskDescriptor task;
    task.range = astro::compute::Range1D{0, 5000};

    auto est = make_cpu_only_estimate(256);
    std::vector<int> data(5000, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        auto* d = static_cast<std::vector<int>*>(ud);
        for (std::size_t i = b; i < e; ++i) (*d)[i] = 1;
    };
    auto r = d.dispatch_range_cost_aware(task, est, fn, &data);

    // 内存预算默认开启；正常负载不应导致 gate 超时放弃
    EXPECT_FALSE(r.resource_control.gate_aborted);
    astro::compute::runtime_shutdown();
}

TEST(SchedulerDispatcherCostAware, DynamicChunkSizesRecordedWithMaxChunkAdjust) {
    // 验证动态模式下 chunk_sizes 被记录，且受 max_chunk 限制
    astro::compute::runtime_init();
    Dispatcher d;
    DispatcherConfig cfg;
    cfg.devices = {{"cpu", 0, 0, 50.0, true}};
    cfg.enable_memory_budget = false;  // 禁用 utilization 走简单路径
    cfg.enable_fixed_tail_chunking = false;
    cfg.min_effective_chunk = 64;
    d.configure(cfg);

    astro::compute::TaskDescriptor task;
    task.range = astro::compute::Range1D{0, 10000};

    auto est = make_cpu_only_estimate(1000);  // recommended_chunk=1000
    std::vector<int> data(10000, 0);
    auto fn = +[](std::size_t, std::size_t b, std::size_t e, void* ud) {
        auto* d = static_cast<std::vector<int>*>(ud);
        for (std::size_t i = b; i < e; ++i) (*d)[i] = 1;
    };
    auto r = d.dispatch_range_cost_aware(task, est, fn, &data);

    // 动态模式应被使用
    EXPECT_TRUE(r.resource_control.dynamic_mode_used);
    // chunk_sizes 应非空
    EXPECT_FALSE(r.resource_control.dynamic_chunk_sizes.empty());
    // 所有 chunk_size 应 <= recommended_chunk（1000）
    // 注意：尾部块可能小于 min_effective_chunk（范围不整除时的最后一块）
    for (auto cs : r.resource_control.dynamic_chunk_sizes) {
        EXPECT_LE(cs, 1000u);
        EXPECT_GE(cs, 1u);  // 至少 1 个元素
    }
    // 完整覆盖
    EXPECT_TRUE(r.run_result.all_done);
    int total = std::accumulate(data.begin(), data.end(), 0);
    EXPECT_EQ(total, 10000);
    astro::compute::runtime_shutdown();
}

// ============================================================================
// main
// ============================================================================

int main(int argc, char** argv) {
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
