# AstroCS 审核包（20260909T133841Z）
- 基线：git HEAD 789c5b6cec5e7b25f6c13e41c55a0a2e8e905cd9（main，2026-09-09T21:36:43+08:00）
- 本包 = git archive HEAD 全量 + 工作树未提交增量（NOISE-IMPL 残留态：lib/snr_estimator 模块面 + tests/unit/p1_noise + 根 CMakeLists 追加块，未验收未提交，状态如实保留）
- 排除：大体积观测数据（GaiaDR3/GaiaDR3SP/BASS DR3/testdata）、编译产物（build/out/Testing/*.so/*.o）、运行索引（astrocs_run_*.json）、影子树快照、.git
- 证据面：evidence/（台账 TASK_STATE/STATE_RECONCILIATION.csv/COMMIT_LEDGER.jsonl + 各任务证据目录）、reports/、artifacts/、工程控制/（含 _control_packs zip 原件）、run/local/**（agent 日志/报告，已去 shadow/probe/构建产物）、docs/
- 旧控制包状态：V7 MODULAR REFOUNDATION 线 disarm 终止于 42/140（memory.md item 9）；pending 收尾：P1-NOISE-IMPL 残留态
