# AstroCS V6.1 Alpha 重构打回控制包

控制包：`AstroCS-V6.1-REWORK`  
目标版本：`0.10.0-alpha.2`  
上轮控制包 SHA-256：`fdad8e40123a757cfcdd51429261ca2e9c915f640e69adba8eb449ee2850f689`  
被审审核包 SHA-256：`137e3ed14ef85142f5897c93ac718f4f22713977282815e2ddd7288f62e6696a`  
审核包自报 commit：`b16d422a40fefedbdedab1749cfb8ebc06189736`（尚未被接受为基线）  
开发分支：仅 `main`

## 1. 结论与目标

上轮结果正式打回。不得继承“81 PASS、Linux 侧完成、G11 PASS”等状态。本包不是要求回退到历史版本，也不是要求重复比较旧版；它要求在当前 `main` 上完成真正的生产架构、纯 CPU 并行、科学 Oracle、文档—代码闭环及双平台发布验证。

只有执行完本包全部非 Owner 任务，Windows 最终验证完成，审核包自验证通过后，Agent 才能输出 `READY_FOR_OWNER_REVIEW`。Agent 永远无权输出 `ALPHA_RELEASE_APPROVED`。

## 2. 最高优先级

冲突时依次服从：

1. 仓库根 `AstroCS_ENGINEERING_CONSTRAINTS.md`；
2. 本文件和 `03_REWORK_TASK_LEDGER.csv`；
3. 本包各专项合同；
4. 已核实的当前 SCI/ALG/DATA 合同；
5. 当前源码仅是待审对象，不能因为已存在就成为正确设计；
6. 历史报告、自报 PASS、旧测试日志仅作线索。

## 3. 启动动作（必须按顺序）

1. 在独立控制目录解压本包，运行 `python3 scripts/validate_control.py .`，必须得到 `CONTROL_PASS`。
2. 阅读 `01_INDEPENDENT_AUDIT_CONCLUSION.md`、`02_FINDINGS.csv`、`03_REWORK_TASK_LEDGER.csv` 和当前任务规格。
3. `git fetch origin --prune`；确认当前分支仅为 `main`，且 `HEAD == main == origin/main`。
4. 验证 `b16d422...` 是否为当前 `main` 祖先；若不是，记录为 `SOURCE_IDENTITY_FAIL`，禁止修改代码并汇报。
5. 创建仓库内本轮证据目录 `evidence/v6_1_rework/`，复制任务台账；不得覆盖上轮证据。
6. 运行 `scripts/known_failure_scan.py <repo>`；起点预期失败，结果保存为 `KNOWN_FAILURES_BASELINE.json`。
7. 从 `R0-001` 连续执行，不设 CP0、普通外部审核或人工等待点。

## 4. 不得自由发挥

- 不改任务 ID、依赖、验收条件和严重度；需要新增任务只能追加，不得删改原任务。
- 不创建、切换或使用任何分支；不 merge/rebase/cherry-pick/reset/force-push。
- 每项修改任务一个原子 commit，消息必须以 `<TASK-ID>:` 开头；任务验收后立即 push `main`。
- 不大范围格式化，不顺手改无关模块，不以“重构”为名改变科学公式。
- 不运行历史版本全量对比；科学正确性用独立合成 Oracle，最终真实 32R 仅在 Windows 冻结候选上成功跑一次。
- ACR 保留但必须 `DORMANT_NOT_IN_PRODUCTION`；本 Alpha 生产只允许纯 CPU。
- 可用 CPU≥2 时，任何持续 ≥10 s 的 CPU-heavy 生产节点不得单线程或低利用率；保守 ISA 路径也必须并行。
- 关键词 grep、注释、`CHECK(true)`、伪造资源指标、空 trace、旧 V5 表、人工填写 PASS 均不得作为验收。
- Windows/Fatduck 离线时标 `WAITING_WINDOWS` 并继续所有 Linux、文档、静态和合成任务；不得因此整轮停工。

## 5. 每任务闭环

每个任务严格执行：

`NOT_STARTED → IN_PROGRESS → 修改/验证 → TASK_RESULT → 原子 commit → push → PASS`

PASS 需要同时满足：

- 任务规格全部验收项；
- 现场命令、完整日志、输入/输出 hash；
- 负面测试能抓到故意错误；
- 相关科学/架构/接口/代码/测试文档同步；
- commit 已 push，`origin/main` 与结果 commit 一致；
- 没有未登记 P0/P1。

`TASK_RESULT.json` 不写自引用 commit SHA。它记录 `parent_commit`、控制包 hash、命令和证据 hash；最终 `COMMITS.csv` 由打包器从 Git 历史生成并绑定每个任务结果 commit。

## 6. 当前必须消除的事实

以下任一仍存在即不得 READY：

- CLI 直接手工调用 p1/p2/p3 session 或 Drizzle；
- `PipelineIR/ModuleRegistry/Scheduler/RunContext` 只在单测出现而不在生产调用图；
- Phase1→2→3 通过路径猜测而非类型化 Artifact ID/hash 传递；
- Phase2 默认或 Windows 路径实际串行；Phase3 逐像素双循环串行；
- 资源 gate 只存在于 header/单测、生产从不调用；
- Phase2 接缝测试不调用生产 UPM；
- Phase3 的 Dec 条件、order、unit、BITPIX、provenance、missing tile、FITS checksum 任一与合同不符；
- 文档仍引用缺失 ALG、旧 V5 trace、泛化 422 行 API 占位值；
- 编译有项目源码 warning；
- 审核包缺根摘要、提交账本、完整自有源码、算法文档、验证器或最终真实视图。

## 7. 完成出口

最终只能交付：

- `AstroCS_V6_1_AUDIT_<UTC>_<main12>.zip`；
- 包内 `SUMMARY.json.verdict=READY_FOR_OWNER_REVIEW`；
- `REL-004` 保持 `NOT_STARTED`；
- 固定视图必须来自最终 Windows 32R 和同一 source commit，不得用合成图代替；
- Agent 最终回复只给路径、SHA、source commit、任务统计、Windows/32R 状态、P0/P1 数量和负责人需要看的 6 个视图。

