# 目标架构与验收合同

本文件把“彻底梳理架构”限定为可验收的职责迁移，不授权大爆炸式重写或改变科学公式。迁移顺序必须是合同→适配器→生产接线→删除旧路径；任何阶段都保持可构建。

## 1. 唯一生产路径

```mermaid
flowchart TD
    CLI["astrocs CLI"] --> IR["Pipeline IR + Runtime"]
    IR --> REG["Module Registry"]
    IR --> RES["Thread/Memory/I-O Scheduler"]
    REG --> MOD["Phase1 / Phase2 / Phase3 Modules"]
    MOD --> CPU["CPU Provider ABI"]
    MOD --> ART["I/O + Artifact Store"]
    RES --> MON["Log + Metrics + Resource Gate"]
```

强制边界：

| 层 | 可以做 | 禁止做 |
|---|---|---|
| CLI | 参数、配置、JSONL、退出码、调用 Runtime | include session/CFITSIO/科学内核；手写 phase 顺序 |
| Runtime | IR、依赖、资源、取消、checkpoint、trace | 科学公式；文件格式细节；ISA kernel |
| Registry | descriptor、factory、plan/execute/inspect | 仅保存 metadata 却不可执行 |
| Module | 单一科学职责、正式生产入口、独立验证 | 自己创建全局线程池；从路径猜输入；跨模块调用内部实现 |
| ArtifactStore/I/O | schema/hash/provenance、读取、原子写入 | 科学处理；阶段编排；隐藏全局锁 |
| CPU Provider | 逐 kernel 同 ABI 的 baseline/AVX2/AVX512 | 改变 SCI/ALG 语义；自行决定 Pipeline |
| Monitor | 采样、诊断、门禁、统一日志 | 伪造 worker 数或用请求值代替活跃值 |

## 2. Pipeline IR 最低语义

每个 IR 必须有 schema/version、source commit、preset、nodes、typed edges、inputs、outputs、resource policy 和 deterministic policy。Node 至少声明：

- `node_id`、`module_id`、`module_version`；
- 输入/输出 `port_id` 和 `DATA-*`；
- 输入 Artifact ID，不允许只给裸路径；
- 配置 schema/version/hash；
- execution class：`control|io|cpu_heavy|memory_heavy`；
- parallel axes、requested work、estimated memory；
- error/cancel/checkpoint policy；
- 预期 provider kernel IDs。

IR 校验必须在执行前发现未知模块、缺端口、多 producer、未生产输入、schema/unit/coordinate 不匹配、DAG cycle、heavy+serial、资源超预算。定义了但永远无法触发的错误码视为失败。

## 3. Module descriptor 与生命周期

Descriptor 的机器字段必须和文档字段来自同一结构化源：

`describe → validate_config → plan → create → execute → inspect → destroy`

要求：

- `plan` 不修改输入，输出工作量、内存、I/O、并行轴和 kernel 请求；
- `execute` 只使用 Runtime 提供的 lease/context/artifacts；
- `inspect` 返回结构化诊断，不重新执行科学计算；
- ownership 和异常边界在 C ABI/C++ facade 两侧明确；
- cancel 后所有 lease、file handle、temporary artifact 可回收；
- module ID/version/ABI 与实际装载库和 trace 一致。

## 4. Artifact 连续性

Artifact 是数据对象，不是文件名。最低字段：

| 类别 | 必需字段 |
|---|---|
| 身份 | artifact_id、role、schema/version、hash、size |
| 数值 | dtype、shape、unit、invalid/NaN、precision |
| 坐标 | frame、projection/order/WCS 或明确 none |
| 生产 | producer node/module/version、source commit、run ID |
| 血缘 | input artifact IDs/hashes、config hash、profile ID |
| 存储 | URI/path、atomic state、created UTC、retention |

Phase1→2→3 验收不是“日志里顺序出现三个 phase”，而是 observed trace 中：P2 每个输入 Artifact 的 producer 是本 run 的 P1 节点；P3 source Artifact 的 producer 是本 run 的 P2 writer。任何篡改 hash/unit/schema/producer 后必须在消费前失败。

## 5. 调度、预算和并发

- 全进程只有一个 CPU work pool 和一个原子 ThreadBudget；I/O executor 数量有限。
- Lease 是可移动 RAII 对象，原子 reserve，析构/失败/cancel release；不得只是返回一个整数。
- Scheduler 只对 ready nodes 并发；Node 内并行和 Node 间并行共享同一预算。
- memory reservation 在启动 node 前完成；超过预算进入 backpressure，不能靠 OOM 发现。
- RunContext 的 artifact/log/metric/checkpoint 容器必须同步；不得返回可能失效的内部指针。
- 并发测试至少覆盖 2 核 diamond DAG、嵌套并行、失败、取消、异常、恢复、artifact 冲突和 TSan。

## 6. 静态图与运行图

同一结构化 IR 生成 JSON、DOT/SVG 和 L0 简图。运行 trace 另含实际：start/end、status、artifact hash、provider、workers、CPU/memory/IO、binary/module build ID。

`check_pipeline_trace` 必须双向集合比较：

1. static node 必须恰有一个 observed terminal state；
2. static edge 必须对应相同 Artifact ID 的 produce/consume；
3. observed 不得出现静态图外的隐藏科学节点；
4. 空 trace、只补 output node、漏失败节点均失败；
5. source/config/profile/module/binary commit/hash 必须一致。

## 7. 兼容适配器退出条件

旧 session 可以短期保留 ABI，但只能薄委托同一 Runtime preset。满足以下条件后删除其内部调度：调用图无 session→kernel 直连；新旧入口产生相同 IR hash；测试只维护一套 production path。AIO PipelineEngine、旧 Stage2 Orchestrator 和 CLI direct Drizzle 不得作为第二条正式路径残留。
