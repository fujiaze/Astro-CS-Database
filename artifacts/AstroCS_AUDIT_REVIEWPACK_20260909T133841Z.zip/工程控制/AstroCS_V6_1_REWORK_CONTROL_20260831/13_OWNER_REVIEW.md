# 项目负责人最终审查说明

负责人不需要逐函数阅读。Agent 只有在审核包验证通过并显示 `READY_FOR_OWNER_REVIEW` 后，才提交以下固定入口：

1. `docs/review/REVIEW.md`：一页结论和导航；
2. `SCIENCE_OVERVIEW.md`：SCI→ALG 的核心公式、单位、假设、适用边界和文献；
3. `PIPELINE_OVERVIEW.md`：真实 P1→P2→P3 Artifact 图与 observed trace；
4. `ARCHITECTURE_OVERVIEW.md`：唯一 Runtime、模块、I/O、资源、CPU provider 边界；
5. `CHANGE_REVIEW.md`：本轮变化、科学/API/Pipeline 影响、原子 commits；
6. `RELEASE_STATUS.md`：门禁、失败、未验证、限制、ACR/GUI 状态；
7. P0/P1 闭环表和独立抽查表；
8. 六张同一 Windows 32R run 的真实固定视图及 sidecar。

## 六张必须视图

- 三块两两/共同 overlap 接缝；
- 最弱背景区域；
- 亮星及其邻域；
- 卫星线/排异代表区；
- support/coverage 边缘；
- Phase3 平面 FITS 固定 WCS 视图。

所有视图固定 center、FOV、STF/stretch、colormap，标 source commit、run ID、input/output hash、seam 指标。合成图可以辅助，但不能替代真实 32R。

## 负责人只需回答

- 科学定义与算法推导是否接受；
- 接缝是否在定量和视觉上均可接受；
- Phase3 投影/WCS/单位是否符合用途；
- 架构边界是否满足未来只注册模块而非全局修改；
- 已知限制是否允许 Alpha 发布；
- `APPROVE ALPHA` 或 `REJECT + 指定问题`。

Agent 无权代填批准。负责人拒绝后新增 finding/task/commit，不改写历史或删除本轮失败证据。
