# AstroCS AGENTS.md（建议替换正文）

中文工作。先读根 `AstroCS_ENGINEERING_CONSTRAINTS.md`、memory、当前控制包和相关 SCI/ALG/DATA/API/MOD/TEST；保持定义→算法→数据/接口→代码→测试一致。

只在 `main` 做原子 commit 并立即 push；不建分支、不改写历史、不混入无关重构。未现场验证不得 PASS，历史报告和 Agent 自报不算证据。

当前 Alpha 仅纯 CPU amd64；ACR 保留但不接生产。任何持续≥10秒的 CPU-heavy 生产节点在可用核≥2时必须由统一 Runtime 多 worker 执行，并自动记录 CPU/worker/内存/I/O；低利用率、单线程或异常内存增长是失败。ISA/workers/block 由 benchmark profile 决定；无 profile 用 baseline ISA，但仍并行。

Linux 2c2g 连续完成文档、静态、clean build、小合成、sanitizer和资源小测；Fatduck 在线后完成 MSVC、benchmark、真实数据、一次32R和最终视图。Windows 离线只标 `WAITING_WINDOWS`，继续全部 Linux 工作；除最终发布决定外不设人工停点。

CLI 是唯一产品入口；CLI→Pipeline Runtime→Registry→Module→CPU/I/O。Phase1/2/3 必须用类型化 Artifact 传递；Phase3是 HiPS球面→平面FITS。未来 GUI 只驱动 CLI。

控制包 task/依赖/checklist 不得删改或放宽；每 task 留命令、日志、hash、结果、commit/push证据。审核包严格白名单，不含历史、data、build、cache和大文件。Agent最多声明 `READY_FOR_OWNER_REVIEW`，不得批准发布。
