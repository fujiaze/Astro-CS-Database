# 纯 CPU Provider、Benchmark 与资源利用合同

## 1. 首发边界

- 仅 amd64；生产后端为纯 CPU。
- ACR 保留源码/合同/独立测试，但不注册、不链接到 production graph，不作为首发 gate。
- 对外科学接口唯一；baseline/AVX2/AVX512 是内部 provider，不是三套算法。
- 没有 benchmark 时选最低 ISA 的 baseline provider，但仍用 Runtime lease 多线程。

## 2. Provider ABI

每个 provider 至少导出：ABI/version/build ID、feature requirements、kernel table、self-test、create/destroy/execute。Kernel descriptor 含 ID、dtype、alignment、size domain、determinism、scratch estimate、parallel axis 和 SCI/ALG/TEST ID。

要求：主 CLI/Runtime 使用保守 amd64 flags；AVX2 与 AVX512 flags 只作用对应 shared library/DLL。通过 link map 和反汇编检查主程序无高级 ISA 泄漏。Loader 在执行 provider 代码前核验 CPUID+OSXSAVE/XGETBV；不凭型号白名单。

## 3. 有效 CPU 与配额

Linux 有效核数取 `online ∩ sched_affinity ∩ cpuset ∩ cgroup_quota`；Windows 取 processor groups、process affinity 与 Job Object 限额。记录 vendor/family/model/stepping、feature bits、XCR0、cache/NUMA、逻辑可用核、配额 signature。模块不得直接以 `hardware_concurrency()` 决定 worker。

## 4. Benchmark 协议

命令：

```text
astrocs benchmark cpu --quick|--full --output cpu_profile.json --events-jsonl
astrocs benchmark verify-profile cpu_profile.json
```

固定流程：

1. 探测能力/配额并加载可安全执行的 providers；
2. 每 provider 每 kernel 先跑 correctness/self-test，失败者永久剔除本 profile；
3. 测 memory copy/read/write/triad，形成带宽上限；
4. 每代表 kernel 测 small/medium/large、workers `1..available`、候选 block/tile；
5. 3 次 warmup、至少 7 次 measure，保存全部 wall/CPU/cycles（可得时）、throughput；
6. 以 median/MAD 选择，验证重复测量稳定性；
7. AVX512 相对 AVX2 提升不足 3% 时优先 AVX2；
8. available≥2 且 workload≥10 秒时不得选择 1 worker；若扩展差必须回到实现任务修复；
9. 输出推荐 provider/workers/block 和全部失败/回退原因。

Profile 必须绑定 schema、arch、CPU signature、XCR0、OS ABI、quota、runtime/provider build IDs、source commit、benchmark binary hash 和 UTC。任一不匹配时逐 kernel 回退 baseline并记录原因。

## 5. 全局预算

- 全进程一个 CPU pool；Lease 原子 reserve/release，嵌套计算共享配额。
- `sum(active node leases) <= effective logical CPUs`；不得 Node 间和 OpenMP 各自开满。
- OpenMP 若保留，只能作为 provider 内实现并显式使用 lease size；dynamic/nested 关闭并记录实际 team。
- 小于 5 秒的小工作可串行；threshold 必须由 benchmark/profile 产生，不硬编码 CPU 型号或核数。

## 6. 强制资源采样

每个 `cpu_heavy|memory_heavy` node 由 Runtime 自动启动监测，输出：

| 文件 | 必需内容 |
|---|---|
| `resource_samples.csv` | elapsed、phase、process/system normalized CPU、active/runnable workers、RSS/PSS/commit、faults、read/write、queue、lock wait、progress |
| `resource_summary.json` | active window、mean/p50/p95/peak、memory slope、I/O、bandwidth、worker balance、bottleneck、gate verdict |
| `worker_balance.csv` | worker ID、active/idle/wait、work units、CPU time、bytes、exceptions |

`normalized CPU=进程 CPU / 当前已分配有效 CPU 容量`，100% 表示分配给 AstroCS 的所有核用满。不得用请求 worker 数替代 active worker，不得只保存单点峰值。

## 7. 门禁

CPU-heavy active window ≥10 秒且 available≥2：

- active worker p50 ≥2；
- normalized CPU p50 ≥90%；
- normalized CPU mean ≥85%；
- 无单 worker 持续占据绝大多数 work；
- 无未解释持续锁/I/O等待；
- RSS/commit 无无法解释的正斜率；
- 无 oversubscription、swap/OOM 或反复打开同一文件。

memory-bound 只有实际带宽 ≥ 本机 benchmark 的 80% 且检查过布局/搬运/锁后才允许分类；它不豁免 worker 与内存增长检查。短 I/O 串行只能是 <5 秒或占总 wall <5%。first-10s fast fail 和 final gate 均必须改变正式退出状态。

## 8. 必需负面测试

- 强制单 worker 跑 ≥10 秒，资源门失败；
- 人工加全局锁，分类为 lock contention 并失败；
- 制造负载不均，worker balance 失败；
- 制造缓慢泄漏/缓存不受控，memory slope 失败；
- 伪造 profile/CPU signature，安全回退；
- AVX2/512 correctness 故意错误，候选在计时前被剔除；
- 两个并发 heavy node 请求满核，总 lease 不超配额。
