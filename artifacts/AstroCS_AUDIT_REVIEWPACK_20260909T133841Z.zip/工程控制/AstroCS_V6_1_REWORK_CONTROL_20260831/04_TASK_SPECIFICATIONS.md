# V6.1 逐任务执行规格

本文件与 `03_REWORK_TASK_LEDGER.csv` 同为强制规范。Agent 不得把一个任务拆成多个无编号提交，也不得把多个任务合成一个提交。所有路径均以仓库根为基准。

## A. 通用任务模板

每个任务开始前：

1. `git fetch origin --prune`，确认 `HEAD == main == origin/main`、当前仅 main、工作区无来源不明变化。
2. 将唯一台账中本任务改为 `IN_PROGRESS`；任何时刻只允许一个 IN_PROGRESS。
3. 写 `evidence/v6_1_rework/tasks/<TASK-ID>/PLAN.md`：需求、现状证据、影响文件、科学影响、风险、验收命令。
4. 只修改 scope 内文件。发现外部变化时记录并停止覆盖，不自行 stash/reset。
5. 每个命令必须有 timeout，stdout/stderr 写独立日志；失败日志不得删除或用成功重跑覆盖。
6. 写 `TASK_RESULT.json`，包含 `parent_commit`、`control_sha256`、files_changed、commands、tests、metrics、findings、science_changed。禁止把 parent SHA称作结果 SHA。
7. 运行任务验收和所有受影响测试；失败则状态 FAIL，禁止 commit“假完成”。
8. `git diff --check`，检查无凭据/大文件/build/data。
9. 原子 commit：`<TASK-ID>: <中文目的>`；立即 `git push origin main`。
10. 外部证据记录器把实际 commit 写入 out-of-tree task journal；下一任务起点验证 origin/main 已是该 SHA。

任务 PASS 的证据必须直接执行生产符号或生产 CLI。以下证据一律无效：只搜索字符串、只数引用点、测试中复制生产公式、`CHECK(true)`、人为给 GateConfig 填一个“通过值”、没有输入的 trace checker、旧 commit 日志。

---

## G0：身份与审计重置

### R0-001 冻结当前 main 身份

操作：

- 记录 remote（凭据脱敏）、分支列表、HEAD/main/origin/main、最近 100 个提交摘要、submodule、工作区状态。
- 运行 `git merge-base --is-ancestor b16d422a40fefedbdedab1749cfb8ebc06189736 HEAD`。
- 若三 SHA 不相同，或 b16d422 不是祖先，状态 FAIL；禁止 pull --rebase、merge 或 reset 自行修复。
- 已知外部未跟踪输入逐项写 owner/source/size/hash，不 stage。

产物：`SOURCE_IDENTITY.json`、`WORKTREE_CLASSIFICATION.md`。验收器必须验证 40hex、三 SHA 相等、remote 不含 token。

### R0-002 完整自有源码清单

建立 `SOURCE_INDEX.csv`：path、kind、owner、target、public/private、sha256、required_for_build。解析所有 CMake target/source，逐项证明存在；生成 `TARGET_SOURCE_GRAPH.json/.dot`。

第三方只登记 lock/version/license，不复制进审核源码；自有源码、public headers、CMake、schemas、生产 scripts、SCI/ALG/DATA/API/MOD/TEST 文档必须完整。故意删除一个 CMake source 的 fixture 必须让 checker 非零退出。

### R0-003 本轮证据与台账

- 新建 `evidence/v6_1_rework/`，不修改 `evidence/refactor/` 历史。
- 原样复制本包 ledger，保存控制包和 ledger SHA。
- 实现 `tools/quality/validate_task_ledger.py`，状态仅允许 NOT_STARTED/IN_PROGRESS/PASS/FAIL/BLOCKED/WAITING_WINDOWS/WAITING_DATA。
- 依赖不全 PASS 时当前任务不得 PASS；唯一例外是 Owner 任务保持 NOT_STARTED。

### R0-004 已知问题复现

逐项执行 F-001..F-040。每项写最小复现命令、stdout/stderr、文件/符号、结果。无法因审核包缺文件而复现时，必须在完整 repo 复现；不能把“没找到”直接 CLOSED。输出 `KNOWN_FAILURES_BASELINE.json`，所有 40 项状态只能 REPRODUCED、NOT_REPRODUCED_WITH_EVIDENCE 或 SOURCE_CHANGED。P0/P1 不允许靠改文档关闭。

---

## G1：治理与不可作假的机器门

### GOV-001 任务—commit 绑定

定义：`parent_commit` 是任务开始 SHA；`result_commit` 只能由最终打包器从 `git log --first-parent main` 提取。`COMMITS.csv` 字段固定为 task_id、parent_commit、result_commit、commit_subject、committed_utc、pushed_origin_main、changed_paths_sha256、task_result_sha256。

验证：每个 commit subject 只出现一个 task ID；parent/result 形成连续链；每个 result commit 是最终 source commit 祖先；origin_main 证明存在。故意篡改一个 SHA、交换两个任务、缺一个 push 均必须失败。

### GOV-002 Gate 状态机

修复上轮 `REVIEW_PENDING` 和“依赖未过但 release PASS”漏洞。validator 必须输出第一个和全部错误；不允许改 dependency 来使 ledger 通过。负面 fixture：非法状态、两个 IN_PROGRESS、PASS 依赖 WAITING、环、缺任务、REL 提前 PASS、task count 不符。

### VER-001 版本

根 `VERSION` 改为 `0.10.0-alpha.2`。CMake project 数字版本可为 `0.10.0`，显示版本、CLI、provider ABI manifest、profile、FITS provenance、release docs和包名必须从 VERSION+commit派生。扫描自有生产源码中的 `0.1.0`、旧 alpha.1、手写 commit/run_id；测试 fixture 可登记豁免。

### CHK-001 Production reachability

必须基于 `compile_commands.json`、AST/符号/link map 构建生产可达图，至少覆盖 CLI→Runtime→Module→kernel/I/O。禁止只 grep。输出 JSON/DOT 和下列 machine assertions：

- CLI handler 只能调用 public Runtime、Benchmark、Test、Verify API；
- session/科学内核/I/O内部 symbol 从 CLI 不可达；
- 生产只有一个 scheduler owner；
- ACR symbol/target/module 从默认产品不可达；
- legacy wrapper 如保留，只能通过 test registry/preset。

fixture 必须能抓到 CLI 新增一次 `hp_drizzle_run_hips` 直连和 dead Runtime。

### CHK-002 Pipeline graph/trace

命令必须显式接收 `--ir`、`--module-index`、`--trace`。任一文件缺失或 trace 零节点直接 FAIL。逐项比较 node ID、module ID/version、edge、port、DATA schema、unit、coordinate、artifact ID/hash、producer/consumer、resource class、provider、workers、status、start/end。禁止扫描任意 build 目录碰运气。输出完整 diff；negative fixtures 覆盖少节点、换 artifact、换单位、隐藏节点、空 trace。

### CHK-003 Serial-heavy/reachability

从生产调用图定位每个 cpu_heavy node 的实现和编译 target，核对：并行轴、lease 调用、compile definition、OpenMP/std::thread实现、MSVC/Linux实际路径、resource gate caller。扫描固定 workers=1、hardware_concurrency 模块自取、裸 thread pool、serial pixel/sample loop、全局锁。allowlist 仅允许 <5 s 或总耗时 <5% 的 I/O/metadata，必须含 owner/reason/expiry/test。负面 fixture 使用当前 Phase2 宏关闭、P3 双循环和无 gate caller，三者必须被抓。

---

## G2：唯一 Runtime、类型化管道和模块注册

### RT-001 公共合同

在 public headers 冻结以下接口：Runtime create/run/cancel/inspect；ModuleDescriptor/ModulePlan/IModule；typed Port/DataArtifact；ThreadBudget/ThreadLease；logger/metrics/checkpoint。每个参数写 ownership、nullable、lifetime、thread-safety、blocking、unit/schema。C ABI 不抛异常，C++ 边界返回 Result/Error。

不得把算法实现塞进 ABI；不得让模块拿全局 scheduler。ABI layout test 必须在 GCC/Clang/MSVC 验证 size/align/offset/version。

### RT-002 ThreadBudget

实现共享原子 token/semaphore：`acquire(min,max,policy)`、RAII release、取消/异常自动归还。Scheduler 自身 worker 与节点内部 work 必须使用同一总预算，避免 N 个节点各获 N。测试同时启动两个 heavy node，各请求全部核，断言全程 sum(active)<=budget；注入异常/取消后 available 恢复。1 worker 只允许 available=1 或测试 reference。

### RT-003 RunContext

日志/metrics 使用线程安全 sink；ArtifactStore 的并发读、唯一 producer 写和 duplicate 冲突确定；checkpoint 顺序可追溯；取消 atomic。禁止暴露容器裸引用和返回可能因并发插入失效的 map 指针。TSan 测多个 node 并发 log/store/metrics/cancel。

### RT-004 PipelineIR

使用真正 JSON parser+schema，不写脆弱字符串解析。IR 固定 schema/version、nodes、ports、artifacts、resources、config reference、outputs。validate 接受完整 ModuleRegistry，必须触发 UNKNOWN_MODULE、MISSING_PORT、DATA_MISMATCH、UNIT_MISMATCH、COORDINATE_MISMATCH、DUPLICATE_PRODUCER、CYCLE、SERIAL_HEAVY、UNPRODUCED_OUTPUT。每个错误有 fixture。

### RT-005 ModuleRegistry

Descriptor 必须含 module ID/version/ABI、factory、plan、execute/inspect、ports、config schema、execution class、parallel axes、memory model、SCI/ALG/DATA/API/TEST。注册时校验完整合同、重复 ID/端口、heavy+serial、ACR production。registry 导出用 JSON library正确转义。至少一个真实 Phase1、一个 Phase2、一个 Phase3模块通过 factory 执行，不接受只注册 metadata。

### RT-006 Scheduler

IR 构图后按依赖就绪调度；CPU pool、有限 I/O executor、backpressure和memory reservation统一。NodePlan先估计work/memory，再取 lease。失败只标失败节点，其依赖 SKIPPED；独立节点策略明确。状态输出必须带 node ID，不能只给无名 vector。测试 DAG并发、diamond、失败、取消、恢复、预算、内存回压、确定性。

### RT-007 ArtifactStore

Artifact descriptor 至少含 ID、role、schema/version、unit、coordinate、dtype/shape、validity、path/URI、size/hash、producer node/module/version、source commit、input IDs/hashes、created UTC。消费前验证完整；禁止从文件名/目录猜角色。P1 output 必须成为 P2 input，P2 HiPS 成为 P3 input。篡改 path、hash、unit、schema 或换 producer 均硬失败。

### RT-008 CLI 接线

拆分 1604 行 main：parser、commands、JSONL formatter、runtime client、benchmark client、test client、verify client。CLI 不 include session、CFITSIO、AIO内部、Drizzle或科学 header。`run --phases` 解析 preset→IR→Runtime，一次运行的 P1/P2/P3 通过 ArtifactStore连续。单 phase命令也是相同IR子图，不是第二条路径。现有 `cmd_drizzle` 只能选择测试 preset；不得手工重读 FITS。

验收以 CHK-001 调用图和实际 observed trace为准，不以文件行数单独判定。

### RT-009 运行图

每个正式 preset 生成 static JSON/DOT/SVG；每次 run 生成 observed JSON/DOT/SVG 和 sidecar（IR hash、source commit、profile ID、input manifest hash）。L0 简图从相同 JSON 派生。必须能从图看到 Artifact 传递、节点耗时、provider、workers、状态。路径脱敏。

---

## G3：纯 CPU provider、Benchmark 与资源门

### CPU-001 Provider 构建

建立真实 shared-library targets：baseline、avx2、avx512。CLI/Runtime以最低 AMD64/SSE2编译；高级 flags只作用于对应 provider target。每个 provider manifest 声明 ABI、build ID、具体 feature bits、kernel entries/hash。AVX2+FMA分别声明；AVX512声明 F/DQ/BW/VL实际使用子集。

允许某 kernel 只有 baseline；路由逐 kernel fallback。禁止三份复制算法：共享模板/生成源，但每条路径必须编译成不同目标并运行 self-test。检查最终 link map和反汇编，证明 CLI baseline无高级 ISA泄漏。

### CPU-002 能力/配额

Linux：CPUID、OSXSAVE/XGETBV、sched affinity、cpuset、cgroup v1/v2 quota取交集。Windows：processor groups、process affinity、Job Object CPU rate/限制。输出 vendor/family/model/stepping、features、XCR0、cache/NUMA、logical_available、quota signature。不得用 CPU 型号白名单或仅 hardware_concurrency。

### CPU-003 Benchmark

命令：`astrocs benchmark cpu --quick|--full --output profile.json --events-jsonl`。固定步骤：能力→provider correctness→memory copy/read/write/triad→每代表 kernel small/medium/large→workers 1..available→block/tile→3 warmup+7 measure→median/MAD→winner。错误候选不计时；AVX512提升<3%选AVX2；worker增加收益<3%可少选但 available≥2 heavy不得选1。保存全部原始候选，独立 `--verify-profile` 复读。

### CPU-004 路由

Runtime按 kernel ID+workload class读取 profile；核对 arch/CPU/XCR0/OS ABI/quota/runtime/provider/benchmark schema/build IDs。无 profile、stale、损坏或 unsupported provider时逐 kernel回 baseline；保守意味着最低 ISA，不意味着单线程。记录 provider选择、fallback reason、workers/block和self-test hash。

### MON-001 监测

每个 heavy node自动生成 `resource_samples.csv`、`resource_summary.json`、`worker_balance.csv`。样本含 elapsed、process/system CPU、active/runnable workers、RSS/PSS/commit、fault、read/write、queue depth、lock wait、progress。分 init/active/flush；统计 mean/p50/p95/peak/slope。Windows/Linux统一“100%=全部分配核用满”的 normalized 口径。采样开销用真实 wall总开销计算，不得把每样本平均再除总wall。

### MON-002 门禁

生产 Runtime在 first 10 s和结束时调用 gate；失败返回统一 RESOURCE exit code并输出 diagnosis。CPU-heavy active window≥10s：worker p50≥2（available≥2）、CPU p50≥90%、mean≥85%。memory-bound只有带宽≥80%本机 benchmark且已检查搬运/布局才可解释；I/O串行仅短于5s或总时长<5%。禁止仅 emit event不改变退出状态。

### MON-003 2核验证

Linux 2c2g为每个代表 heavy kernel生成刚好能持续10–30s的合成 workload，避免OOM。记录真实曲线，不人工构造 GateConfig。分别验证单核负fixture会失败、多核生产会通过、锁退化/不均衡可被分类。任何实际低利用先修源码，不放宽阈值。

---

## G4：Phase1

### P1-001 模块迁移

注册 calibration、cosmetic、star/PSF、WCS/platesolve、photometry、noise/SNR、drizzle/writer模块。每个节点声明标准 DATA端口和执行类。Session如暂保留只能是兼容 adapter，内部必须委托 Runtime，不得拥有第二调度顺序。

### P1-002 生产 Oracle

所有测试通过 Registry/Runtime或正式 CLI执行：

- Calibration：常量/梯度/负值/NaN、bias/dark/flat、u16/f32/f64；
- stars/PSF：孤立/重叠/饱和/边缘/纯噪声，completeness/FP/centroid/FWHM；
- WCS：已知星场、扰动初值、roundtrip、无解；
- photometry：已知flux/background/PSF、饱和拒绝；
- noise：Poisson+read noise Monte Carlo和解析variance/ivar；
- Drizzle：constant/impulse/subpixel/rotation/pixfrac/RA wrap/support/flux。

Oracle独立实现，不调用待测 kernel；seed、容差、单位预冻结。

### P1-003 Drizzle路径

删除 CLI 的 `spawn_frame_from_fits`、直接 CFITSIO header解析和 `hp_drizzle_run_hips` production call。必要的 FITS→Artifact 由 I/O module完成，Drizzle只消费类型化 frame。test wrapper选择IR preset。调用图和negative fixture证明无法绕过。

### P1-004 联合门

同一次 current commit运行所有P1 Oracle和≥10s Drizzle/calibration资源 workload；science summary和resource summary互相引用 run ID。数值对但资源失败仍FAIL，资源好但数值错也FAIL。

---

## G5：Phase2与接缝专项

### P2-001 Coverage/Sampler

删除 `P2_ENABLE_OPENMP` 默认关闭和 `_MSC_VER` 排除造成的生产串行。优先使用Runtime tile/work queue；如保留OpenMP必须 `num_threads(lease.size)`、nested off。每worker独立reader/CFITSIO handle，按预计有效sample负载分块。1-worker只作reference；Linux/MSVC N-worker实测调用同生产符号。

### P2-002 UPM

所有 per-observation、per-control、per-frame CG工作从Runtime lease执行；模块不得hardware_concurrency。规约使用worker-local+固定树合并，定义determinism class。避免每thread K大小重复数组导致2c2g OOM；NodePlan报告内存。取消点位于迭代/块边界，异常归还lease。

### P2-003 生产接缝 Oracle

生成三块真正的mini FITS/HiPS输入，含：常量、线性和低阶平滑背景；不同加性偏移；恒星和扩展结构；mask/low support；一个断连分量。通过正式 `astrocs phase2 run`/IR调用 production sampler+UPM+persist+apply+integrate。

预先冻结并报告每 overlap：median difference、robust RMS、gradient residual、source flux ratio、extended-structure residual、zero-support数量；UPM amplitude/smoothness/gauge/component。必须证明 before→after下降且源不被拟合。测试不得写入真 correction，也不得调用生产 UPM内部函数作Oracle。

### P2-004 排异/积分

每种方法以正式 kernel执行 cosmic ray、hot pixel、satellite streak、真实星核、低样本、NaN/Inf/zero/negative ivar。AUTO必须输出已解析方法+reason。Integration检查weighted mean/variance/ivar/support、frame identity和all-rejected。拒绝图/计数是Artifact并可追溯。

### P2-005 Block/IO

预算生成block plan，禁止35GB稠密cache。小问题full reference与block结果比较；所有边界无重复/遗漏。压力测试峰值RSS≤plan容差，worker-local reader，无共享fitsfile写；单writer/有序提交。

### P2-006 Canonical Pipeline

IR至少含 coverage→sample→upm_fit→upm_apply→reject→integrate→write，各端口DATA/单位/Artifact ID完整。ACR不注册不链接。Observed trace必须逐节点匹配static graph，且输出 mosaic/signal/support/ivar/variance/UPM/rejection诊断的命名无模糊weight。

### P2-007 联合门

在2c2g运行production seam workload≥10s，保存科学+资源证据。CPU不达门时不得因seam数值好而PASS。Windows最终还要同一test registry复验，但本任务先关闭Linux实现缺陷。

---

## G6：Phase3 HiPS球面→平面FITS

### P3-001 科学与算法冻结

先修文档再修代码：明确 alpha支持的HiPS版本/子集、NESTED、ICRS、TAN、单位、pixel center、CD parity、order、nearest/bilinear、coverage、NaN/missing、BITPIX、最大资源。若排除距极点5°，条件写为 `abs(dec)<=85°`；不允许SCI/API/WCS/session三套条件。

从SCI连续定义推导ALG离散算法、误差、复杂度、tile并行轴和每worker cache。引用 `14_PRIMARY_REFERENCES.md` 的官方HiPS、HEALPix、FITS-WCS、FITS checksum来源，逐条说明采用/项目自定义之处。

### P3-002 properties/order/unit

解析实际 HiPS properties：order、tile width、frame、format、dataproduct、unit/creator/manifest。`order_sel` 上限来自输入实际order，且实际 reader/resampler使用该order；禁止仅写metadata。BITPIX/max memory来自request+NodePlan；不支持输入明确错误。BUNIT来源于输入合同，unknown按SCI决定拒绝或原样UNKNOWN，绝不Jy/beam默认。

### P3-003 并行resampler

按输出tile/row-band生成work units，每worker独立sampler和bounded tile cache，输出buffer不重叠；Runtime lease调度，最后单writer有序提交。删除production串行全图双循环。小图可串行阈值由benchmark profile确定且<5s；大图available≥2必须N worker。测试1/N结果、取消、missing tile、cache边界、TSan和资源。

### P3-004 独立Oracle

不要在测试里重写普通矩形bilinear来冒充HEALPix。使用独立高精度球面生成器/标准库建立常数球、解析球面函数、impulse、跨tile连续场、RA 0/360、旋转TAN、边界missing/NaN。生产nearest/bilinear逐pixel对照独立WCS+HEALPix reference。若自定义“bilinear”，必须数学定义邻点和权重并验证非负、和1、连续性；否则改用经验证的HEALPix插值。

### P3-005 FITS

- request `-32/-64` 必须真实决定BITPIX和buffer；
- 写CRPIX/CRVAL/CD/CTYPE/CUNIT/BUNIT/coverage/provenance；
- SWVER、run_id、source artifact/hash、order/sampler、missing tiles全来自Runtime；
- 使用CFITSIO标准 checksum API写/验每HDU，不自创字节和；
- independent reopen读取并逐项比较dimensions、BITPIX、WCS、BUNIT、CHECKSUM/DATASUM、coverage和像素；任何不符返回失败；
- close/flush后fsync文件，再atomic replace，最后fsync父目录；Windows使用可靠replace语义；失败清tmp。

故意篡改BUNIT/WCS/pixel/checksum/coverage的fixture均必须被verify拒绝。

### P3-006 组装

通过Registry/IR执行 source artifact→properties→WCS plan→parallel resample→FITS writer→verify。Session若保留只适配public Runtime。完整合成运行≥10s并同时过科学/资源/trace。此时才能将SCI/ALG/MOD/RELEASE状态由DRAFT/PROTOTYPE改IMPLEMENTED。

---

## G7：文档与质量

### DOC-001 合同图

每份 L1 文档有 front matter：id/version/status/owner/upstream/downstream/source_commit。每个 production MOD必须存在SCI→ALG→DATA→ARCH→API→MOD→source→TEST完整可达链；双向引用一致；ACTIVE不能依赖DRAFT/OBSOLETE/CONFLICT。禁止索引存在但文件不打包。

### DOC-002 当前追溯矩阵

矩阵必须从当前合同、public AST、registry、CMake、test registry和现场evidence生成。工具无默认V5路径，不硬编码claim计数。每行真实检查doc anchor、header symbol、implementation symbol、test executable/case、oracle、evidence hash。故意改函数名/删除测试/换单位均失败。

### DOC-003 API AST与语义

扫描全部安装/导出的public headers，不是3个样本。比较return/param类型、name、const/ref/noexcept/calling convention/visibility、C struct size/align/offset、enum值。接口语义表逐函数填写单位、范围、nullable、ownership、lifetime、mutation、blocking、thread safety、reentrancy、error、determinism、precision和test；禁止 `per header` 等占位。`void free()`不得有“return code 0”。

### DOC-004 模块README

每个Registry production module一份README：做/不做、输入输出DATA和单位、SCI/ALG/API/MOD/TEST链接、public header/核心symbol、execution class/parallel axis/lease/determinism、memory/cache/ownership、error/cancel/checkpoint、synthetic command、限制。checker以registry为源，不能手工写“只需5个”。

### DOC-005 L0

`REVIEW.md`只链接SCIENCE/PIPELINE/ARCHITECTURE/RELEASE_STATUS/CHANGE_REVIEW。内容由当前 ledger/trace/evidence生成；不得互相矛盾。每个结论链接L1/L3 hash。Phase状态逐一 IMPLEMENTED/EXPERIMENTAL/NOT_IMPLEMENTED；ACR DORMANT；GUI NOT_INCLUDED。

### DOC-006 注释/可读性

按模块小范围整理，禁止全仓格式化。拆薄CLI；删除任务号/审核轮次/旧版本故事/逐行复述/虚假thread-safe注释；保留数学原因、单位、边界、所有权、线程约束、非显然优化和合同ID。修复模糊变量/死代码/危险test shell。每批仅修改一个模块并由本任务commit（若范围过大，先在ledger追加经批准子任务，不混改）。

### QA-001 零警告与静态分析

GCC Release、Clang Debug全自有production targets启用合理 `-Wall -Wextra -Wpedantic -Wconversion` 分层；第三方只target-local隔离。修复monitor格式类型问题。运行clang-tidy/cppcheck或等价工具，输出全部发现，P0/P1清零。禁止`-w`作用自有源码或宽泛suppression。

### QA-002 Sanitizer

ASan+UBSan跑所有所有权路径和pipeline；LSan必须开启，环境不支持时换可支持runner，不能 `detect_leaks=0` 后称闭合。TSan定向跑Runtime、ArtifactStore、P2/P3 worker、CFITSIO handle策略。suppression逐项有第三方来源/owner/expiry；自有race/leak不豁免。

### QA-003 依赖/SBOM

锁定nlohmann/cfitsio/zlib等版本、来源、license、patch；生成CycloneDX/SPDX或等价SBOM。记录编译器/SDK/CMake/flags、provider build IDs、source commit。双平台release package可从清单重建。

---

## G8：Linux控制节点

### LNX-001 Clean build

在全新临时目录分别GCC Release、Clang Debug配置/构建，不复用旧CMake cache。构建完整CLI、providers、tests。保存configure/build/test logs、compile_commands、link map、`/usr/bin/time -v`。任何自有warning失败。

### LNX-002 全合成

`astrocs test synthetic --group all` 必须调用真实test registry并生成machine summary；同时分别运行模块测试，防聚合器漏项。报告每test实际 executable/production symbols/seed/tolerance/duration/hash；无NOT_RUN、无CHECK(true)、无旧日志。

### LNX-003 Sanitizer复验

使用LNX-001相同source commit的新build目录现场运行QA-002矩阵。证据绑定binary hash和commit。任何 sanitizer error 不允许通过重跑消失。

### LNX-004 2c2g资源与恢复

运行P1/P2/P3各至少一个10–30s合成heavy节点；同时测试cancel、checkpoint/resume、低内存backpressure。保留resource samples/summary/worker balance，验证normalized CPU门。Linux不跑32R。

### LNX-005 少量真实辅助

在Fatduck在线时只拷三块各1个R和必要masters，重算hash，运行最小P1/P2/P3 smoke；不把数据入库/审核包。若离线，保存SSH/DNS/timeout证据，TASK_RESULT的实验状态写NOT_RUN_EXTERNAL_OFFLINE，但任务可完成“尝试与诚实登记”；不得把它汇总为真实数据PASS。Windows WIN-004仍为强制真实门。

---

## G9：Windows/Fatduck

所有SSH调用有connect/command/idle timeout并流式日志。离线时WIN任务保持WAITING_WINDOWS，Agent继续Linux；Linux完成后定期重试，但不得自行放弃或用Linux代替最终Windows门。

### WIN-001

只读探测后拉取GitHub `main`，确认commit与Linux最终候选相同。在全新目录用MSVC Release/Debug完整构建CLI/providers/tests；不复制Linux binary/build。

### WIN-002

运行full benchmark，证明实际DLL被loader加载；correctness失败候选剔除。保存profile、raw candidates、CPU/XCR0/Job/affinity、memory、provider hashes。

### WIN-003

运行同一production合成registry和资源门；容差来自TEST合同，不在看结果后放宽。Phase2/3 active worker和normalized CPU达标。

### WIN-004

使用三板块各1R+masters，验证完整Artifact链、P1输出、P2 overlap/UPM、P3 FITS、资源和无泄漏。冻结最终candidate commit/profile/config。

### WIN-005

严格使用32R `11+11+10` hash manifest。最终候选成功全链只跑一次；失败可修复明确原因后重跑，但必须保留失败并说明为何第二次必要。验证每帧贡献、artifact identity、seam指标、UPM、rejection、support、资源曲线、无异常内存增长。

### WIN-006

从WIN-005真实产物生成锁定视图：三块overlap、最弱背景、亮星、卫星线、support边缘、Phase3 FITS。固定center/FOV/stretch/colormap；每张sidecar含source commit、input/output hash、viewer config、seam metrics。合成图只能单列为synthetic，不得进入owner视图。

---

## G10：发布与回包

### REL-001

生成Linux amd64和Windows amd64 alpha.2。每平台唯一用户入口`astrocs`/`astrocs.exe`；内部含baseline及通过正确性验证的AVX2/AVX512 provider、default IR、schemas、licenses、SBOM、README、checksums。干净临时目录install/run/doctor/profile verify/small synthetic smoke。无GUI、ACR、数据、build、历史。

### REL-002

重新运行全部合同、AST、registry、reachability、IR/trace、serial/resource、version、warning、sanitizer、release layout check。`FINDINGS.csv` P0/P1必须CLOSED且有resolution commit/evidence；Windows/32R必须PASS。L0从这些证据生成，不人工抄状态。

### REL-003

严格执行 `12_AUDIT_PACKAGE_SPEC.md`。打包前和解包后各跑 `validate_return_audit.py`；完整自有源码必须能在新目录configure，算法文档必须存在。大产物只manifest引用，小型真实视图入包。包失败不得手工删几项后绕过validator。

### REL-004

Agent不得修改为PASS、不得代签。负责人读取L0、P0/P1 closed表、Phase2 seam、Phase2/3资源和6张真实视图后明确APPROVE/REJECT。批准后才由负责人授权发布标记。
