# V6.1 返工审核包白名单规范

## 1. 唯一交付

文件名：`AstroCS_V6_1_AUDIT_<UTC>_<main12>.zip`。只能由仓库中的 `scripts/package_audit.py` 从显式白名单生成；禁止手工压整个仓库、复制历史包后删文件或把绝对运行目录直接加入 ZIP。

## 2. 根目录必含

```text
00_README.md
SUMMARY.json
SOURCE_IDENTITY.json
SOURCE_INDEX.csv
TASK_LEDGER.csv
COMMITS.csv
FINDINGS.csv
TEST_SUMMARY.csv
RESOURCE_SUMMARY.csv
TRACEABILITY_MATRIX.csv
LARGE_ARTIFACT_MANIFEST.csv
PREVIEW_MANIFEST.csv
docs/review/*
docs/contracts/*
docs/algorithms/*
docs/modules/*
source/CMakeLists.txt
source/cmake/*
source/cli/*
source/include/*
source/lib/*
source/tests/*
source/tools/*
source/VERSION
source/AGENTS.md
source/AstroCS_ENGINEERING_CONSTRAINTS.md
evidence/gates/*
evidence/failures/minimal/*
evidence/science/summary/*
evidence/resources/summary/*
evidence/build/summary/*
previews/*
scripts/package_audit.py
scripts/validate_audit.py
MANIFEST.json
SHA256SUMS
```

本轮属于系统重构，必须包含单一 source commit 的完整“自有源码快照”，使审核者能在新目录至少 configure 并核对全部 production/test targets。第三方源码不打包，以 lock/SBOM/license 引用。`SOURCE_INDEX.csv` 每行给 path、kind、owner、target、sha256、size、generated、required_for_build。

## 3. 严禁

- `.git/`、objects、refs、branch/tag/history patch bundle；
- 旧控制包/审核包/归档包；
- 原始 FITS/HiPS/testdata/masters/32R；
- build、CMakeCache、obj/pdb/ilk/exe/dll/so/a、coverage/sanitizer cache；
- 大型 trace 原始流、完整 resource samples、临时/下载/cache/core/dump；
- third_party 可重新获取内容；
- token、密码、SSH key、凭据 URL、真实用户主目录；
- symlink/hardlink、绝对路径、`..`、设备文件；
- 未声明的单文件 >5 MiB 或总 ZIP >25 MiB。

超限必须让打包器失败并输出 size report；Agent 无权放宽。大型数据/产物只写 manifest 引用。允许包内小型合成 fixture、摘要 JSON/CSV 和六张必要真实预览。

## 4. SUMMARY 状态

`SUMMARY.json` 最低字段：schema、version、verdict、source/origin commit、control/ledger hash、task counts、gate status、science/API/pipeline changes、blockers、not_verified、Linux/Windows、32R、findings counts、artifacts、owner_review。

`READY_FOR_OWNER_REVIEW` 的机器条件：

- 除 `REL-004=NOT_STARTED` 外全部 Task 为 PASS；
- P0/P1 finding 全 CLOSED；
- Windows WIN-001..006 PASS；32R PASS；
- source==main==origin/main==所有 final evidence/preview commit；
- blockers/not_verified 为空；owner_review=PENDING；
- Agent 不得输出 ALPHA_RELEASE_APPROVED。

## 5. 提交、测试和资源表

- `COMMITS.csv`：task_id、commit、parent、subject、UTC、paths hash、pushed、origin ancestor、result hash。
- `TEST_SUMMARY.csv`：test_id、module、oracle、production symbol、platform/compiler/provider/workers、seed/tolerance、result、run/evidence hash、source commit。保留 FAIL/NOT_RUN。
- `RESOURCE_SUMMARY.csv`：node/kernel、platform、workload、available/requested/active workers、CPU mean/p50/p95、RSS peak/slope、I/O、wait、bandwidth ratio、bottleneck、gate、evidence hash。
- `FINDINGS.csv`：每个 F-001..040 及新发现，含 severity、文件/符号、证据、Task、状态、resolution commit/evidence。P0/P1 不允许 DEFERRED。

## 6. 预览与大产物

`PREVIEW_MANIFEST.csv` 字段：preview_id、kind、source_kind、source_commit、run_id、input/output hash、center/FOV/stretch/colormap、seam metrics sidecar、file、sha256。Owner 六视图必须 `source_kind=WINDOWS_FINAL_32R`。

`LARGE_ARTIFACT_MANIFEST.csv` 字段：artifact_id、type、platform、redacted run-relative path、size、sha256、source commit、input manifest hash、command/run ID、created UTC、retention、reason omitted。不得只写“在 Fatduck”。

## 7. 打包器流程

1. 读取白名单，不跟随链接；生成 staging；
2. 从 CMake/Registry/test registry 生成并核对 SOURCE_INDEX；
3. 扫禁止路径、扩展名、敏感内容、绝对路径和大小；
4. 生成 SUMMARY/COMMITS/各摘要，不允许手填覆盖；
5. 生成 MANIFEST 和 SHA256SUMS；
6. 在 staging 运行 `validate_audit.py`；
7. 生成 ZIP；在全新临时目录安全解压；
8. `sha256sum -c`、schema、ledger、source completeness、configure smoke、敏感/大小复验；
9. 输出 ZIP path/size/SHA；失败不交付半成品。

审核包可包含验证器源码，但验证器还必须随本控制包提供，避免由被审代码单方面定义通过标准。
