# 文档体系与机器一致性检查

## 1. 四层文档

| 层 | 读者 | 权威内容 | 禁止 |
|---|---|---|---|
| L0 | 项目负责人 | 科学/管线/架构/变化/发布风险摘要 | 复制函数表、要求负责人维护底层实现 |
| L1 | 开发与审核 Agent | SCI/ALG/DATA/ARCH/API/MOD/TEST 合同 | 用代码现状反向定义科学；占位字段 |
| L2 | 模块维护者 | README、并发、所有权、实现边界、测试入口 | 审计轮次和临时调试历史写入生产注释 |
| L3 | 机器与独立审核 | AST、注册表、图、trace、测试、资源、hash | 手改生成证据；从历史 V5 表抄结论 |

单一权威：SCI=科学公式，ALG=离散方法，DATA=数据语义，源码 AST=真实签名，Pipeline IR=拓扑，Registry=模块集合，现场 evidence=测试状态。L0 只引用这些来源，不维护第二套真相。

## 2. 合同 front matter

所有 L1 Markdown 使用可解析 YAML front matter：

```yaml
---
id: SCI-P2-UPM-001
version: 1.0.0
status: ACTIVE
owner: astrocs-core
source_commit: <40hex>
upstream: []
downstream: [ALG-P2-UPM-001]
---
```

合法状态：`DRAFT|ACTIVE|EXPERIMENTAL|DEPRECATED|OBSOLETE|CONFLICT`。ACTIVE 不得依赖 DRAFT/OBSOLETE/CONFLICT。ID、文件、索引和双向引用必须唯一一致；索引指向缺文件直接失败。

## 3. 机器检查器必须验证什么

### 3.1 Contract graph

- 从文档 front matter 和 Registry 构图，不用手工白名单；
- 每个 production module 存在 SCI→ALG→DATA→ARCH→API→MOD→source→TEST→evidence；
- 所有 edge 双向一致、无 dangling/duplicate/cycle/非法状态；
- 故意删文档、换 ID、让 ACTIVE 依赖 DRAFT 时非零退出。

### 3.2 Public API/ABI

- 从 `compile_commands.json` 与 install/export target 枚举全部 public headers；
- 使用 Clang AST 比较 namespace、symbol、return/params、const/ref/noexcept、calling convention、visibility；
- C struct 比较 ABI version/size/alignment/offset；enum 比较实际值；
- API 语义表逐 symbol 比较单位、范围、nullable、ownership、lifetime、mutation、blocking、thread safety、reentrancy、error、determinism、precision、test；
- 禁止对 422 行批量填同一 `ADU/pixel/deg per header` 或 `return code 0=OK`；
- 故意改签名/enum/结构体/文档单位时检查失败。

### 3.3 Registry/CMake/link

- Registry 列出的 production module 必须有 target、装载符号、descriptor、README、TEST；
- 每个 production target 的自有源码存在并进入 source snapshot；
- 链接产物中的 provider/module 集合与 Registry 一致；ACR 不得出现在 production list；
- 不能只 grep 名称，必须解析 CMake file-api/compile commands、AST 或实际二进制导出表。

### 3.4 Pipeline static/observed

- 见 `06_ARCHITECTURE_ACCEPTANCE.md`；空 trace 必须失败；
- observed 节点不能由 checker 人工补齐；
- 每条 Artifact edge 校验 ID/hash/schema/unit/producer/consumer；
- source commit、IR/config/profile/module/binary hash 一致。

### 3.5 Serial-heavy/resource reachability

- 从 production entry 到 heavy loops/parallel executor/resource gate 做可达性检查；
- 检查 compile definitions 和实际 link/runtime team，不仅查 header 存在；
- 识别 `_MSC_VER` 排除并行、默认并行宏 OFF、`hardware_concurrency` 自开线程、二维串行主循环、gate 无 caller；
- 运行负 fixture 验证单线程重计算使正式命令非零退出。

### 3.6 Traceability/current evidence

- 当前矩阵由本 commit 的文档/AST/Registry/CMake/test registry/evidence 生成；
- 工具不得默认读 `artifacts/prerelease_v5`，不得硬编码 claim 数；
- 每行包含合同 anchor、header/impl symbol、test case、Oracle、run ID、evidence hash、result commit；
- 旧日志、空文件、人工 PASS、source commit 不匹配均失败。

## 4. 模块 README 固定章节

每个 production module 必须包含：职责/非职责、输入输出 DATA+单位、SCI/ALG/API/MOD/TEST 链接、public header 与核心 symbol、生命周期与所有权、execution class/parallel axis/lease、determinism/precision、memory/cache/I/O、error/cancel/checkpoint、日志/指标、独立 synthetic 命令、已知限制。集合必须从 Registry 自动发现。

## 5. 顶层 L0

`REVIEW.md` 仅链接并摘要：`SCIENCE_OVERVIEW.md`、`PIPELINE_OVERVIEW.md`、`ARCHITECTURE_OVERVIEW.md`、`RELEASE_STATUS.md`、`CHANGE_REVIEW.md`。每个 PASS/FAIL/NOT VERIFIED 指向 task/evidence hash。Phase3 只有 G6 全通过才从 prototype 变 IMPLEMENTED；ACR 固定 DORMANT；GUI NOT_INCLUDED。

## 6. 运行图文档

每个正式 preset 由相同 IR 自动生成 JSON、DOT/SVG；真实 run 再生成 observed 图。文档不得手画与 IR 无关的拓扑。图至少显示 node、module/version、typed ports、Artifact IDs、依赖、execution class；observed 图增加状态、耗时、provider、workers和资源判定。

## 7. 代码注释与可读性

注释解释“为什么”：数学来源、单位、边界、所有权、线程约束、规约次序、数值近似和非显然优化。删除逐行复述、旧版本故事、Task/审核轮次、虚假 thread-safe 声明。重命名和拆文件按模块原子提交，禁止全仓格式化和借机改变公式。

## 8. 检查器质量门

每个 checker 都必须有至少一个合法 fixture和每类错误一个最小负 fixture；检查器本身纳入 CI。只 grep 关键词、只检查文件存在、无输入也 PASS、输出固定 claim 数，均判定无效。检查器能证明结构一致，不能宣称证明科学正确。
