# Linux→GitHub main→Fatduck→发布连续流程

## 1. 总原则

Linux 2c2g 是常在线控制节点，连续完成身份、合同、架构、静态、clean build、小型合成、sanitizer、资源负 fixture 和少量真实 smoke。Fatduck 是间歇在线 Windows 计算节点，完成 MSVC、full benchmark、真实三板块、一次 32R 和最终产物。Fatduck 离线只使相应 WIN task 进入 `WAITING_WINDOWS`；不阻塞 Linux 可执行任务，不要求用户逐关回复。

## 2. Linux 每任务协议

1. `git fetch origin --prune`，确认 `HEAD==main==origin/main`；
2. 只把当前 Task 置 `IN_PROGRESS`；
3. 在全新或 Task 独立 build/run 目录执行，命令带 timeout 并流式/落盘日志；
4. 修改最小范围；同步合同、测试与 checker；
5. 运行正/负验收；计算 evidence hash；
6. 写 `TASK_RESULT.json`（记录 parent commit，不伪造结果 commit）；
7. `git diff --check`、检查无无关文件；
8. `git commit -m "<TASK-ID>: <中文目的>"`；
9. `git push origin main`；fetch 后确认 commit==origin/main；
10. 打包器最终从 Git 历史生成 `COMMITS.csv` 并绑定 Task/result/evidence。

允许在一个 Task 中多次编辑和测试，但一个 commit 只能一个明确目的。若任务天然需要多个独立修改，必须在 ledger 追加子 Task，禁止把架构、科学、性能、文档混为一个 commit。

## 3. Linux 资源边界

- clean build 使用有限并行度和内存感知，避免 2c2g OOM；不得因此把 production runtime 固定为 2 核。
- 合成 workload 选 10–30 秒和有界内存；不在 Linux 反复跑 32R/历史版本。
- 从 Fatduck 只取三块各 1R+masters；hash 冻结，不入 Git/审核包。
- 长流程均可恢复：保存 checkpoint、last command、source commit、PID/remote run ID 和日志。

## 4. Fatduck 调用

按仓库 `AGENTS.md/FATDUCK_ACCESS.md` 的 SSH+PowerShell 约定。每次调用必须有 connect timeout、command timeout、idle heartbeat、stdout/stderr 日志和明确 remote working directory。先只读探测；在线后：

1. `git fetch/pull --ff-only origin main`；不得在 Windows 产生未回推代码；
2. 核对 commit 与 Linux 冻结候选；
3. 新建 clean MSVC build/run 目录；
4. 依次 WIN-001→006，所有结果带 binary/provider/input/output hash；
5. 修复必须回 Linux/main 原子 commit+push，再由 Windows 重新 pull；禁止远程临时补丁成为不可追溯真相。

Windows 离线：记录 UTC、DNS/TCP/SSH 命令、exit/timeout 和下一重试；继续所有非 WIN 工作。不得将 `WAITING_WINDOWS` 写成 PASS，也不得用 Linux 结果冒充 Windows。

## 5. 最终 32R

- 使用冻结 manifest 的银心 Red `11+11+10` 和 3 masters，运行前逐文件重算 SHA-256；
- 只对冻结的 final candidate/profile/config 做成功全链一次，不做历史版本对比；
- 若失败，保留失败 run、根因、修复 Task/commit、为何必须重跑；不得删失败日志后宣称“一次成功”；
- 验证 32 帧全部贡献、P1→P2→P3 Artifact 连续、seam/UPM/rejection/support、资源曲线和内存趋势；
- Owner 视图只从该 run 生成，固定 center/FOV/STF/colormap 并带 sidecar/hash。

## 6. 发布候选冻结

冻结键：`source_commit + VERSION + compiler/SDK + provider build IDs + benchmark profile hash + pipeline IR hash + config hash + input manifest hash`。任一代码/合同/依赖/provider 变化使 Windows/发布候选失效；只改 L0 文案且机器证明不影响 binary 时可不重跑科学计算，但必须重生成追溯/审核包。

## 7. 允许停止的唯一情形

- 当前身份不可信或 unknown dirty change；
- 权限/凭据/必需数据缺失；
- 科学合同互相冲突、需要负责人选择；
- 将执行破坏性操作；
- 发现无法在当前任务范围修复的 P0/P1；
- 所有 Linux 工作完成、Fatduck 持续离线，且只剩强制 WIN 门。

普通 Gate、checker PASS、文档审阅、CP0 均不是人工停止点。
