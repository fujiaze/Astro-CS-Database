---
id: ALG-XXX-001
version: 0.1.0
status: DRAFT
owner: astrocs-core
source_commit: 0000000000000000000000000000000000000000
upstream: [SCI-XXX-001]
downstream: [DATA-XXX-001, API-XXX-001, MOD-XXX-001, TEST-XXX-001]
---

# 算法推导

## 从 SCI 到离散算法的逐步推导

## 输入、输出、单位与边界

## 近似、误差、稳定性和确定性

## 复杂度、内存模型和并行轴

## baseline/AVX2/AVX512 等价要求

## 独立 Oracle、性质测试、seed 与预冻结容差

## 失败/取消/checkpoint 语义
