---
id: SCI-XXX-001
version: 0.1.0
status: DRAFT
owner: astrocs-core
source_commit: 0000000000000000000000000000000000000000
upstream: []
downstream: [ALG-XXX-001]
---

# 科学定义

## 计算对象与物理意义

## 连续数学定义

## 量、单位、坐标与无效值

## 假设、适用域与不支持项

## 科学不变量与允许误差

## 一手来源、采用内容与 AstroCS 差异

## 待负责人核实的问题
