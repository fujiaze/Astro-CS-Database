---
id: MOD-XXX-001
version: 0.1.0
status: DRAFT
owner: astrocs-core
source_commit: 0000000000000000000000000000000000000000
upstream: [SCI-XXX-001, ALG-XXX-001, DATA-XXX-001, API-XXX-001]
downstream: [TEST-XXX-001]
---

# 模块 README

## 职责与明确非职责

## 输入输出端口、DATA、单位、坐标、invalid

## 公共 header、核心 symbol 与生命周期

## Registry descriptor 与配置 schema

## Execution class、并行轴、ThreadBudget lease、确定性

## 内存/cache/I-O/所有权

## 错误、日志、指标、取消和 checkpoint

## 独立 synthetic 验证命令与容差

## 已知限制
