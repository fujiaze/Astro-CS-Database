# 科学合同与数值测试验收

## 1. 科学真相链

每项生产能力必须形成：

`SCI → ALG → DATA → API → MOD → source symbol → TEST → current evidence`

SCI 定义连续数学对象、单位、物理假设和适用域；ALG 只能由 SCI 推导离散方法、近似、误差和复杂度；DATA/API 说明承载方式；代码不能反过来成为科学定义。结构 checker 只能证明链存在，科学结论必须由推导、独立 Oracle、性质测试和负责人抽查共同支持。

## 2. 每份算法的固定验证清单

每个 `ALG-*` 必须在编码前冻结：

- 输入域、单位、坐标、invalid/NaN/Inf 语义；
- 解析解或独立 Oracle 的实现来源；
- seed、样本规模、dtype、绝对/相对/ULP 容差；
- 科学不变量、守恒量、单调性或边界；
- baseline/AVX2/AVX512、1/N worker、GCC/Clang/MSVC 的允许差异；
- 确定性等级和规约次序；
- 对抗/负面 fixture；
- 资源 workload 与门禁；
- 失败时指向的 SCI/ALG/代码符号。

禁止在看到结果后提高容差；变更容差是独立科学任务和 commit。

## 3. Oracle 独立性规则

- 测试必须调用 production Registry/Runtime/CLI；仅调用 helper 不算生产验证。
- Oracle 不得调用待测 kernel、复制同一离散循环或把预期 correction 写回输入。
- 可用解析解时优先解析解；否则使用更高精度、不同算法或权威独立库。
- `CHECK(true)`、只检查文件存在、日志包含 PASS、手工填资源指标均为测试缺陷。
- 每个聚合测试报告实际 executable、production symbol、oracle ID、seed/tolerance、输入/输出 hash。

## 4. Phase1 最低矩阵

| 能力 | 合成场景 | 必须检查 |
|---|---|---|
| Calibration | 常量/梯度 bias-dark-flat、负值、NaN、u16/f32/f64 | 公式、单位、边界、variance 传播 |
| Star/PSF | 孤立/重叠/饱和/边缘/纯噪声 | completeness、FP、centroid、FWHM |
| WCS | 已知星场、扰动初值、无解、RA wrap | pixel↔sky roundtrip、失败语义 |
| Photometry | 已知 flux/background/PSF、饱和 | flux bias、uncertainty、拒绝 |
| Noise/SNR | Poisson+read noise Monte Carlo | variance/ivar/SNR 解析一致性 |
| Drizzle | constant/impulse/subpixel/rotation/pixfrac/wrap | flux、centroid、support、coverage、NaN |

## 5. Phase2 接缝专项

构造三块重叠 mini HiPS/FITS，包含常量、线性和低阶背景、不同比例的加性偏移、恒星、扩展结构、mask、low support、断连分量。完整走 production sampler→UPM fit→persist→reload→apply→reject→integrate。

预冻结并输出每 overlap：

- correction 前后 median difference 与 robust RMS；
- 一阶梯度 residual；
- 恒星 aperture/PSF flux ratio；
- 扩展结构 residual；
- zero/low support 像素；
- UPM amplitude、smoothness、gauge residual、component count；
- rejection 数和 integrated signal/variance/ivar/support。

测试不得知道真 correction 的生产 apply 值；Oracle 可在独立分析阶段比较估计值与生成真值。常量缝消失但源被拟合、support 变黑洞、噪声语义错误均失败。

## 6. Phase3 专项

Phase3 定义为 HiPS 球面产品→平面 FITS。实现前必须冻结支持的 HiPS 子集、HEALPix ordering/frame、TAN WCS、pixel center、CD parity、order selection、nearest/bilinear 语义、coverage、missing/NaN、unit/BITPIX/provenance。

独立测试使用常数球、低阶解析球面函数、impulse、跨 tile 连续场、RA 0/360、极区边界、缺 tile 和 NaN。WCS 与 HEALPix reference 必须独立于生产 resampler。普通规则矩形 `bilinear()` 测试不能证明不规则 HEALPix 插值正确。

输出测试必须重新打开 FITS，比较 dimensions、BITPIX、CRPIX/CRVAL/CD/CTYPE/CUNIT/BUNIT、CHECKSUM/DATASUM、coverage、provenance 和抽样像素。故意篡改任一字段必须非零退出。

## 7. 平台、并行和 ISA 等价

所有 provider 首先与高精度/解析 Oracle 比较，再互相比较；历史版本不作主要 Oracle。并行规约允许合同内浮点差异，但必须证明无系统偏差、无数据 race、结果分布在预冻结误差内。每个 kernel 至少覆盖：

- baseline 1 worker reference；
- baseline N worker；
- 支持时 AVX2 N worker；
- 支持并正确时 AVX512 N worker；
- GCC/Clang；最终候选加 MSVC；
- small/medium 和边界规模；
- cancellation/partial failure 不产生可提交 Artifact。

## 8. 抽查机制

Agent 完成不等于科学批准。审核包必须附：

1. 每个 SCI/ALG 的公式、单位、引用和差异摘要；
2. Oracle 源码及其独立性说明；
3. 随机选择至少 10% 合同的源码符号/测试/evidence 抽查清单；
4. Phase2 接缝前后定量表和真实固定视图；
5. Phase3 WCS/单位/checksum 抽查；
6. 所有容差变更历史。

负责人只读 L0；独立审核者可据抽查清单向下复核，不接受 Agent 的单行 `PASS`。
