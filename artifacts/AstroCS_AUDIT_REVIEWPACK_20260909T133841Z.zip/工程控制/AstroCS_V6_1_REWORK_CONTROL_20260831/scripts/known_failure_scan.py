#!/usr/bin/env python3
"""Deterministic probes for blockers independently reproduced in the returned audit."""

from __future__ import annotations

import argparse
import json
import pathlib
import re
import sys
from dataclasses import asdict, dataclass


@dataclass
class Probe:
    finding_id: str
    description: str
    present: bool
    evidence: list[str]


def read(root: pathlib.Path, rel: str) -> str:
    path = root / rel
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def occurrences(root: pathlib.Path, token: str, *, production_only: bool = True) -> list[str]:
    hits: list[str] = []
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in {".cpp", ".cc", ".c", ".h", ".hpp", ".cmake", ".txt"}:
            continue
        rel = path.relative_to(root).as_posix()
        if production_only and (rel.startswith("tests/") or rel.startswith("tools/") or "/tests/" in rel):
            continue
        try:
            if token in path.read_text(encoding="utf-8", errors="replace"):
                hits.append(rel)
        except OSError:
            pass
    return sorted(hits)


def scan(root: pathlib.Path) -> list[Probe]:
    cli = read(root, "cli/main.cpp")
    cmake = read(root, "CMakeLists.txt")
    p2_sampler = read(root, "lib/phase2/src/sampler.cpp")
    p2_upm = read(root, "lib/phase2/src/upm.cpp")
    p3_session = read(root, "lib/phase3_session/p3_session.cpp")
    p3_output = read(root, "lib/phase3_session/p3_output.cpp")
    p2_test = read(root, "tests/unit/p2_upm_synthetic_test.cpp")
    p3_test = read(root, "tests/unit/p3_assembly_test.cpp")
    api_csv = read(root, "docs/contracts/API_CONTRACTS.csv")
    trace_tool = read(root, "tools/check_traceability.py")
    probes: list[Probe] = []

    direct = sorted(set(re.findall(r"p[123]_session_(?:create|validate|run|inspect|destroy)", cli)))
    probes.append(Probe("F-001", "CLI directly calls phase sessions", bool(direct), direct))
    broken_flow = "pdoc[\"hips_paths\"] = doc[\"inputs\"][\"lights\"]" in cli and "pdoc = doc[\"phase3\"]" in cli
    probes.append(Probe("F-002", "phase handoff is rebuilt from config paths", broken_flow, ["cli/main.cpp"] if broken_flow else []))
    p2_serial = "P2_ENABLE_OPENMP" in p2_sampler and ("P2_ENABLE_OPENMP" not in cmake or "!defined(_MSC_VER)" in p2_sampler)
    probes.append(Probe("F-003", "Phase2 sampler parallel path is not portable production default", p2_serial, ["lib/phase2/src/sampler.cpp", "CMakeLists.txt"] if p2_serial else []))
    p2_upm_bad = "hardware_concurrency" in p2_upm or ("P2_ENABLE_OPENMP" in p2_upm and "!defined(_MSC_VER)" in p2_upm)
    probes.append(Probe("F-004", "Phase2 UPM bypasses Runtime lease or excludes MSVC", p2_upm_bad, ["lib/phase2/src/upm.cpp"] if p2_upm_bad else []))
    p3_serial = ("单线程" in p3_session or "serial" in p3_session.lower()) and re.search(r"for\s*\([^)]*y", p3_session) is not None
    probes.append(Probe("F-005", "Phase3 production resampler is explicitly serial", p3_serial, ["lib/phase3_session/p3_session.cpp"] if p3_serial else []))
    gate_hits = [p for p in occurrences(root, "evaluate_gate", production_only=True) if not p.endswith("resource_gate.h")]
    probes.append(Probe("F-006", "resource gate has no production caller", not gate_hits, ["no production evaluate_gate caller"] if not gate_hits else gate_hits))
    context = read(root, "include/astrocs/core/context.h") + read(root, "lib/core/src/context.cpp")
    fake_lease = "acquire_lease" in context and not any(word in context for word in ("compare_exchange", "fetch_sub", "release_lease", "condition_variable"))
    probes.append(Probe("F-007", "ThreadLease has no observable atomic reservation/release", fake_lease, ["include/astrocs/core/context.h", "lib/core/src/context.cpp"] if fake_lease else []))
    p2_toy = bool(p2_test) and "p2_upm_build" not in p2_test and "phase2 run" not in p2_test
    probes.append(Probe("F-009", "Phase2 seam test bypasses production UPM", p2_toy, ["tests/unit/p2_upm_synthetic_test.cpp"] if p2_toy else []))
    dec_conflict = "fabs" in p3_session and re.search(r"fabs\s*\([^)]*dec[^)]*\)\s*<\s*5", p3_session) is not None
    probes.append(Probe("F-010", "Phase3 rejects equatorial instead of near-pole coordinates", dec_conflict, ["lib/phase3_session/p3_session.cpp"] if dec_conflict else []))
    hard_order = "p3_order_select(20" in p3_session.replace(" ", "")
    probes.append(Probe("F-011", "Phase3 max order is hard-coded", hard_order, ["lib/phase3_session/p3_session.cpp"] if hard_order else []))
    bad_meta = any(token in p3_session for token in ('"Jy/beam"', '"0.1.0"', '"phase3-run"'))
    probes.append(Probe("F-012", "Phase3 scientific unit/version/run identity is hard-coded", bad_meta, ["lib/phase3_session/p3_session.cpp"] if bad_meta else []))
    fixed_bitpix = re.search(r"(?:const\s+)?int\s+bitpix\s*=\s*-32", p3_output) is not None
    probes.append(Probe("F-013", "Phase3 writer ignores requested BITPIX", fixed_bitpix, ["lib/phase3_session/p3_output.cpp"] if fixed_bitpix else []))
    direct_drizzle = "hp_drizzle_run_hips" in cli
    probes.append(Probe("F-017", "CLI directly invokes Drizzle", direct_drizzle, ["cli/main.cpp"] if direct_drizzle else []))
    provider_targets = [line for line in cmake.splitlines() if re.search(r"add_(?:library|executable).*astrocs_cpu_(?:baseline|avx2|avx512)", line, re.I)]
    probes.append(Probe("F-019", "independent CPU provider targets are absent", len(provider_targets) < 3, provider_targets or ["CMakeLists.txt"] ))
    p3_vacuous = "CHECK(true)" in p3_test
    probes.append(Probe("F-022", "Phase3 assembly contains vacuous CHECK(true)", p3_vacuous, ["tests/unit/p3_assembly_test.cpp"] if p3_vacuous else []))
    alg_dir = root / "docs/algorithms"
    probes.append(Probe("F-024", "algorithm documents are absent", not alg_dir.is_dir() or not any(alg_dir.glob("*.md")), ["docs/algorithms"] if not alg_dir.is_dir() else []))
    placeholder_count = api_csv.count("ADU/pixel/deg per header")
    probes.append(Probe("F-025", "API semantic table contains mass placeholder values", placeholder_count > 1, [f"placeholder rows={placeholder_count}"] if placeholder_count > 1 else []))
    old_trace = "prerelease_v5" in trace_tool.lower() or "66" in trace_tool
    probes.append(Probe("F-028", "traceability checker reads historical/fixed truth", old_trace, ["tools/check_traceability.py"] if old_trace else []))
    warning_fmt = "%llu" in read(root, "cli/monitor.h")
    probes.append(Probe("F-030", "monitor uses non-portable %llu parsing", warning_fmt, ["cli/monitor.h"] if warning_fmt else []))
    return probes


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("repo", type=pathlib.Path)
    parser.add_argument("--output", type=pathlib.Path)
    args = parser.parse_args(argv)
    root = args.repo.resolve()
    if not root.is_dir():
        print(f"KNOWN_FAILURE_SCAN_ERROR: not a directory: {root}", file=sys.stderr)
        return 2
    probes = scan(root)
    present = [probe for probe in probes if probe.present]
    report = {"schema": "astrocs.known-failure-scan/v1", "repo": str(root), "probe_count": len(probes), "present_count": len(present), "probes": [asdict(probe) for probe in probes]}
    rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.write_text(rendered, encoding="utf-8")
    else:
        print(rendered, end="")
    if present:
        print(f"KNOWN_FAILURES_PRESENT count={len(present)}", file=sys.stderr)
        return 1
    print(f"KNOWN_FAILURE_SCAN_PASS probes={len(probes)}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
