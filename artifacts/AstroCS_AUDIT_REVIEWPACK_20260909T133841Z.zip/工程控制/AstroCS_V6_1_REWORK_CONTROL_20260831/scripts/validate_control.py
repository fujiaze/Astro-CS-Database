#!/usr/bin/env python3
"""Validate the immutable AstroCS V6.1 rework control package."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import pathlib
import re
import sys

from validate_task_graph import LedgerError, load_ledger, validate_rows

EXPECTED_CONSTRAINT_SHA = "dc47fbbbeccb239fc1834a985b357d6ded50080977708b6ea5c9811bf4de4b92"
REQUIRED = {
    "00_READ_FIRST.md", "01_ASTROCS_ENGINEERING_CONSTRAINTS.md", "01_INDEPENDENT_AUDIT_CONCLUSION.md",
    "02_FINDINGS.csv", "03_REWORK_TASK_LEDGER.csv", "04_TASK_SPECIFICATIONS.md", "05_GATE_CHECKLISTS.md",
    "06_ARCHITECTURE_ACCEPTANCE.md", "07_SCIENCE_AND_TEST_ACCEPTANCE.md", "08_CPU_RESOURCE_ACCEPTANCE.md",
    "09_DOCUMENTATION_AND_MACHINE_CHECKS.md", "10_LINUX_WINDOWS_RELEASE_FLOW.md", "11_GIT_MAIN_ONLY.md",
    "12_AUDIT_PACKAGE_SPEC.md", "13_OWNER_REVIEW.md", "14_PRIMARY_REFERENCES.md", "AGENTS_PATCH.md", "START_PROMPT.txt",
    "schemas/task_result.schema.json", "schemas/audit_summary.schema.json", "schemas/resource_summary.schema.json",
    "schemas/data_artifact.schema.json", "schemas/module_descriptor.schema.json", "schemas/pipeline_ir.schema.json", "schemas/cpu_profile.schema.json",
    "scripts/validate_task_graph.py", "scripts/known_failure_scan.py", "scripts/validate_control.py",
    "scripts/validate_return_audit.py", "scripts/package_audit.py", "scripts/selftest.py",
    "templates/TASK_RESULT.template.json", "templates/SUMMARY.template.json", "templates/SOURCE_IDENTITY.template.json",
    "templates/SOURCE_INDEX.csv", "templates/COMMITS.csv", "templates/FINDINGS.csv", "templates/TEST_SUMMARY.csv",
    "templates/RESOURCE_SUMMARY.csv", "templates/LARGE_ARTIFACT_MANIFEST.csv", "templates/PREVIEW_MANIFEST.csv",
    "templates/SCI_CONTRACT.md", "templates/ALG_CONTRACT.md", "templates/MODULE_README.md", "templates/OWNER_REVIEW_CHECKLIST.md",
    "MANIFEST.json", "SHA256SUMS",
}
BANNED_PARTS = {".git", "build", "testdata", "__pycache__", ".pytest_cache", "archive", "history"}
BANNED_SUFFIXES = {".fits", ".fit", ".fts", ".obj", ".pdb", ".ilk", ".dll", ".so", ".exe", ".core", ".dmp", ".tar", ".gz", ".zip"}


def digest(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def fail(message: str) -> None:
    raise ValueError(message)


def validate(root: pathlib.Path) -> dict:
    root = root.resolve()
    missing = sorted(rel for rel in REQUIRED if not (root / rel).is_file())
    if missing:
        fail(f"missing required files: {missing}")
    if digest(root / "01_ASTROCS_ENGINEERING_CONSTRAINTS.md") != EXPECTED_CONSTRAINT_SHA:
        fail("frozen engineering constraints changed")

    prompt = (root / "START_PROMPT.txt").read_text(encoding="utf-8").strip()
    if not prompt or "\n" in prompt or len(prompt) > 1000:
        fail(f"START_PROMPT must be one non-empty line <=1000 Unicode chars; got {len(prompt)}")
    if not all(token in prompt for token in ("main", "ACR", "32R", "READY_FOR_OWNER_REVIEW")):
        fail("START_PROMPT omits a hard constraint")

    for path in sorted((root / "schemas").glob("*.json")):
        doc = json.loads(path.read_text(encoding="utf-8"))
        if doc.get("$schema") != "https://json-schema.org/draft/2020-12/schema":
            fail(f"bad JSON schema declaration: {path.name}")
    for path in sorted((root / "templates").glob("*.json")):
        json.loads(path.read_text(encoding="utf-8"))

    ledger = validate_rows(load_ledger(root / "03_REWORK_TASK_LEDGER.csv"), enforce_states=True)
    if ledger["task_count"] != 67 or ledger["topological_order"][-1] != "REL-004":
        fail(f"unexpected ledger shape: tasks={ledger['task_count']} last={ledger['topological_order'][-1]}")
    if set(ledger["task_counts"]) != {"NOT_STARTED"}:
        fail("immutable control ledger must start entirely NOT_STARTED")

    with (root / "02_FINDINGS.csv").open("r", encoding="utf-8", newline="") as stream:
        findings = list(csv.DictReader(stream))
    expected_ids = {f"F-{number:03d}" for number in range(1, 41)}
    if {row.get("finding_id") for row in findings} != expected_ids or any(row.get("status") != "OPEN" for row in findings):
        fail("F-001..F-040 must exist exactly once and start OPEN")

    files: dict[str, dict] = {}
    total = 0
    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root)
        if path.is_symlink():
            fail(f"symlink forbidden: {rel}")
        if path.is_dir():
            continue
        if any(part in BANNED_PARTS for part in rel.parts) or path.suffix.lower() in BANNED_SUFFIXES:
            fail(f"banned path/type: {rel}")
        size = path.stat().st_size
        if size > 5 * 1024 * 1024:
            fail(f"file too large: {rel}")
        total += size
        files[rel.as_posix()] = {"size": size, "sha256": digest(path)}
    if total > 25 * 1024 * 1024:
        fail(f"control package exceeds 25MiB: {total}")

    content_names = set(files) - {"MANIFEST.json", "SHA256SUMS"}
    manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
    if manifest.get("schema") != "astrocs.control-manifest/v2" or manifest.get("target_version") != "0.10.0-alpha.2":
        fail("bad control manifest schema/version")
    if manifest.get("reviewed_audit_sha256") != "137e3ed14ef85142f5897c93ac718f4f22713977282815e2ddd7288f62e6696a":
        fail("manifest is not bound to the reviewed audit")
    listed = {item["path"]: item for item in manifest.get("files", [])}
    if set(listed) != content_names:
        fail("manifest file set mismatch")
    for name in content_names:
        if listed[name].get("sha256") != files[name]["sha256"] or listed[name].get("size") != files[name]["size"]:
            fail(f"manifest mismatch: {name}")

    sums: dict[str, str] = {}
    for line in (root / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        sha, name = line.split("  ", 1)
        if name in sums:
            fail(f"duplicate SHA256SUMS entry: {name}")
        sums[name] = sha
    if set(sums) != content_names:
        fail("SHA256SUMS file set mismatch")
    for name, sha in sums.items():
        if not re.fullmatch(r"[0-9a-f]{64}", sha) or sha != files[name]["sha256"]:
            fail(f"checksum mismatch: {name}")

    return {"files": len(files), "bytes": total, "tasks": ledger["task_count"], "findings": len(findings), "prompt_chars": len(prompt)}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", nargs="?", default=".", type=pathlib.Path)
    args = parser.parse_args(argv)
    try:
        result = validate(args.root)
        print("CONTROL_PASS " + " ".join(f"{key}={value}" for key, value in result.items()))
        return 0
    except (OSError, ValueError, LedgerError, json.JSONDecodeError) as exc:
        print(f"CONTROL_FAIL: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
