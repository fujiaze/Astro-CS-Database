#!/usr/bin/env python3
"""Validate the AstroCS V6.1 task graph and its live states."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import pathlib
import re
import sys
from collections import Counter, defaultdict, deque

REQUIRED_COLUMNS = {
    "task_id", "gate", "title", "depends_on", "platform", "change_class",
    "heavy_compute", "commit_required", "scope", "acceptance", "status",
}
STATUSES = {"NOT_STARTED", "IN_PROGRESS", "PASS", "FAIL", "WAITING_WINDOWS"}
TASK_RE = re.compile(r"^[A-Z0-9]+-[0-9]{3}$")
GATE_RE = re.compile(r"^G([0-9]+)$")


class LedgerError(ValueError):
    pass


def sha256_file(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_ledger(path: pathlib.Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames is None or set(reader.fieldnames) != REQUIRED_COLUMNS:
            raise LedgerError(f"ledger columns mismatch: {reader.fieldnames}")
        rows = list(reader)
    if not rows:
        raise LedgerError("ledger is empty")
    return rows


def validate_rows(rows: list[dict[str, str]], *, enforce_states: bool = True) -> dict:
    by_id: dict[str, dict[str, str]] = {}
    order: list[str] = []
    for line_no, row in enumerate(rows, start=2):
        task_id = row["task_id"]
        if not TASK_RE.fullmatch(task_id):
            raise LedgerError(f"line {line_no}: invalid task_id {task_id!r}")
        if task_id in by_id:
            raise LedgerError(f"duplicate task_id: {task_id}")
        if row["status"] not in STATUSES:
            raise LedgerError(f"{task_id}: invalid status {row['status']!r}")
        if row["heavy_compute"] not in {"yes", "no"} or row["commit_required"] not in {"yes", "no"}:
            raise LedgerError(f"{task_id}: heavy_compute/commit_required must be yes/no")
        if not GATE_RE.fullmatch(row["gate"]):
            raise LedgerError(f"{task_id}: invalid gate {row['gate']!r}")
        if not all(row[name].strip() for name in ("title", "platform", "change_class", "scope", "acceptance")):
            raise LedgerError(f"{task_id}: required text field is empty")
        if row["status"] == "WAITING_WINDOWS" and "Windows" not in row["platform"]:
            raise LedgerError(f"{task_id}: WAITING_WINDOWS is legal only for a Windows task")
        by_id[task_id] = row
        order.append(task_id)

    deps: dict[str, list[str]] = {}
    reverse: dict[str, list[str]] = defaultdict(list)
    indegree: dict[str, int] = {}
    for task_id, row in by_id.items():
        task_deps = [item.strip() for item in row["depends_on"].split(";") if item.strip()]
        if len(task_deps) != len(set(task_deps)):
            raise LedgerError(f"{task_id}: duplicate dependency")
        task_gate = int(GATE_RE.fullmatch(row["gate"]).group(1))
        for dep in task_deps:
            if dep not in by_id:
                raise LedgerError(f"{task_id}: unknown dependency {dep}")
            dep_gate = int(GATE_RE.fullmatch(by_id[dep]["gate"]).group(1))
            if dep_gate > task_gate:
                raise LedgerError(f"{task_id}: dependency {dep} belongs to a later gate")
            reverse[dep].append(task_id)
        deps[task_id] = task_deps
        indegree[task_id] = len(task_deps)

    queue = deque(task_id for task_id in order if indegree[task_id] == 0)
    topo: list[str] = []
    while queue:
        task_id = queue.popleft()
        topo.append(task_id)
        for next_id in reverse[task_id]:
            indegree[next_id] -= 1
            if indegree[next_id] == 0:
                queue.append(next_id)
    if len(topo) != len(rows):
        raise LedgerError(f"dependency cycle: {sorted(k for k, v in indegree.items() if v > 0)}")

    if enforce_states:
        if sum(row["status"] == "IN_PROGRESS" for row in rows) > 1:
            raise LedgerError("more than one task is IN_PROGRESS")
        for task_id, task_deps in deps.items():
            state = by_id[task_id]["status"]
            if state in {"PASS", "IN_PROGRESS"}:
                bad = [dep for dep in task_deps if by_id[dep]["status"] != "PASS"]
                if bad:
                    raise LedgerError(f"{task_id}: {state} with non-PASS dependencies {bad}")
        if by_id.get("REL-004", {}).get("status") == "PASS":
            raise LedgerError("REL-004 is Owner-only and cannot be marked PASS by the Agent")

    counts = Counter(row["status"] for row in rows)
    gates: dict[str, str] = {}
    for gate in sorted({row["gate"] for row in rows}, key=lambda value: int(value[1:])):
        states = [row["status"] for row in rows if row["gate"] == gate]
        if all(state == "PASS" for state in states):
            gates[gate] = "PASS"
        elif "FAIL" in states:
            gates[gate] = "FAIL"
        elif "IN_PROGRESS" in states:
            gates[gate] = "IN_PROGRESS"
        elif "WAITING_WINDOWS" in states:
            gates[gate] = "WAITING_WINDOWS"
        else:
            gates[gate] = "NOT_STARTED"
    return {"task_count": len(rows), "task_counts": dict(sorted(counts.items())), "gate_status": gates, "topological_order": topo}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("ledger", type=pathlib.Path)
    parser.add_argument("--baseline-sha256")
    parser.add_argument("--structure-only", action="store_true")
    parser.add_argument("--output", type=pathlib.Path)
    args = parser.parse_args(argv)
    try:
        digest = sha256_file(args.ledger)
        if args.baseline_sha256 and digest != args.baseline_sha256.lower():
            raise LedgerError(f"ledger hash changed: {digest}")
        result = validate_rows(load_ledger(args.ledger), enforce_states=not args.structure_only)
        result["ledger_sha256"] = digest
        rendered = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
        if args.output:
            args.output.write_text(rendered, encoding="utf-8")
        else:
            print(rendered, end="")
        print(f"TASK_GRAPH_PASS tasks={result['task_count']}", file=sys.stderr)
        return 0
    except (OSError, LedgerError) as exc:
        print(f"TASK_GRAPH_FAIL: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
