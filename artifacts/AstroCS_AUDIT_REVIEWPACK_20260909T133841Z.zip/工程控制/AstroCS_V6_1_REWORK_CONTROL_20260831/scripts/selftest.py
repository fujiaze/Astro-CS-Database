#!/usr/bin/env python3
"""Negative self-tests for the independent V6.1 control validators."""

from __future__ import annotations

import csv
import json
import pathlib
import tempfile

from known_failure_scan import scan
from validate_return_audit import validate as validate_audit
from validate_task_graph import LedgerError, load_ledger, validate_rows


def expect_ledger_fail(rows: list[dict[str, str]], message: str) -> None:
    try:
        validate_rows(rows, enforce_states=True)
    except LedgerError:
        return
    raise AssertionError(f"negative ledger fixture unexpectedly passed: {message}")


def main() -> int:
    root = pathlib.Path(__file__).resolve().parents[1]
    rows = load_ledger(root / "03_REWORK_TASK_LEDGER.csv")
    result = validate_rows(rows, enforce_states=True)
    assert result["task_count"] == 67 and result["topological_order"][-1] == "REL-004"

    illegal = [dict(row) for row in rows]
    illegal[0]["status"] = "REVIEW_PENDING"
    expect_ledger_fail(illegal, "illegal status")

    bypass = [dict(row) for row in rows]
    next(row for row in bypass if row["task_id"] == "REL-001")["status"] = "PASS"
    expect_ledger_fail(bypass, "PASS before Windows dependency")

    cycle = [dict(row) for row in rows]
    next(row for row in cycle if row["task_id"] == "R0-001")["depends_on"] = "REL-003"
    expect_ledger_fail(cycle, "dependency cycle/later gate")

    owner = [dict(row) for row in rows]
    for row in owner:
        row["status"] = "PASS"
    expect_ledger_fail(owner, "Agent pre-approves Owner task")

    with tempfile.TemporaryDirectory(prefix="astrocs-known-failure-") as temp_name:
        temp = pathlib.Path(temp_name)
        (temp / "cli").mkdir()
        (temp / "cli/main.cpp").write_text("p1_session_run(); hp_drizzle_run_hips();\n", encoding="utf-8")
        probes = scan(temp)
        assert any(probe.finding_id == "F-001" and probe.present for probe in probes)
        assert any(probe.finding_id == "F-017" and probe.present for probe in probes)

    with tempfile.TemporaryDirectory(prefix="astrocs-invalid-audit-") as temp_name:
        try:
            validate_audit(pathlib.Path(temp_name))
        except ValueError:
            pass
        else:
            raise AssertionError("empty audit directory unexpectedly passed")

    for schema in (root / "schemas").glob("*.json"):
        assert json.loads(schema.read_text(encoding="utf-8"))["$schema"].endswith("2020-12/schema")
    for template in (root / "templates").glob("*.json"):
        json.loads(template.read_text(encoding="utf-8"))

    print("SELFTEST_PASS ledger_negative=4 known_failure=2 audit_negative=1 schemas=PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
