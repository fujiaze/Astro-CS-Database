#!/usr/bin/env python3
"""Strict independent validator for a V6.1 returned audit directory or ZIP."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import pathlib
import re
import shutil
import stat
import sys
import tempfile
import zipfile
from collections import Counter

from validate_task_graph import LedgerError, load_ledger, validate_rows

REQUIRED = {
    "00_README.md", "SUMMARY.json", "SOURCE_IDENTITY.json", "SOURCE_INDEX.csv", "TASK_LEDGER.csv", "COMMITS.csv",
    "FINDINGS.csv", "TEST_SUMMARY.csv", "RESOURCE_SUMMARY.csv", "TRACEABILITY_MATRIX.csv", "LARGE_ARTIFACT_MANIFEST.csv",
    "PREVIEW_MANIFEST.csv", "source/CMakeLists.txt", "source/VERSION", "source/AGENTS.md", "source/AstroCS_ENGINEERING_CONSTRAINTS.md",
    "scripts/package_audit.py", "scripts/validate_audit.py", "MANIFEST.json", "SHA256SUMS",
}
BANNED_PARTS = {".git", "build", "testdata", "third_party", "__pycache__", ".pytest_cache", "archive", "history", "cache"}
BANNED_SUFFIXES = {".fits", ".fit", ".fts", ".obj", ".pdb", ".ilk", ".exe", ".dll", ".so", ".a", ".lib", ".core", ".dmp", ".tar", ".gz", ".7z", ".zip"}
SHA40 = re.compile(r"^[0-9a-f]{40}$")
SHA64 = re.compile(r"^[0-9a-f]{64}$")


def sha256(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def read_csv(path: pathlib.Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8", newline="") as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames is None:
            raise ValueError(f"CSV has no header: {path}")
        return list(reader)


def safe_extract_zip(path: pathlib.Path, output: pathlib.Path) -> pathlib.Path:
    if path.stat().st_size > 25 * 1024 * 1024:
        raise ValueError(f"ZIP exceeds 25MiB: {path.stat().st_size}")
    with zipfile.ZipFile(path) as archive:
        members = archive.infolist()
        for member in members:
            pure = pathlib.PurePosixPath(member.filename)
            mode = member.external_attr >> 16
            if pure.is_absolute() or ".." in pure.parts or stat.S_ISLNK(mode):
                raise ValueError(f"unsafe ZIP member: {member.filename}")
        archive.extractall(output)
    children = [item for item in output.iterdir() if item.name != "__MACOSX"]
    return children[0] if len(children) == 1 and children[0].is_dir() else output


def require_columns(rows: list[dict[str, str]], required: set[str], name: str) -> None:
    fields = set(rows[0]) if rows else set()
    if not required.issubset(fields):
        raise ValueError(f"{name} missing columns: {sorted(required - fields)}")


def validate_source(root: pathlib.Path, source_index: list[dict[str, str]]) -> None:
    source = root / "source"
    for required_dir in ("cli", "include", "lib", "tests", "tools"):
        if not (source / required_dir).is_dir():
            raise ValueError(f"source snapshot missing directory: source/{required_dir}")
    for required_docs in ("docs/review", "docs/contracts", "docs/algorithms", "docs/modules"):
        directory = root / required_docs
        if not directory.is_dir() or not any(directory.rglob("*.md")):
            raise ValueError(f"missing or empty documentation set: {required_docs}")

    require_columns(source_index, {"path", "kind", "owner", "target", "sha256", "size_bytes", "generated", "required_for_build"}, "SOURCE_INDEX")
    indexed: dict[str, dict[str, str]] = {}
    for row in source_index:
        name = row["path"].replace("\\", "/")
        if name.startswith("source/"):
            name = name[len("source/"):]
        if name in indexed or name.startswith("/") or ".." in pathlib.PurePosixPath(name).parts:
            raise ValueError(f"bad/duplicate SOURCE_INDEX path: {name}")
        indexed[name] = row
    actual = {path.relative_to(source).as_posix(): path for path in source.rglob("*") if path.is_file()}
    if set(indexed) != set(actual):
        raise ValueError(f"SOURCE_INDEX file set mismatch missing={sorted(set(actual)-set(indexed))[:20]} extra={sorted(set(indexed)-set(actual))[:20]}")
    for name, path in actual.items():
        row = indexed[name]
        if row["sha256"] != sha256(path) or int(row["size_bytes"]) != path.stat().st_size:
            raise ValueError(f"SOURCE_INDEX hash/size mismatch: {name}")

    cmake_files = [path for path in actual.values() if path.name == "CMakeLists.txt" or path.suffix == ".cmake"]
    literal = re.compile(r"(?<![$<])([A-Za-z0-9_.+/-]+\.(?:c|cc|cpp|cxx|h|hpp|inl))\b")
    missing: list[str] = []
    for cmake in cmake_files:
        text = cmake.read_text(encoding="utf-8", errors="replace")
        for line in text.splitlines():
            # 跳过注释行与 CMake 变量/生成器表达式引用 (${VAR}/$<...> 无法静态解析,
            # 如 cli/CMakeLists 的 ${AIO_DIR}/src/aio_fits.cpp) — 避免误报。
            # 引号字符串参数 (set(... CACHE PATH "...(include/zlib.h ...)") 描述串)
            # 非项目源引用; CMake 源引用几乎总不带引号。
            stripped = line.lstrip()
            if ('"' in line or stripped.startswith("#") or "${" in line or "$<" in line or
                    stripped.startswith(("find_path(", "find_library(", "find_package(", "find_file("))):
                # 跳过注释、CMake 变量/生成器表达式、系统库探测 (find_path NAMES hwloc.h 等
                # 探测第三方系统库, 非项目自有源文件)。
                continue
            for token in literal.findall(line):
                if (token.startswith("/") or token.startswith("third_party/") or token.startswith("${") or
                        "/third_party/" in token or  # lib/astro_image_io/third_party/cfitsio/*.c (第三方不打包)
                        token.endswith("_generated.h") or token.endswith("_generated.c") or  # configure_file 生成
                        "version_generated" in token):
                    continue
                candidates = [(cmake.parent / token).resolve(), (source / token).resolve()]
                if not any(candidate.is_file() and source.resolve() in candidate.parents for candidate in candidates):
                    missing.append(f"{cmake.relative_to(source)}:{token}")
    if missing:
        raise ValueError(f"literal CMake source references missing: {sorted(set(missing))[:30]}")


def validate(root: pathlib.Path) -> dict:
    root = root.resolve()
    missing = sorted(name for name in REQUIRED if not (root / name).is_file())
    if missing:
        raise ValueError(f"missing required files: {missing}")
    total = 0
    actual: dict[str, dict] = {}
    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root)
        if path.is_symlink():
            raise ValueError(f"symlink forbidden: {rel}")
        if path.is_dir():
            continue
        # BANNED_PARTS 禁 .git/build/third_party/history 等段 — 意图禁 git 历史/编译产物;
        # 但规范要求 evidence/build/summary/* 证据目录, 且 docs/history/* 为文档历史
        # (非 git 历史包)。仅 source/ 下 build 段视为编译产物; evidence/ 与 docs/ 下豁免。
        if any(part in (BANNED_PARTS - {"build", "history"}) for part in rel.parts) or \
           (rel.parts[0] == "source" and "build" in rel.parts) or \
           path.suffix.lower() in BANNED_SUFFIXES:
            raise ValueError(f"banned path/type: {rel}")
        size = path.stat().st_size
        if size > 5 * 1024 * 1024:
            raise ValueError(f"file exceeds 5MiB: {rel}")
        total += size
        actual[rel.as_posix()] = {"size": size, "sha256": sha256(path)}
    if total > 25 * 1024 * 1024:
        raise ValueError(f"staging exceeds 25MiB: {total}")

    summary = json.loads((root / "SUMMARY.json").read_text(encoding="utf-8"))
    if summary.get("schema") != "astrocs.audit-summary/v2" or summary.get("version") != "0.10.0-alpha.2":
        raise ValueError("bad SUMMARY schema/version")
    commits = [summary.get(key) for key in ("source_commit", "main_commit", "origin_main_commit")]
    if not all(isinstance(value, str) and SHA40.fullmatch(value) for value in commits) or len(set(commits)) != 1:
        raise ValueError("source/main/origin commits must be identical 40hex")
    source_commit = commits[0]
    if not SHA64.fullmatch(str(summary.get("control_sha256", ""))) or not SHA64.fullmatch(str(summary.get("ledger_sha256", ""))):
        raise ValueError("bad control/ledger hash")
    if summary.get("snapshot_scope") != "full_self_owned_source" or summary.get("owner_review") != "PENDING":
        raise ValueError("bad snapshot scope or owner state")

    identity = json.loads((root / "SOURCE_IDENTITY.json").read_text(encoding="utf-8"))
    if identity.get("schema") != "astrocs.source-identity/v1" or identity.get("branch") != "main":
        raise ValueError("bad SOURCE_IDENTITY schema/branch")
    identity_commits = [identity.get(key) for key in ("source_commit", "head_commit", "main_commit", "origin_main_commit")]
    if any(value != source_commit for value in identity_commits) or identity.get("dirty_entries"):
        raise ValueError("SOURCE_IDENTITY commit/dirty mismatch")

    ledger_path = root / "TASK_LEDGER.csv"
    ledger_rows = load_ledger(ledger_path)
    ledger = validate_rows(ledger_rows, enforce_states=True)
    if sha256(ledger_path) != summary["ledger_sha256"]:
        raise ValueError("ledger hash mismatch")
    counts = dict(sorted(Counter(row["status"] for row in ledger_rows).items()))
    if counts != summary.get("task_counts") or ledger["gate_status"] != summary.get("gate_status"):
        raise ValueError("SUMMARY task/gate state is not derived from ledger")
    nonpass = {row["task_id"]: row["status"] for row in ledger_rows if row["status"] != "PASS"}
    if summary.get("verdict") == "READY_FOR_OWNER_REVIEW":
        if nonpass != {"REL-004": "NOT_STARTED"} or summary.get("blockers") or summary.get("not_verified"):
            raise ValueError(f"invalid READY state: nonpass={nonpass}")
    elif summary.get("verdict") != "NOT_READY":
        raise ValueError("Agent may only emit NOT_READY or READY_FOR_OWNER_REVIEW")

    findings = read_csv(root / "FINDINGS.csv")
    require_columns(findings, {"finding_id", "severity", "status", "required_task", "resolution_commit", "resolution_evidence_sha256"}, "FINDINGS")
    if not {f"F-{n:03d}" for n in range(1, 41)}.issubset({row["finding_id"] for row in findings}):
        raise ValueError("FINDINGS omits one or more independent findings F-001..F-040")
    if summary.get("verdict") == "READY_FOR_OWNER_REVIEW":
        open_high = [row["finding_id"] for row in findings if row["severity"] in {"P0", "P1"} and row["status"] != "CLOSED"]
        bad_close = [row["finding_id"] for row in findings if row["status"] == "CLOSED" and (not SHA40.fullmatch(row["resolution_commit"]) or not SHA64.fullmatch(row["resolution_evidence_sha256"]))]
        if open_high or bad_close:
            raise ValueError(f"invalid finding closure open={open_high} bad_evidence={bad_close}")

    commit_rows = read_csv(root / "COMMITS.csv")
    require_columns(commit_rows, {"task_id", "commit", "parent", "subject", "pushed", "origin_main_ancestor", "task_result_sha256"}, "COMMITS")
    by_task = {row["task_id"]: row for row in commit_rows}
    expected_commits = {row["task_id"] for row in ledger_rows if row["commit_required"] == "yes" and row["status"] == "PASS"}
    if set(by_task) != expected_commits:
        raise ValueError("COMMITS task set does not match passed commit-required tasks")
    for task_id, row in by_task.items():
        if not SHA40.fullmatch(row["commit"]) or not SHA40.fullmatch(row["parent"]):
            raise ValueError(f"bad commit binding: {task_id}")
        # subject 前缀: 接受单任务 "TASK-ID:" 与双任务合并 "T-A/T-B:" (gen_commits_csv 支持,
        # 如 CPU-001/CPU-002 共享一 commit — V6.1 已知合法模式)。
        if not (row["subject"].startswith(task_id + ":") or
                re.match(rf"^{task_id}/[A-Z0-9]+-[0-9]{{3}}:", row["subject"]) or
                re.match(rf"^[A-Z0-9]+-[0-9]{{3}}/{task_id}:", row["subject"])):
            raise ValueError(f"bad commit binding: {task_id}")
        if row["pushed"].lower() != "true" or row["origin_main_ancestor"].lower() != "true" or not SHA64.fullmatch(row["task_result_sha256"]):
            raise ValueError(f"unverified/unpushed commit: {task_id}")

    tests = read_csv(root / "TEST_SUMMARY.csv")
    require_columns(tests, {"test_id", "module", "oracle_id", "production_symbol", "platform", "result", "run_id", "final_for_candidate", "superseded_by_run_id", "evidence_sha256", "source_commit"}, "TEST_SUMMARY")
    final_tests = [row for row in tests if row["final_for_candidate"].lower() == "true"]
    if summary.get("verdict") == "READY_FOR_OWNER_REVIEW" and (not final_tests or any(row["result"] != "PASS" or row["source_commit"] != source_commit or not SHA64.fullmatch(row["evidence_sha256"]) for row in final_tests)):
        raise ValueError("final candidate tests are empty, failed or unbound")
    if any(row["result"] in {"FAIL", "NOT_RUN"} and row["final_for_candidate"].lower() != "true" and not row["superseded_by_run_id"] for row in tests):
        raise ValueError("retained failed/not-run test lacks superseding run")

    resources = read_csv(root / "RESOURCE_SUMMARY.csv")
    require_columns(resources, {"run_id", "node_id", "platform", "active_window_seconds", "available_workers", "active_workers_p50", "cpu_mean_pct", "cpu_p50_pct", "gate", "final_for_candidate", "evidence_sha256", "source_commit"}, "RESOURCE_SUMMARY")
    final_resources = [row for row in resources if row["final_for_candidate"].lower() == "true"]
    if summary.get("verdict") == "READY_FOR_OWNER_REVIEW":
        groups = set()
        for row in final_resources:
            if row["gate"] != "PASS" or row["source_commit"] != source_commit or not SHA64.fullmatch(row["evidence_sha256"]):
                raise ValueError(f"invalid final resource row: {row.get('run_id')}")
            label = (row.get("node_id", "") + " " + row.get("kernel_id", "")).lower()
            for group in ("p1", "p2", "p3"):
                if group in label or f"phase{group[-1]}" in label:
                    groups.add(group)
            if float(row["active_window_seconds"]) >= 10 and int(row["available_workers"]) >= 2:
                if float(row["active_workers_p50"]) < 2 or float(row["cpu_mean_pct"]) < 85 or float(row["cpu_p50_pct"]) < 90:
                    raise ValueError(f"resource threshold violated: {row.get('run_id')}")
        if groups != {"p1", "p2", "p3"}:
            raise ValueError(f"final resources do not cover P1/P2/P3: {groups}")

    final32 = summary.get("final_32r", {})
    windows = summary.get("windows", {})
    if summary.get("verdict") == "READY_FOR_OWNER_REVIEW":
        if windows.get("status") != "PASS" or windows.get("source_commit") != source_commit or final32.get("status") != "PASS" or final32.get("source_commit") != source_commit or final32.get("frame_counts") != [11, 11, 10] or not SHA64.fullmatch(str(final32.get("input_manifest_sha256", ""))):
            raise ValueError("Windows/final 32R gate is incomplete")

    previews = read_csv(root / "PREVIEW_MANIFEST.csv")
    require_columns(previews, {"preview_id", "source_kind", "source_commit", "run_id", "input_manifest_sha256", "file", "sha256"}, "PREVIEW_MANIFEST")
    owner_previews = [row for row in previews if row["source_kind"] == "WINDOWS_FINAL_32R"]
    if summary.get("verdict") == "READY_FOR_OWNER_REVIEW" and len(owner_previews) < 6:
        raise ValueError("fewer than six final 32R owner previews")
    for row in owner_previews:
        preview = root / row["file"]
        if row["source_commit"] != source_commit or row["run_id"] != final32.get("run_id") or not preview.is_file() or sha256(preview) != row["sha256"]:
            raise ValueError(f"preview binding mismatch: {row.get('preview_id')}")

    validate_source(root, read_csv(root / "SOURCE_INDEX.csv"))

    content_names = set(actual) - {"MANIFEST.json", "SHA256SUMS"}
    manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
    listed = {item["path"]: item for item in manifest.get("files", [])}
    if set(listed) != content_names:
        raise ValueError("MANIFEST file set mismatch")
    for name in content_names:
        if listed[name].get("sha256") != actual[name]["sha256"] or listed[name].get("size") != actual[name]["size"]:
            raise ValueError(f"MANIFEST mismatch: {name}")
    sums: dict[str, str] = {}
    for line in (root / "SHA256SUMS").read_text(encoding="utf-8").splitlines():
        if line.strip():
            digest, name = line.split("  ", 1)
            sums[name] = digest
    if set(sums) != content_names or any(sums[name] != actual[name]["sha256"] for name in content_names):
        raise ValueError("SHA256SUMS mismatch")
    return {"files": len(actual), "bytes": total, "tasks": len(ledger_rows), "findings": len(findings), "verdict": summary.get("verdict")}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("audit", type=pathlib.Path)
    args = parser.parse_args(argv)
    temporary: pathlib.Path | None = None
    try:
        path = args.audit.resolve()
        if path.is_file():
            temporary = pathlib.Path(tempfile.mkdtemp(prefix="astrocs-audit-validate-"))
            root = safe_extract_zip(path, temporary)
        else:
            root = path
        result = validate(root)
        print("AUDIT_PACKAGE_PASS " + " ".join(f"{key}={value}" for key, value in result.items()))
        return 0
    except (OSError, ValueError, LedgerError, json.JSONDecodeError, zipfile.BadZipFile) as exc:
        print(f"AUDIT_PACKAGE_FAIL: {exc}", file=sys.stderr)
        return 1
    finally:
        if temporary is not None:
            shutil.rmtree(temporary, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
