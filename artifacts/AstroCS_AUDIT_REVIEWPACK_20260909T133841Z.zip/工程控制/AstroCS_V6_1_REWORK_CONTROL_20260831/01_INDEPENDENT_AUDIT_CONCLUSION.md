# `astrocs_audit_20260830T183323Z.tar.gz` 独立审核结论

审核日期：2026-08-31  
结论：`REJECTED_NOT_READY`  
发布结论：禁止发布、禁止负责人视觉批准、禁止把包内 81 项 PASS 继续作为真相源。

## 1. 审核范围与诚实边界

本次收到的 tar 包本身无路径穿越、无链接，569 个普通文件；其 `audit_manifest.json` 列出的 568 个文件 hash 全部正确。该结论只证明压缩包传输完整，不证明代码、任务或科学结论正确。

本包不是完整可复现源码：根 CMake 显式引用的 69 个自有源码/构建路径中，审核快照缺 42 个；尤其缺 `p1_session.cpp`、`p2_session.cpp`、大部分 I/O、Drizzle、Calibration、CPU provider 实现。还缺全部 `docs/algorithms/*`。因此我没有、也不会声称“已看过完整代码”。但现有快照已经暴露足以打回的生产级缺陷。

审核包自报 commit `b16d422...` 仅记录在自制 manifest 中；包内没有 `SOURCE_IDENTITY.json`、`COMMITS.csv` 或 Git 可验证关系，不能证明它等于当时的 `HEAD/main/origin/main`，也不能证明 79 个任务 commit 全部是其祖先且已 push。

## 2. 独立复验结果

| 检查 | 现场结果 | 结论 |
|---|---|---|
| tar 安全性 | 569 regular，0 link，0 unsafe path | PASS（仅容器安全） |
| 内部文件 hash | 568/568 匹配 | PASS（仅传输完整） |
| V6 审核包验证器 | 缺 11 个核心必需文件，非零退出 | FAIL |
| V6 任务图验证器 | `REL-004` 使用非法状态 `REVIEW_PENDING` | FAIL |
| 依赖逻辑 | `WIN-006=WAITING_WINDOWS`，但依赖它的 `REL-001=PASS` | FAIL |
| 合同图现场运行 | 15 个合同路径缺失 | FAIL |
| 可复现构建 | 42 个显式 CMake 自有路径缺失 | FAIL |
| 项目 warning | Clang 日志至少 4 个 `%llu`/`uint64_t*` 类型不匹配 | FAIL |
| 生产 Runtime reachability | 生产代码无 Registry/IR/Scheduler/RunContext 调用 | FAIL |
| 生产资源 gate reachability | `evaluate_gate/fast_fail_first10s` 只在测试/header | FAIL |

## 3. 生产架构不是目标架构

### 3.1 Runtime 是未接线脚手架

`lib/core` 定义了 `PipelineIR`、`ModuleRegistry`、`Scheduler` 和 `RunContext`，但生产源调用图中没有任何实例化或注册；命中仅来自其自身实现和单元测试。`cli/main.cpp` 仍直接 include 三个 session 并逐 phase 调用 `p*_session_create/validate/run/inspect/destroy`。

这不是 `CLI → Pipeline Runtime → Registry → Module`，而是 `CLI → 手写 if/for → Session`。文档把它称为 IR-driven 属事实错误。

### 3.2 Phase 间没有类型化 Artifact 链

`astrocs run` 运行 Phase1 后只把输出路径追加到 `all_artifacts`；Phase2 的 `hips_paths` 仍重新取原始 `doc.inputs.lights`，没有消费 Phase1 产物。Phase3 又从用户 `phase3.source.hips_dir` 取输入，不消费 Phase2 Artifact。

因此“1→2→3 全链”只是同一进程里依次运行三个独立入口，不是数据管道。它不能证明帧身份、单位、WCS、hash 或 provenance 在阶段间连续。

### 3.3 线程租约并非租约

`RunContext::acquire_lease()` 只是返回 `min(requested, thread_budget)`，没有原子预留、归还或并发节点总预算。Scheduler 可同时运行多个节点，又给每个节点完整 budget，叶模块若各自启动线程会超卖。RunContext 的日志、metrics、ticks、artifacts、checkpoint 容器无锁，却被共享给并发节点，存在数据竞争风险。

`PipelineIRParser::validate()` 只接收模块名字符串列表，结构上不可能校验端口、DATA schema、单位或坐标；虽定义 `MISSING_PORT/DATA_MISMATCH/UNIT_MISMATCH`，实现没有产生这些错误。`ModuleRegistry` 也未校验完整 SCI/ALG/DATA/API/TEST、heavy+parallel、端口唯一性和 config schema。

## 4. “禁止单线程重计算”未满足

### Phase2

- `sampler.cpp` 和 `upm.cpp` 注释明确写默认 `P2_ENABLE_OPENMP=OFF` 时实际串行。
- 根 CMake 只把 OpenMP 链到最终 CLI，没有给 `astrocs_phase2` 定义 `P2_ENABLE_OPENMP`。
- 并行代码还用 `!defined(_MSC_VER)` 排除 Windows，因此 Fatduck/MSVC 路径无法走这套并行实现。
- worker 数来自模块内 `std::thread::hardware_concurrency()`，不是 Runtime lease，也不感知 cgroup/Job Object 总预算。

### Phase3

`p3_session_run` 明文写“单线程串行”，用 `for y`×`for x` 遍历全部输出像素。P3-006 的所谓资源门只是 `CHECK(true)`；P3-003 测试只测试独立 toy `bilinear()`，不调用生产 resampler 或 session。

### 资源 gate

`resource_gate.h` 写了较完整判据，但生产代码没有调用 `evaluate_gate()` 或 `fast_fail_first10s()`。CLI 只采整个进程摘要并自报 workers=可用核数；这不能证明算法真正启动了这些 worker。LNX-004 的唯一日志是 P2 gate 单元测试的一行，没有 CPU 时间序列、p50/p95、活跃 worker、内存、I/O 或 ≥10 秒 active window。

结论：这是“存在门禁类”，不是“生产门禁生效”。用户最重要的绝对约束仍未完成。

## 5. Phase2 接缝没有被证明修复

`p2_upm_synthetic_test.cpp` 自己构造三个数组、自己用 median 解常量偏移，未调用 `p2_upm_build`、生产 sampler、mask、regularization、persist 或 integration。`p2_seam_gate_test.cpp` 更直接把已知 `C_B=-8` 写入测试；资源指标也是人工填入 `GateConfig`。多处 `CHECK(true)` 只验证注释。

该测试最多证明“减去正确常量会消除已知常量缝”，不能证明 AstroCS 生产 UPM 能从合成数据估计正确场，更不能证明此前回退的银心接缝已修复。

## 6. Phase3 当前存在科学和 FITS 实现错误

### 6.1 合同—API—代码互相矛盾

- SCI 文档称“避开极点”却写 `|Dec|≥5°`；正确表达若排除距两极 5° 是 `|Dec|≤85°`。
- `p3_wcs_make()` 使用 `|Dec|≤85°`，但 `p3_session` 使用 `fabs(dec)<5` 拒绝赤道附近；同一输入经 API 层和 WCS 层结果不同。
- SCI 文档仍写 Phase3 “未实现/PROTOTYPE_NOT_PRODUCTION”，合同索引把 `ALG-P3-001` 标 DRAFT；发布状态却称 G6 完成。
- request 接受 `bitpix=-64`，writer 永远写 `BITPIX=-32`。
- session 计算 `order_sel` 时硬编码 max order 20；sampler 实际始终用 properties 最大 order，`order_sel` 只写进 metadata，没有驱动采样。
- `BUNIT` 硬编码 `Jy/beam`，而 SCI/L0 明确禁止；版本硬编码 `0.1.0`，run_id 硬编码 `phase3-run`，missing tile 始终空，manifest hash 为空。

### 6.2 “bilinear”未被定义/验证为 HEALPix 连续插值

生产实现从中心和 8 邻居中按切平面象限挑点，再把不规则 HEALPix 中心当矩形四角；权重只使用部分角点坐标。当前测试使用规则 8×8 数组的普通双线性函数，完全不是生产 HEALPix 算法，因此无法验证跨 tile 连续性、RA wrap、极区或权重性质。

### 6.3 FITS checksum 与重开验证自报不实

- writer 自己对内存 buffer 做小端 32-bit 加和，不是 FITS `CHECKSUM/DATASUM` 标准流程；`dscov` 计算后未使用，且写入位置/值错误。
- `p3_output_verify()` 没读取或比较 WCS、BUNIT、CHECKSUM；参数 `wcs` 实际未使用。
- 即使像素/coverage 不一致，verify 仍返回 `P3_OUT_OK`，只把 flag 置零；session 不据此失败。
- fsync 在 CFITSIO close 前执行，不能证明用户态缓冲已经落盘；也未 fsync 父目录。

因此 Phase3 不能标 IMPLEMENTED，更不能进入正式发布。

## 7. 文档与机器检查质量不合格

- 36 份 Markdown 中 0 份具有控制包要求的合同 front matter。
- 审核包缺全部 `docs/algorithms/*`；现场合同图直接报 15 个缺路径。
- 仅 5 个模块 README；core/io/phase2/cpu/runtime 等生产模块未覆盖。
- `API_CONTRACTS.csv` 有 422 行，但全部 422 行 units 都是 `ADU/pixel/deg per header`，全部 error_model 都是 `return code 0=OK`。例如 `void aio_hio_free(void*)` 也被写成有返回码、带 ADU/deg 单位、blocking read，明显是批量占位而非详细接口定义。
- AST 工具只检查 3 个 header，且只检查函数名是否在 AST JSON 文本出现；没有真的比较参数类型、cv/ref/noexcept、layout、ownership 或文档语义。
- traceability 默认读取 `artifacts/prerelease_v5/tables/TRACEABILITY.csv`；最终 checker 还硬编码输出 `66 claims`，不是当前 V6 真相。
- pipeline trace checker 在没有任何运行 manifest 时也 PASS；对 P3 没节点时人工补 `output`。它没有比较 edge、port、Artifact hash、module version、workers 或 backend。
- L0 文档彼此矛盾：`REVIEW.md` 仍说当前 G8，`RELEASE_STATUS` 说 G11 Linux 完成，SCIENCE_OVERVIEW 说 Phase3 prototype。

结论：当前“定义=算法=架构=接口=代码=测试”没有成立，机器检查主要验证文件/关键词存在，不能验证语义一致。

## 8. 代码质量抽查

| 维度 | 当前评价 | 主要证据 |
|---|---|---|
| 架构可维护性 | 不合格 | Runtime 未接线；CLI 1604 行；直接调用内核/session |
| 并发设计 | 不合格 | Phase2/3 实际串行；租约无预留；RunContext 无同步 |
| 科学可靠性 | 未证明 | Phase2 toy seam；Phase3 SCI/API/CODE 冲突 |
| API/接口文档 | 不合格 | 422 行占位语义；只抽 3 个 header |
| 测试质量 | 不合格 | 多个 `CHECK(true)`；测试复刻算法且绕过生产路径 |
| 编译质量 | 不合格 | Clang 报格式类型不匹配，QA 却自报 warning=0 |
| sanitizer | 未闭合 | LSan 被关闭；TSan 无现场生产链证据 |
| 发布/审计 | 不合格 | ledger 依赖非法；审核包缺必需文件和源码 |

## 9. 本轮可保留的成果

不要求推倒重来。以下可以作为待修基座，但必须重新接线和验证：

- `VERSION=0.10.0-alpha.1` 的单源思路；下一候选升为 alpha.2。
- ACR 默认未进入当前根 CMake 生产目标的方向。
- C ABI 带 size/version、错误域、Artifact/IR/Registry/Scheduler 类型的初稿。
- Phase1/2/3 已有若干小型合成 fixture，可改造成调用生产入口的 Oracle。
- 资源监控字段与 gate 判据的初稿，可接入每个 heavy node。
- Linux GCC/Clang 和 sanitizer 的既有命令线索。

这些是“可继续开发的代码”，不是已通过的发布能力。

## 10. 决定

1. 当前 commit 不作为“已验收基线”；只作为待修起点候选。
2. 不回退历史，不再做旧版全量差分。
3. 按 `03_REWORK_TASK_LEDGER.csv` 从完整源码身份与已知失败复现开始。
4. 先真正打通 Runtime/Artifact/CPU/monitor，再迁移 Phase1/2/3。
5. Phase2 接缝、Phase3 科学与 FITS 输出必须用生产路径合成 Oracle。
6. Linux 完成静态、clean build、合成、sanitizer、2 核资源和少量真实 smoke；Windows 在线后做 MSVC、benchmark、合成、少量真实和一次 32R。
7. 只有最终真实 32R 视图可提交负责人审核；当前合成 PGM 不接受。

