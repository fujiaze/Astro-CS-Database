# 一手科学与工程参考

引用不是装饰。每份 SCI/ALG 必须说明采用哪一节/公式/语义、AstroCS 如何推导、单位和与来源的差异；论文不能替代项目合同或生产测试。

## 科学与格式

1. Fruchter & Hook, **Drizzle: A Method for the Linear Reconstruction of Undersampled Images**, PASP 114, 144–152 (2002), arXiv:astro-ph/9808087。用于 footprint、pixfrac、权重与 flux 语义；AstroCS 的球面/HEALPix版本须自行推导。
2. Górski et al., **HEALPix: A Framework for High-Resolution Discretization and Fast Analysis of Data Distributed on the Sphere**, ApJ 622, 759–771 (2005), arXiv:astro-ph/0409513。用于等面积、层次、RING/NESTED 和邻接语义。
3. IVOA, **HiPS Recommendation 1.0** (2017-05-19), `https://www.ivoa.net/documents/HiPS/`；Fernique et al., **Hierarchical progressive surveys**, A&A 578, A114 (2015)。用于 properties、目录、tile/order 和交付语义。
4. Greisen & Calabretta (2002) 及 Calabretta & Greisen (2002), FITS WCS Papers I/II；NASA WCS 索引 `https://fits.gsfc.nasa.gov/fits_wcs.html`。用于 Phase3 TAN、CRPIX/CRVAL/CD/CTYPE/CUNIT 和 errata。
5. IAU FITS Working Group, **Definition of the Flexible Image Transport System (FITS), Version 4.0**，`https://fits.gsfc.nasa.gov/standard40/fits_standard40aa-le.pdf`。用于 BITPIX、header、HDU、CHECKSUM/DATASUM 与数据表示；实现优先调用 CFITSIO 标准 API。
6. Montage Algorithms，`https://montage.ipac.caltech.edu/docs/algorithms.html`，用于重投影/重叠背景模型的工程参考。AstroCS UPM 的加性模型、gauge、正则化与源保护仍须独立 SCI/ALG，不得无授权改成乘性平坦化。
7. Maples et al., **Robust Chauvenet Outlier Rejection** (2018), arXiv:1807.05276。仅在完整实现对应定义时引用，不得把普通 sigma clipping 命名为 RCR。

## I/O、并行与 ISA

8. NASA/HEASARC CFITSIO User’s Guide, **Using CFITSIO in Multi-threaded Environments** 与 **Multiple Access to the Same FITS File**。必须使用 reentrant 构建、现场 `fits_is_reentrant()`；worker 使用独立 `fitsfile*`，不得并发共享同一 handle。
9. OpenMP 5.2 Specification。请求 team size 不等于实际 active worker；AstroCS 以 Runtime lease 和现场指标为准，且必须防止 nested oversubscription。
10. AMD64 Architecture Programmer’s Manual 与 Intel 64/IA-32 SDM。用于 CPUID、OSXSAVE/XGETBV、SIMD 状态与 feature bit；不得只凭 CPU 品牌/型号启用 ISA。
11. GCC function multiversioning 与 Microsoft x64 intrinsics/compiler 文档只作实现参考。跨 GCC/MSVC 的首发架构使用稳定 provider C ABI，不依赖单一编译器扩展。

## 引用验收

- 使用稳定题名、版本/日期、DOI/arXiv/官方 URL；优先标准组织、论文或官方手册。
- SCI/ALG 的 reference 表必须包含“采用内容”和“项目差异”两列。
- 依赖库行为由锁定版本、源码/API 和现场测试验证，不靠博客。
- Phase3 未完成文献核实、独立 Oracle、WCS/FITS 负测前不得标 IMPLEMENTED。
