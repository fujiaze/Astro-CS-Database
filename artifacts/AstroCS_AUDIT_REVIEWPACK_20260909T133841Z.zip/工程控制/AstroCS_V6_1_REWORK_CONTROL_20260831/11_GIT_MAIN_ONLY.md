# Git main-only 原子提交规范

## 1. 硬规则

- 只在 `main` 开发、提交、push；不创建/切换 branch、worktree branch 或 PR branch。
- 禁止 merge、rebase、cherry-pick、am、reset、force push、改写历史、删除远端历史。
- 每个 `commit_required=yes` Task 恰好对应一个或一组显式登记的原子 commit；默认一个 Task 一个 commit。
- commit message：`<TASK-ID>: <中文、单一目的>`。
- 每个 commit 通过对应局部验收后立即 `git push origin main`，再 fetch 核验。
- 不提交数据、build、cache、日志大文件、审核包、控制包、凭据或无关格式化。

## 2. 起点和并发

每个 Task 开始前记录 `parent_commit`、`HEAD/main/origin_main`。三者不一致或出现来源未知 dirty change，停止修改并汇报。只有一个 Agent/任务可写 main；不得并行写同一工作树。分析/只读检查可并行，但本控制包默认单执行者串行状态机。

## 3. Task 结果与 commit 绑定

`TASK_RESULT.json` 在 commit 前生成，不能包含尚不存在的 result commit。最低记录：task_id、parent_commit、control/ledger hash、changed paths、commands、tests、evidence paths/hashes、science/API/pipeline impact、known limits、expected commit subject。

commit/push 后，打包器从 Git 读取：commit SHA、parent、subject、author/UTC、changed paths、pushed ancestor relation，并写 `COMMITS.csv`。验证器检查：

- commit subject 以 Task ID 开头；
- parent 与结果中一致；
- commit changed paths 与 result 登记一致；
- commit 是 source commit 祖先且是 origin/main 祖先；
- 依赖任务 commit 在其前；
- 不存在重复 Task、无 Task commit、未 push commit。

## 4. 原子边界

必须分开提交：科学定义/算法变化、架构接线、并行/性能、接口 ABI、测试 Oracle、文档修正、工具/checker。一个修复必须同时更新直接受影响合同和测试时，可在同一 Task commit 内完成，因为这是维持一致性的最小闭环；不得顺手清理其他模块。

## 5. 失败处理

测试失败不 commit 半成品，保留 run evidence。若已 push 的 commit 后来发现问题，追加新的修复 Task/commit，不改写历史。Windows 发现缺陷必须回 Linux main 修复并 push，再由 Windows pull；远端临时改动不得作为最终代码。

## 6. 最终审核

`SOURCE_IDENTITY.json` 必须显示 `source_commit == main_commit == origin_main_commit` 且工作树可解释。`COMMITS.csv` 是 Git 现场生成证据，不是 Agent 手填。审核包本身不包含 `.git`；审核者通过 commit SHA、文件 hash和源码快照交叉验证。
