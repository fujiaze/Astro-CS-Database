# AstroCS 当前 main 完整审核证据采集规范 V1

## 0. 启动词（不超过100字）

> 严格执行本文件，仅在main只读采集完整源码、历史、文档、测试与接缝证据；禁止改代码、建分支、commit或push。

## 1. 本轮任务性质

本轮不是开发、修复或预发布验收，只是生成一份可供独立审核的**权威证据包**。

Agent 只能读取、枚举、构建必要索引、执行安全的只读检查并打包。不得根据检查结果修改任何项目文件。

### 1.1 强制约束

1. AstroCS 后续只在 `main` 开发；禁止创建、切换到或推送任何新开发分支。
2. 本次采集必须在 `main` 上进行，且开始时必须确认：
   - 当前分支为 `main`；
   - 工作区和暂存区均干净；
   - 本地 `main` 与 `origin/main` 完全一致；
   - 没有未初始化或脏状态的子模块。
3. 若任一条件不满足，立即停止并报告，不得自动 reset、clean、stash、merge、rebase、checkout、pull 或修复。
4. 禁止修改代码、文档、配置、测试、Git 历史和远端状态。
5. 禁止 commit、push、PR、tag、force push 及任何破坏性 Git 操作。
6. 禁止沿用既有审核报告中的 PASS 作为新证据；必须交付原始材料。
7. 所有可能阻塞的命令必须设置明确 timeout；stdout/stderr 保存到日志。
8. 禁止输出访问令牌、密码、私钥、完整环境变量或含凭据的远端 URL。
9. 不得复制 build、运行缓存、HiPS 全量数据、testdata 图像正文等大文件，除非本文件明确要求。
10. 任何缺失项必须写入 `MISSING_EVIDENCE.csv`，禁止伪造、推断或用描述性文字冒充原件。

## 2. 权威 Git 身份证据

必须生成 `00_identity/`，包含：

| 文件 | 必须包含 |
|---|---|
| `repository_identity.json` | 项目名、采集UTC时间、主机OS/架构、仓库根目录的脱敏标识 |
| `git_status.txt` | `git status --porcelain=v2 --branch` 原始输出 |
| `head.txt` | `git rev-parse HEAD`、`git rev-parse main`、`git rev-parse origin/main` |
| `head_equality.json` | 三者是否完全一致；必须为 true 才可继续 |
| `branches.txt` | 只读分支及跟踪关系清单；不得切换分支 |
| `tags.txt` | 标签、目标SHA、日期 |
| `remote_sanitized.txt` | 仅保留协议/主机/仓库路径，必须移除用户名、token和密码 |
| `submodules.txt` | `.gitmodules`、递归状态、每个子模块SHA和dirty状态 |
| `lfs.txt` | 是否启用LFS、LFS指针清单、对象可用性；禁止输出凭据 |
| `git_fsck.txt` | `git fsck --no-progress` 结果 |

同时对以下历史SHA逐一执行存在性检查，记录 object type、是否为 `main` 可达及简短提交信息；不存在时如实记录：

- `b9c628399d92fcff0c81d94c74da506f707f2078`（旧科学参考）；
- `a7e063e57516dbe3e0c5dc894f8c3e04d32b4a1c`（旧预发布候选起点）；
- `9d79204b0a8cf02c3f7f6c145cb4c7e52ece3d2f`（上一审核包声称的最终证据HEAD）。

## 3. 完整源码与历史

必须生成：

1. `01_repository/main-source.tar.gz`
   - 必须由 `git archive main` 生成，只包含当前 `main` 已跟踪文件；
   - 不得从工作区直接压缩，避免混入未跟踪文件；
   - 保留文件权限与符号链接语义。
2. `01_repository/main-history.bundle`
   - 必须由当前 `main` 生成并通过 `git bundle verify`；
   - 必须足以离线恢复当前 `main` 可达历史。
3. `01_repository/main_tree.txt`
   - 当前 `main` 全部已跟踪路径、mode、blob SHA；
   - 不得只给目录树截图。
4. `01_repository/file_inventory.csv`
   - 字段：`path,category,language,size_bytes,blob_sha,is_generated,is_vendor,is_test,is_doc`；
   - category 至少区分 source/header/build/test/doc/script/config/vendor/generated。
5. `01_repository/history_first_parent.txt`
   - `main` 第一父链完整日志：SHA、作者日期、主题、变更统计。
6. `01_repository/history_recent_full.txt`
   - 最近100次提交的完整提交信息、name-status和stat。
7. `01_repository/baseline_comparison/`
   - 当前 `main` 分别与上述存在的三个SHA比较；
   - 每组必须包含 merge-base、`diff --stat`、`diff --name-status`、完整文本 patch；
   - 二进制文件只记录路径、旧新blob SHA及大小，不嵌入二进制正文。

## 4. 项目规则、记忆与决策

必须原样包含当前 `main` 中：

- 根目录 `AGENTS.md`、`memory.md`、README、CHANGELOG、release notes；
- 每个模块的 `memory.md` 与正式决策记录；
- `docs/` 下的开发规则、科学规范、算法规范、软件规范、测试规范；
- ADR/RFC/design/decision 等架构决策文件；
- 各模块的日志索引，但不复制无关巨量运行日志。

生成 `02_governance/document_authority.csv`，字段：

```text
document,path,authority_level,scope,status,last_commit,last_date,supersedes,superseded_by
```

必须明确哪个文件是现行权威定义，哪些是历史材料。若项目没有文档权威层级，记录为缺口，不得由 Agent 自行决定。

## 5. 科学定义材料

必须收集全部可能改变科学结果的正式定义，至少覆盖：

1. Calibration：bias/dark/flat、gain、read noise、negative value、pedestal、单位与精度；
2. PSF/星点检测及去重；
3. PlateSolve/WCS/坐标系/投影；
4. Photometry、背景估计、SNR、variance、ivar与权重传播；
5. Drizzle：footprint、pixfrac、能量/通量守恒、覆盖度、采样、数值精度；
6. HEALPix/HiPS：NSIDE、tile、order、坐标与数据层级；
7. Phase2控制点与背景采样：亮星/星云排除、SNR/质量权重；
8. UPM/梯度校正：只允许加性模型、规范自由度、参考帧、正则化、持久化；
9. Rejection/Integration：Sigma、Winsorized、Linear Fit、ESD、RCR及自动选择条件；
10. ACR：FP32/FP64语义、CPU/GPU/Mixed等价条件、确定性与容差；
11. 缺失值、NaN/Inf、溢出、空输入、极端参数、异常帧处理；
12. 输出数据的物理量、单位、有效范围、mask/support语义。

生成 `03_science/science_contract_inventory.csv`：

```text
sci_id,title,path,status,formula_ids,input_quantities,output_quantities,units,assumptions,invariants,error_budget,validation_ids,source_symbols
```

要求：

- 复制正式科学文档原件；
- 公式必须保留原始编号或锚点；
- 没有公式、单位、假设、误差预算或验证方法时分别记录缺口；
- 不得在采集阶段替项目补写科学定义。

## 6. 算法文档材料

对每项科学定义收集其推导出的算法文档，生成 `04_algorithms/algorithm_inventory.csv`：

```text
alg_id,title,path,sci_ids,input,output,preconditions,steps,boundaries,complexity,parallel_semantics,numerical_precision,error_handling,api_ids,source_symbols,test_ids
```

算法材料必须覆盖：

- 连续定义到离散实现的推导；
- 数据布局和中间量；
- 边界条件、退化情况及失败策略；
- 时间和空间复杂度；
- FP32/FP64、归约顺序、FMA及允许误差；
- 串行、并行、异步执行对语义与确定性的影响；
- CPU、GPU、Mixed路由是否必须逐位一致或容差一致；
- 算法选择器的条件与默认回退路径。

只有科学文档标题、没有数学推导或伪代码的，必须标记 `INCOMPLETE`。

## 7. 软件架构与执行模型材料

复制所有架构、模块、数据流、线程和部署文档，并生成：

### 7.1 `05_architecture/module_inventory.csv`

```text
module,responsibility,public_entry,input_types,output_types,dependencies,owner_docs,source_roots,test_roots
```

### 7.2 `05_architecture/execution_paths.csv`

每条正式生产路径一行，字段：

```text
path_id,cli_entry,call_chain,threads,openmp,async_io,cpu_tasks,gpu_tasks,acr_route,synchronization,cancellation,timeout,error_propagation,determinism,config_keys
```

至少列出：

- Stage1 单帧完整链路；
- Stage2 sampler/control/UPM/persist/tile/integration/HiPS链路；
- CPU-only 默认链路；
- ACR CPU、GPU、Mixed、AutoMixed能力链路；
- 实际生产配置是否真的调用ACR；
- 异步读取、缓存、写出和任务调度链路。

### 7.3 同步与资源生命周期

收集并索引：

- 线程池/OpenMP线程数来源；
- mutex/critical/atomic/barrier/future/condition variable；
- 异步任务所有权、取消和异常传播；
- 文件句柄、内存映射、RAM/VRAM buffer、缓存和临时文件生命周期；
- CPU/GPU数据驻留和H2D/D2H传输；
- 2C2G Linux下的内存上限、并发上限和降级策略。

不得仅复制架构图；必须有对应源码符号和配置键。

## 8. 公共API与函数级定义

必须以真实头文件、导出符号和实现为依据生成API清单，禁止使用统一模板填充。

生成 `06_api/api_contracts.csv`，每个公共API/CLI入口/跨模块接口一行：

```text
api_id,symbol,kind,declaration_path,definition_path,signature,purpose,
input_name,input_type,input_semantics,input_unit,input_range,input_nullable,input_ownership,
output_type,output_semantics,output_unit,output_range,output_ownership,
side_effects,lifetime,mutability,thread_safety,reentrancy,blocking,async_completion,
error_model,exceptions,determinism,precision,sci_ids,alg_ids,test_ids
```

要求：

1. `void`、析构、free/close函数不得填写“返回0表示成功”。
2. 句柄、路径、索引、布尔量不得填写ADU等物理单位。
3. ownership必须明确 caller/callee/shared/borrowed 及释放函数。
4. blocking、async completion、reentrancy必须来自实现或正式设计，不能猜。
5. 每个字段必须是具体值；无法确定写 `UNKNOWN` 并列入缺口。
6. 同时导出实际公共头文件、CLI help、配置schema、插件/动态库导出符号。

另生成 `06_api/function_inventory.csv`，列出全部非第三方函数/方法：

```text
symbol,qualified_name,path,start_line,end_line,visibility,signature,callers,callees,module,is_parallel,is_async,docs_anchor,test_ids
```

## 9. 可追溯关系原始数据

必须交付项目现有的正式追溯表原件及生成/检查脚本，不得只交一个“67行PASS”的摘要。

生成 `07_traceability/traceability_expanded.csv`：

```text
sci_id,formula_id,alg_id,api_id,source_symbol,source_path,test_id,test_path,status,evidence
```

同时生成覆盖率统计，但统计不能替代明细：

- SCI → ALG覆盖率；
- ALG → API/SRC覆盖率；
- 公共API → SCI/ALG覆盖率；
- 核心源码符号 → 文档覆盖率；
- SCI/ALG/API → TEST覆盖率；
- generic/scope-only映射数量；
- UNKNOWN、MISSING、STALE、CONTRADICTORY数量。

必须包含追溯检查器完整源码、版本和调用日志，便于审核检查器是否只验证“字段非空”。

## 10. 构建系统与依赖

收集：

- 根及子模块全部 CMakeLists、preset、toolchain、构建脚本；
- 依赖清单、版本锁定、来源、许可证、可选/必选关系；
- CPU-only、OpenMP、CUDA/其他GPU、Debug、Release、sanitizer开关；
- 生成代码流程及生成器版本；
- Linux CLI正式构建入口和安装/运行入口；
- Windows/MSVC专用入口，只收集，不在本轮远程执行；
- 当前已有 `compile_commands.json` 的生成方式，不复制旧build产物。

生成 `08_build/build_matrix.csv`：

```text
build_id,platform,compiler,config,features,expected_targets,entry_command,status,current_evidence_path
```

必须明确“全仓构建”和“仅Phase2子目录构建”的差别，不得以后者冒充前者。

## 11. 测试与机器化检查

复制全部测试源码、fixture描述、测试清单、CTest配置、Python/Shell检查脚本及CI配置。生成：

### 11.1 `09_tests/test_inventory.csv`

```text
test_id,name,path,type,module,sci_ids,alg_ids,api_ids,data_kind,platform,backend,precision,timeout,oracle,tolerance,last_result
```

### 11.2 检查器清单

至少列出并复制现有的：

- C/C++语法、编译警告、clang-tidy/cppcheck等配置；
- ASan/UBSan/TSan或等价检查；
- 文档链接、锚点、Markdown、CSV、JSON、YAML语法检查；
- API声明/定义/导出符号一致性检查；
- 文档函数名和真实源码符号一致性检查；
- SCI/ALG/API/SRC/TEST追溯检查；
- 单位、容差、默认值、配置schema与代码常量一致性检查；
- CLI help、示例配置和解析器一致性检查；
- 未使用/失效测试及 skip/xfail 条件检查。

本轮不得为了“看起来完整”临时生成虚假检查器。不存在的检查器进入缺口清单，后续审核再设计。

## 12. 数值与科学参考材料

收集合成测试的确定性种子、输入生成方法、oracle、容差和参考输出摘要。若项目仍采用下列既有合同，必须找到其当前权威文档；找不到则报告缺失，不得擅自沿用：

- 默认确定性种子：`0xA57C5AC20260802`；
- FP32参考容差：`1e-5 + 5e-5*max(...)`；
- FP64参考容差：`1e-12 + 1e-11*max(...)`；
- 整数及身份/索引结果必须完全一致。

生成 `10_numerics/numerical_contracts.csv`：

```text
quantity,definition,unit,dtype,accumulator_dtype,range,abs_tol,rel_tol,nan_policy,inf_policy,determinism,source_of_truth,source_symbols,test_ids
```

必须特别收集：SNR、variance、ivar、Drizzle accumulator、UPM参数、rejection阈值、support/coverage和输出像素的定义。

## 13. 接缝退化专项证据

接缝专项必须区分两个基线：

1. **旧科学参考基线**：用于检查科学数值漂移，当前已知为 `b9c6283...`；
2. **无接缝已知良好基线**：用于检查后来修复是否退化，必须从历史和产物中重新确认。

不得因为当前结果与旧科学基线一致，就认定接缝没有回归。

### 13.1 历史搜索

在所有已有本地refs和 `main` 历史中只读搜索以下关键词及其中文含义：

```text
seam, overlap, gradient, background, UPM, control, sampler,
harmonic, blend, feather, weight, support, mosaic, HiPS,
接缝, 重叠, 梯度, 背景, 控制点, 马赛克
```

生成 `11_seam/history_candidates.csv`：

```text
commit,date,subject,reachable_from_main,changed_paths,reason_candidate,evidence_available
```

### 13.2 已知良好版本

如果能够从历史报告、用户验收记录或产物哈希确定接缝曾正常：

- 记录精确commit SHA，不得只写日期或“某旧版本”；
- 导出该commit源码快照；
- 导出该commit与当前main的完整文本patch和函数级差异；
- 收集当时使用的配置、32R数据清单、编译选项、日志和HiPS产物哈希；
- 若产物过大，只提供目录manifest、关键预览图和可重新取得的位置，不复制整套HiPS；
- 所有用户视觉结论必须附原始文字和对应产物身份。

如果无法唯一确定，列出候选并标记 `UNRESOLVED`，不得挑选一个充当基线。

### 13.3 接缝链路源码

必须完整包含并索引以下调用链对应源码和配置：

```text
frame/background metadata
→ control sampler
→ bad-sample/bright-source mask
→ UPM solve and gauge
→ per-frame additive correction
→ Drizzle/support/weight accumulation
→ rejection/integration
→ HiPS tile generation and browser STF/render
```

生成 `11_seam/seam_chain_symbols.csv`，不得仅写模块名。

### 13.4 现有接缝验证工具

收集项目中已有的：

- 重叠区残差、背景平面、低频残差或seam metric脚本；
- UPM correction surface导出工具；
- support/weight/difference HiPS生成工具；
- 固定坐标、FOV、order和STF的浏览器审核配置。

不存在时列为缺口。本轮不临时发明一个指标并宣称通过。

## 14. ACR、并行和性能证据

### 14.1 ACR实际接线

必须交付：

- ACR公共API、路由器、profile/标定格式及后端实现；
- CPU、GPU、Mixed、AutoMixed的选择条件；
- 未标定、GPU不可用、资源繁忙时的回退；
- 普通CLI是否初始化ACR；
- Phase2正式生产配置中哪些函数实际调用ACR；
- `enabled=0`、forced CPU等日志字段的生成位置和语义。

必须明确区分：

```text
ACR能力测试通过 ≠ Phase2生产链路已启用ACR
链接OpenMP运行库 ≠ 实际循环已经并行
```

### 14.2 性能材料

收集已有可信baseline、最近一次运行的原始分阶段耗时及资源监控，不重复跑32R完整基准。至少包括：

- sampler probe、sampler fill、UPM solve、persist、tile process、integration、HiPS写出；
- CPU整体及逐线程利用率；
- RSS/峰值内存、major/minor fault、swap；
- 磁盘读写字节、吞吐、I/O wait；
- GPU利用率、显存、H2D/D2H（若实际启用）；
- 锁等待、串行区、任务队列、重复计算和重复I/O；
- 缓存文件大小、生成条件和复用策略。

生成 `12_performance/performance_evidence.csv`：

```text
run_id,commit,platform,data_manifest,config_hash,stage,wall_s,cpu_s,peak_rss,read_bytes,write_bytes,gpu_used,threads,evidence_path
```

不得用代码模式正则扫描或微基准替代真实资源利用证据。

## 15. testdata 与真实数据身份

本证据包不复制银心FITS正文。必须生成 `13_testdata/manifest.csv`：

```text
dataset,section,filter,relative_path,size_bytes,sha256,frame_id,dimensions,dtype,exposure,gain,temperature,wcs_present,accessible_from_linux,source_host
```

要求：

- 冻结银心三个板块全部R帧，预期数量必须由实际索引计算，不得硬编码后直接声称32帧齐全；
- 给出Fatduck上权威数据根的脱敏说明及复制方式，不包含密码/密钥；
- 给出Linux目标目录约定和断点续传/哈希复核方法；
- 记录合成数据生成器及真实数据许可/来源；
- 对缺失、重复、哈希冲突、同名不同内容分别报告。

## 16. 代码质量原始材料

为后续全量审核准备：

- 全部项目源码与头文件；
- 编译数据库生成方法；
- 警告级别及 warning-as-error策略；
- 静态分析配置和抑制清单；
- sanitizer配置；
- 代码格式规范，但不得在本轮格式化；
- TODO/FIXME/HACK、disabled code、deprecated API清单；
- 重复实现、超长函数、循环复杂度、全局可变状态清单（若已有工具）；
- 线程安全注释和所有权注释；
- error code/exception/logging规范；
- 第三方代码边界、补丁和许可证。

必须区分项目代码、第三方代码和生成代码，避免把第三方问题计入项目质量，也避免把项目代码错误标成vendor排除。

## 17. 现有运行证据与审核报告

将既有报告放入 `14_prior_evidence/`，但必须标明：

- 报告对应commit、平台、配置和数据manifest；
- 报告是否含完整原始日志；
- 报告结论是否已经被当前main继承；
- 报告内的PASS是否可重现；
- 报告与状态机、gate JSON、用户签字是否互相矛盾。

上一审核包 `prerelease_20260823T100624Z_a7e063e.zip` 只作为历史证据引用，不得作为当前main源码替代品。

## 18. 缺口、矛盾与来源声明

生成三个文件：

### `15_findings/MISSING_EVIDENCE.csv`

```text
id,required_item,expected_path,reason_missing,impact,how_to_obtain
```

### `15_findings/CONTRADICTIONS.csv`

```text
id,claim_a,path_a,claim_b,path_b,affected_scope,severity,needs_human_definition
```

### `15_findings/PROVENANCE.csv`

```text
artifact,path,generated_or_original,generator,command,source_commit,sha256
```

Agent 只记录事实，不给出“预发布通过/不通过”的最终裁决，不自行修改科学定义来消除矛盾。

## 19. 最终目录结构

```text
AstroCS_MAIN_AUDIT_EVIDENCE_<UTC>_<HEAD12>/
├── 00_READ_FIRST.md
├── MANIFEST.json
├── SHA256SUMS
├── 00_identity/
├── 01_repository/
├── 02_governance/
├── 03_science/
├── 04_algorithms/
├── 05_architecture/
├── 06_api/
├── 07_traceability/
├── 08_build/
├── 09_tests/
├── 10_numerics/
├── 11_seam/
├── 12_performance/
├── 13_testdata/
├── 14_prior_evidence/
├── 15_findings/
└── logs/
```

`00_READ_FIRST.md` 必须说明：

- 当前main SHA及与origin/main一致性；
- 采集是否完整；
- 缺失项数量；
- 接缝良好基线是否已唯一确定；
- 包内不含哪些大文件及其获取方式；
- 本次没有修改仓库、没有commit、没有push。

## 20. 打包与自检

1. 对所有文件生成SHA-256；`SHA256SUMS` 自身除外。
2. `MANIFEST.json` 至少包含路径、大小、SHA-256、来源commit、original/generated分类。
3. 检查包内无：
   - `.git/`目录；
   - build目录和对象文件；
   - token、密码、私钥、cookies、完整环境变量；
   - testdata FITS正文；
   - 无关HiPS瓦片或巨型缓存；
   - 空文件（确需为空时在manifest注明原因）。
4. 验证源码归档可解压、Git bundle可verify、CSV/JSON可解析。
5. 验证 `main-source.tar.gz` 解压后的Git树内容与当前 `main^{tree}` 对应。
6. 输出最终压缩包，并单独报告压缩包SHA-256和大小。

## 21. 本轮验收标准

只有同时满足以下条件，才可称“证据采集完成”：

- 当前分支确认为干净的 `main`，且等于 `origin/main`；
- 当前main完整源码归档和可验证Git bundle均存在；
- SCI、ALG、架构、API、SRC、TEST原件及明细索引齐全；
- 检查器源码存在，而非只有PASS摘要；
- 旧科学基线与无接缝良好基线被明确区分；
- 接缝良好基线已确定，或明确报告无法确定及候选列表；
- 全部缺失与矛盾均有机器可读清单；
- 包完整性、哈希、敏感信息扫描通过；
- 仓库未发生任何修改、commit或push。

未满足时只能报告 `EVIDENCE_INCOMPLETE`，禁止使用 `PASS`、`PRE_RELEASE_READY` 或“完全统一”。

## 22. 后续开发约束（仅记录，不在本轮执行）

完成独立审核后，所有修复仍只在 `main` 上进行：

- 一个commit只处理一个可独立验证的问题；
- 每个commit必须同时更新受影响的科学/算法/架构/API/测试材料；
- 每个commit必须附局部测试和机器化一致性检查；
- 阶段完成后push `main`；
- 禁止创建功能分支或预发布分支；
- 性能已有可信baseline后禁止反复完整跑批，先做资源和源码热点定位。
