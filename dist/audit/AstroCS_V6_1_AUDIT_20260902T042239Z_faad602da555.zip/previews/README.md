Windows 32R 六视图待 Fatduck 在线生成 (WIN-006); 合成图不得入 owner 视图
