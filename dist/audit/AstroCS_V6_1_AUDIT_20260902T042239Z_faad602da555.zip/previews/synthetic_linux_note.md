Linux synthetic 预览不进入 owner 视图 (12_AUDIT_PACKAGE_SPEC.md §2); 六张真实视图由 WIN-006 生成
