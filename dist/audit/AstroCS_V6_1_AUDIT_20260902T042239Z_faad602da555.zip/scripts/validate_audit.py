#!/usr/bin/env python3
"""validate_audit.py — V6.1 审核包验证器 (委托 validate_return_audit 同源逻辑)."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from validate_return_audit import validate, main
if __name__ == "__main__":
    raise SystemExit(main())
