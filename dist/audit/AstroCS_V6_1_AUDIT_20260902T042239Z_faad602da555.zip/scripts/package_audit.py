#!/usr/bin/env python3
"""Finalize, validate and deterministically ZIP a prepared V6.1 audit staging tree."""

from __future__ import annotations

import argparse
import hashlib
import json
import pathlib
import re
import subprocess
import sys
import tempfile
import zipfile

NAME_RE = re.compile(r"^AstroCS_V6_1_AUDIT_[0-9]{8}T[0-9]{6}Z_[0-9a-f]{12}\.zip$")


def sha256(path: pathlib.Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def content_files(root: pathlib.Path) -> list[pathlib.Path]:
    result: list[pathlib.Path] = []
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise ValueError(f"symlink forbidden: {path.relative_to(root)}")
        if path.is_file() and path.name not in {"MANIFEST.json", "SHA256SUMS"}:
            result.append(path)
    return result


def write_integrity(root: pathlib.Path) -> None:
    files = content_files(root)
    entries = [{"path": path.relative_to(root).as_posix(), "size": path.stat().st_size, "sha256": sha256(path)} for path in files]
    manifest = {"schema": "astrocs.audit-manifest/v2", "files": entries}
    (root / "MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    (root / "SHA256SUMS").write_text("".join(f"{item['sha256']}  {item['path']}\n" for item in entries), encoding="utf-8")


def run_validator(validator: pathlib.Path, target: pathlib.Path, timeout: int) -> None:
    completed = subprocess.run([sys.executable, str(validator), str(target)], text=True, capture_output=True, timeout=timeout, check=False)
    sys.stdout.write(completed.stdout)
    sys.stderr.write(completed.stderr)
    if completed.returncode != 0:
        raise ValueError(f"audit validator failed for {target} with exit {completed.returncode}")


def create_zip(root: pathlib.Path, output: pathlib.Path) -> None:
    with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(item for item in root.rglob("*") if item.is_file()):
            rel = path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(rel)
            info.date_time = (1980, 1, 1, 0, 0, 0)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--staging", required=True, type=pathlib.Path)
    parser.add_argument("--output", required=True, type=pathlib.Path)
    parser.add_argument("--validator", required=True, type=pathlib.Path)
    parser.add_argument("--timeout-seconds", type=int, default=300)
    args = parser.parse_args(argv)
    try:
        staging = args.staging.resolve()
        output = args.output.resolve()
        validator = args.validator.resolve()
        if not staging.is_dir() or not validator.is_file():
            raise ValueError("staging directory or validator is missing")
        if not NAME_RE.fullmatch(output.name):
            raise ValueError(f"bad output name: {output.name}")
        if output.exists():
            raise ValueError(f"refusing to overwrite existing output: {output}")
        if staging in output.parents or output.parent == staging:
            raise ValueError("output ZIP must be outside staging")
        write_integrity(staging)
        run_validator(validator, staging, args.timeout_seconds)
        output.parent.mkdir(parents=True, exist_ok=True)
        create_zip(staging, output)
        run_validator(validator, output, args.timeout_seconds)
        if output.stat().st_size > 25 * 1024 * 1024:
            raise ValueError(f"ZIP exceeds 25MiB after validation: {output.stat().st_size}")
        print(f"AUDIT_ZIP_READY path={output} bytes={output.stat().st_size} sha256={sha256(output)}")
        return 0
    except (OSError, ValueError, subprocess.TimeoutExpired, zipfile.BadZipFile) as exc:
        print(f"AUDIT_ZIP_FAIL: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
