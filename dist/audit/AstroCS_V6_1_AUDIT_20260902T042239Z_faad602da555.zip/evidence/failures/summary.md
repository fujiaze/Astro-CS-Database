# failures summary (V6.1 Linux)
