# V6.1 Gate 自动检查清单

本文件是 `03_REWORK_TASK_LEDGER.csv` 的人工可读投影，不是第二套状态源。每个 Gate 完成时，由脚本把本段复制到 `evidence/v6_1_rework/gates/Gx/CHECKLIST.md`，逐项写入 `PASS/FAIL + evidence path + SHA-256`。空项、`N/A`、历史日志、口头说明均不得通过。Gate 通过后立即进入下一可执行任务，不等待人工回复。

## G0：起点与证据完整性

- [ ] 控制包解包后 `CONTROL_PASS`，控制包 SHA 与任务结果一致。
- [ ] `HEAD == main == origin/main`；仅使用 `main`；remote URL 已脱敏。
- [ ] `b16d422a40fefedbdedab1749cfb8ebc06189736` 与实际起点祖先关系已现场核实。
- [ ] dirty/untracked 文件逐项判定来源；未知修改导致 G0 失败。
- [ ] 从 CMake、public headers、registry、test registry 生成完整自有源码清单。
- [ ] 所有生产 target 引用路径存在；第三方、生成文件和数据单列。
- [ ] V6.1 ledger 的原始 hash 冻结；状态机和依赖图验证通过。
- [ ] F-001 至 F-040 每项有现场 `REPRODUCED/NOT_REPRODUCED` 证据。

## G1：治理、版本和检查器

- [ ] Task 结果、commit、push 与 `origin/main` 可机器绑定，不能自证或引用未来 commit。
- [ ] 故意伪造 PASS、漏依赖、非法状态、未 push commit 均被负面测试拒绝。
- [ ] 版本唯一为 `0.10.0-alpha.2`，二进制、包、文档均从同一源生成。
- [ ] 生产可达调用图能识别 CLI 直连 session/Drizzle 和 Runtime 死代码。
- [ ] 静态 Pipeline 图与 observed trace 的 node/edge/port/artifact/version/backend/workers 全量比较。
- [ ] 空 trace、伪造 node、漏 edge、漏 artifact、重复 producer 均失败。
- [ ] serial-heavy、OpenMP 宏关闭、MSVC 排除、资源 gate 无生产 caller 均被识别。

## G2：唯一 Runtime 与类型化数据链

- [ ] Module descriptor 的 SCI/ALG/DATA/API/TEST、端口、资源与并行模型完整。
- [ ] ThreadBudget 是原子 reserve/release 租约；嵌套和并发总 worker 不超预算。
- [ ] RunContext 的日志、指标、artifact、checkpoint、cancel 并发安全；TSan 定向通过。
- [ ] PipelineIR 使用 schema 校验模块、端口、单位、坐标、producer、DAG 与资源。
- [ ] Registry 能创建并执行真实模块，不只注册 metadata；重复/不完整 descriptor 拒绝。
- [ ] Scheduler 支持依赖并发、backpressure、失败传播、取消、checkpoint/recovery。
- [ ] ArtifactStore 校验 ID/hash/schema/unit/coordinate/provenance；不从路径猜语义。
- [ ] CLI 只经 Runtime；无 session、CFITSIO、AIO 内部或科学内核直接调用。
- [ ] Phase1 输出被 Phase2 按 Artifact 消费；Phase2 HiPS 被 Phase3 按 Artifact 消费。
- [ ] 当前 commit 的静态图与现场 observed 图一致且非空。

## G3：纯 CPU、Benchmark 与生产资源门

- [ ] baseline/AVX2/AVX-512 是真实独立 provider 目标，共用科学合同与 ABI。
- [ ] 主 CLI/Runtime 只使用 amd64 保守 ISA；高级指令不泄漏到主程序。
- [ ] CPUID、XGETBV、affinity、cgroup/Job Object 配额共同决定有效能力。
- [ ] benchmark 先正确性后计时；逐 kernel、规模、worker、block 记录原始样本。
- [ ] profile 绑定 CPU/OS/quota/runtime/provider/build；损坏/过期安全回退 baseline。
- [ ] 未 benchmark 的保守通道仍使用 Runtime 多 worker，不等于单线程。
- [ ] 每个 heavy node 自动产生资源时间序列、摘要和 worker balance。
- [ ] first-10s 与结束资源门实际影响进程退出码；不能只打印告警。
- [ ] 2 核真实合成工作负载持续 10–30 秒，CPU p50≥90%、mean≥85%、worker p50≥2。
- [ ] 单 worker、锁退化、负载不均和内存异常负 fixture 会失败。
- [ ] ACR 未注册、未链接、未成为生产依赖，状态为 `DORMANT_NOT_IN_PRODUCTION`。

## G4：Phase1

- [ ] Calibration、Cosmetic、Star/PSF、WCS、Photometry、Noise/SNR、Drizzle、writer 已注册。
- [ ] 每个合成测试经正式 Registry/Runtime/CLI 调用生产符号。
- [ ] Oracle 独立于待测实现，seed/单位/容差事前冻结。
- [ ] Drizzle 覆盖常数、impulse、亚像素、旋转、pixfrac、RA wrap、support、flux。
- [ ] CLI 中不存在直接 `hp_drizzle_run_hips`、重复 FITS 解析或隐藏第二调度链。
- [ ] 数值门和 ≥10 秒资源门绑定同一 source commit/run ID 并同时通过。

## G5：Phase2 与接缝

- [ ] Coverage/Sampler/UPM 在 Linux 和 MSVC 均走 Runtime lease；无默认关闭并行宏。
- [ ] 模块不读取 `hardware_concurrency()` 自行开线程；无全局 FITS 读锁。
- [ ] UPM 规约、gauge、断连图、正则化、持久化及 apply 语义写入 SCI/ALG/DATA。
- [ ] 三块 mini 场景通过正式 production sampler+UPM+persist+apply+integrate。
- [ ] 测试不注入正确 correction，不手工填写 gate 指标，不用 `CHECK(true)`。
- [ ] seam before/after、梯度、源 flux、扩展结构、support、UPM 指标均达预冻结阈值。
- [ ] 排异和积分覆盖真实生产方法、AUTO reason、variance/ivar/support/frame identity。
- [ ] block plan 有界；压力测试无 35GB 稠密 cache、无重复/遗漏、峰值符合计划。
- [ ] canonical Phase2 IR 与 observed trace 一致，诊断产物语义明确。
- [ ] 接缝科学门与 2 核 CPU 资源门在同一 production run 同时通过。

## G6：Phase3 HiPS→平面 FITS

- [ ] SCI→ALG→DATA/API 推导冻结，并引用 HiPS、HEALPix、FITS-WCS/FITS 一手来源。
- [ ] Dec/极区、NESTED、ICRS/TAN、pixel center、CD parity、order、unit 只有一套定义。
- [ ] 实际 properties 决定 max order、tile width、frame、format、unit；算法使用选中 order。
- [ ] 大图按 tile/row-band 多 worker；无生产二维串行主循环。
- [ ] nearest/bilinear（或替代算法）有球面数学定义和独立 HEALPix/WCS Oracle。
- [ ] constant/解析球面函数/impulse/tile 边界/RA wrap/极区/missing/NaN 全覆盖。
- [ ] request 的 -32/-64 真正决定 BITPIX；BUNIT、版本、run_id、provenance 不硬编码。
- [ ] 使用 CFITSIO 标准 CHECKSUM/DATASUM；重开逐项校验 header/WCS/unit/pixel/coverage。
- [ ] 故意篡改 WCS/BUNIT/pixel/checksum/coverage 均硬失败。
- [ ] Runtime Pipeline、科学 Oracle、trace、≥10 秒资源门同时通过后才标 IMPLEMENTED。

## G7：文档与代码质量

- [ ] 每份 L1 合同有 front matter、稳定 ID、状态、上下游和 source commit。
- [ ] 每个生产模块存在 SCI→ALG→DATA→ARCH→API→MOD→source→TEST→evidence 完整链。
- [ ] 追溯矩阵只由当前合同/AST/registry/CMake/test/evidence 生成，无 V5 默认或硬编码计数。
- [ ] 全部 public headers 的函数/类型/ABI 与 API 文档结构字段精确一致。
- [ ] API 语义表逐函数填写单位、所有权、线程、错误、确定性；无批量占位。
- [ ] 每个 Registry production module 有 L2 README；集合从 Registry 自动生成。
- [ ] L0 文档简洁且互不矛盾；每个结论可回溯到 L1/L3 hash。
- [ ] 注释只保留数学原因、单位、所有权、线程和边界；无审计故事/任务号/虚假声明。
- [ ] GCC/Clang 自有代码零 warning；静态分析 P0/P1 清零。
- [ ] ASan/UBSan/LSan/TSan 现场有效，LSan 未关闭，自有缺陷无 suppression。
- [ ] 依赖锁、许可、SBOM、编译器/SDK/flags/provider build ID 完整。

## G8：Linux 常在线控制节点

- [ ] 全新目录 GCC Release 和 Clang Debug configure/build/test；无旧 cache。
- [ ] 全合成 registry 与逐模块测试互相核对，无 NOT_RUN、stub 或历史日志。
- [ ] sanitizer 绑定当前 binary hash/source commit，现场复验通过。
- [ ] Phase1/2/3 各一个 10–30 秒 production heavy 合成节点通过资源门。
- [ ] cancel、checkpoint/resume、低内存 backpressure 通过。
- [ ] 少量真实数据已尝试并诚实记录；Fatduck 离线不伪造 PASS、不阻塞其余任务。
- [ ] Linux 未运行 32R，未反复执行历史版本对比。

## G9：Windows/Fatduck 最终计算节点

- [ ] Windows 使用与 Linux 相同冻结 `origin/main` commit，新目录 MSVC Release/Debug 构建。
- [ ] full benchmark 实际装载 provider DLL，并记录 correctness/profile/raw samples。
- [ ] 同一 production synthetic registry、资源门和容差在 Windows 通过。
- [ ] 三板块各 1R+masters 完整 Artifact 链和 Phase1/2/3 smoke 通过。
- [ ] 最终候选 commit/profile/config 冻结后，32R `11+11+10` 成功全链一次。
- [ ] 32R 每帧贡献、seam、UPM、rejection、support、资源和内存趋势可验证。
- [ ] 失败重跑保留原失败、修复 commit 和重跑理由，禁止删除失败记录。
- [ ] 六张 Owner 视图来自同一真实运行和 source commit，固定显示参数及 sidecar 完整。

## G10：发布、审核包和 Owner 决定

- [ ] Linux/Windows alpha.2 发布包各只有一个用户入口；provider 为内部实现。
- [ ] install/doctor/profile verify/synthetic smoke 在干净目录通过。
- [ ] 最终 checker 全量重跑，P0/P1 全 CLOSED；Windows/32R 为 PASS。
- [ ] L0 状态从 ledger/trace/evidence 自动生成，无人工抄写漂移。
- [ ] 审核包按白名单生成，完整自有源码可配置；无历史、data、build、cache、大文件。
- [ ] 打包前、解包后、hash、schema、状态和 source identity 验证全部通过。
- [ ] Agent 最多声明 `READY_FOR_OWNER_REVIEW`；`REL-004` 保持 `NOT_STARTED`。
- [ ] 只有负责人查看顶层结论、P0/P1 闭环和六张真实视图后可批准发布。
